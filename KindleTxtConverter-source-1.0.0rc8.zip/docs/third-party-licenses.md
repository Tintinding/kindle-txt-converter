# 第三方组件与分发记录

项目内便携候选包已包含开发依赖许可、Calibre 同版源码及部分经核对的上游许可全文。正式分发材料仍在核验。

| 组件 | 固定版本 | 许可记录 | 当前用途 |
|---|---|---|---|
| CPython x64 | 3.14.10 | PSF 及随包附带的第三方声明，保留完整 `LICENSE.txt` | 项目内开发运行时 |
| PySide6-Essentials / Shiboken6 | 6.12.0 | LGPL-3.0-only OR GPL-2.0-only OR GPL-3.0-only，按上游完整文本记录 | Qt 桌面界面依赖 |
| charset-normalizer | 3.5.2 | MIT | 后续编码识别 |
| pytest | 9.2.0 | MIT | 开发测试 |
| PyInstaller | 6.22.3 | GPL-2.0-or-later 带打包例外；部分文件 Apache-2.0 | 后续 Windows 打包 |
| setuptools | 84.2.1 | MIT，依实际随包许可文件记录 | 本地项目构建 |
| Calibre 完整便携组件 | 9.18.0 | GPLv3 及实际依赖许可；已缓存同版源码和官方 LICENSE/COPYRIGHT，最终完整分发方案待核验 | 项目内真实转换 |

完整传递依赖版本与复制出的许可文本清单见 `licenses/development-inventory.json`。该清单只取自项目内实际安装的发行包；不以包元数据的一行摘要替代许可全文。

## 来源

- [Python 官方 Windows NuGet 分发说明](https://docs.python.org/3.14/using/windows.html#the-nuget-org-packages)
- [NuGet Python 3.14.10](https://www.nuget.org/packages/python/3.14.10)
- [PySide6-Essentials 官方 PyPI 包](https://pypi.org/project/PySide6-Essentials/6.12.0/)
- [Qt for Python 许可证](https://doc.qt.io/qtforpython-6/licenses.html)
- [PyInstaller 许可证及打包例外](https://pyinstaller.org/en/stable/license.html)

Python 包的固定下载地址和 SHA-512 在 `scripts/dev-runtime.json` 中记录，哈希来源是 NuGet 注册目录；依赖包的 SHA-256 在 `requirements.lock` 中记录。

## 发布前待完成

1. 明确应用本身的源码分发许可；当前不擅自替用户选择公开许可。
2. 对实际打包的 Qt 模块及其第三方组件逐项核对许可、动态链接和所需通知/替换安排。
3. 确定 Calibre 组件的完整依赖、许可及相应源码方案。不能仅复制一个 EXE，也不能认为引用官网链接本身就已满足全部义务。
4. 根据实际发布物重新整理许可证目录、通知与构建材料。

## TASK-002 组件来源与实际记录

官方包和源码地址、官方 SHA-512 校验来源及固定摘要见 `scripts/converter-runtime.json`。本地缓存为 `.tools/downloads/calibre-portable-installer-9.18.0.exe`（259,196,168 字节）和 `calibre-9.18.0.tar.xz`（50,364,528 字节），均通过校验。

完整便携载荷包含 2,086 个文件、965,696,402 字节；逐文件路径、大小和 SHA-256 存于忽略的 `.tools/calibre-runtime-inventory.json`。本轮未裁剪 DLL、插件、Python 或 Qt 资源，未假设一个 `ebook-convert.exe` 可以独立运行。

从该运行时实际读取的依赖版本为 Python 3.14.10、Qt 6.10.1、PyQt 6.10.0、SQLite 3.50.4、zlib 1.3.1.zlib-ng。它们与开发环境的 PySide6 分开管理。

同版源码内 `LICENSE`、`LICENSE.rtf`、`COPYRIGHT` 已保留在 `licenses/calibre-9.18.0/`。完整包的 Qt、Python 和其他组件仍需在最终发布时逐项处理许可与相应源码义务；缓存 Calibre 本身源码并不意味着已覆盖所有第三方来源。

官方参考：[便携版](https://calibre-ebook.com/download_portable)、[版本存档](https://download.calibre-ebook.com/9.18.0/)、[校验值](https://calibre-ebook.com/signatures/)、[GPL 许可说明](https://manual.calibre-ebook.com/faq.html#how-is-calibre-licensed)。

## TASK-003 本地打包边界

技术验证包保留既有完整许可目录、应用可构建源码快照和 Calibre 9.18.0 同版源码。它只供本项目本地验收，未作正式公开分发。应用自身公开许可尚未由用户决定，Qt/其他依赖的全部对应源码、通知、替换安排和发布材料也未完成逐项核验；不得将这个 ZIP 直接视为许可证验收已通过的正式发行物。

打包没有采用开发宿主的 Poppler ICU 组件；修复了其被误采入引发的 ABI 冲突，改用 Windows 原生 ICU。未复制或修改系统 ICU DLL。目标平台下限和相应依赖仍需真实 Windows 目标环境核验。

## TASK-020 候选包材料核对

- RC3 ZIP 中的 2,086 个 Calibre 载荷文件均与项目内固定运行时清单一致。Calibre 许可及版权声明与同版源码内文件逐字节一致。证据为 `build/reports/TASK-020-rc3-distribution-audit.json`。
- Calibre 同版源码的依赖构建清单包含 76 项。其 Qt 6.10.1 的 11 个模块源码归档散列与上游公布的散列一致。该检查覆盖上游归档标识，仍须结合最终二进制、构建配置及补丁核对。证据为 `build/reports/TASK-020-calibre-source-checks.json`。
- RC4 新增 PySide6/Shiboken、Qt Base、Qt SVG、Qt Image Formats 6.12.0，以及 Calibre 构建清单所列 FFmpeg 7.1.2 和 UnRAR 7.2.2 的上游许可文本，共 66 份。归档散列、成员路径及提取文件的 SHA-256 见包内 `licenses/upstream/inventory.json`。这些文本与上游归档成员逐字节一致。Qt 6.12.0 属于桌面界面运行时，Calibre 自带 Qt 6.10.1。
- 当前单文件包已裁剪 QtWebEngine、语言检查、语音和 ONNX/DirectML 组件。正式材料尚需核对保留的实际 FFmpeg 构建选项、Qt 软件 OpenGL、Visual C++ 运行时、逐组件通知及相应源码安排。应用自身的公开分发许可仍待决定。


## 单文件候选包

RC8 将现有许可全文、应用源码快照及 Calibre 9.18.0 同版源码封装在 EXE 中，运行时通过「许可与源码」菜单打开 materials。未以瘦身为由删除这些材料。应用公开许可和剩余组件分发义务仍在 TASK-020 核对范围内。裁剪清单见 `build/reports/1.0.0rc8-slim-inventory.json`；原始完整运行时未修改。
