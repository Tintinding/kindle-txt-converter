"""记录开发环境第三方组件，不自动声明最终发布合规。"""

from hashlib import sha256
from importlib import metadata
import json
from pathlib import Path
import shutil


def main() -> None:
    root = Path(__file__).resolve().parent.parent
    environment = (root / ".venv").resolve()
    destination = root / "licenses" / "development"
    destination.mkdir(parents=True, exist_ok=True)
    inventory = []
    for distribution in sorted(metadata.distributions(), key=lambda item: item.metadata["Name"].lower()):
        name = distribution.metadata["Name"]
        if name == "kindle-txt-converter":
            continue
        copied = []
        for file in distribution.files or []:
            if not file.name.upper().startswith(("LICENSE", "COPYING", "NOTICE")):
                continue
            source = distribution.locate_file(file).resolve()
            if not source.is_relative_to(environment) or not source.is_file():
                continue
            # 保留包内层级，避免不同许可证文件的同名覆盖。
            target = destination / f"{name}-{distribution.version}" / Path(*[part for part in file.parts if part != ".."])
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, target)
            copied.append({
                "path": target.relative_to(root).as_posix(),
                "sha256": sha256(target.read_bytes()).hexdigest(),
            })
        license_name = distribution.metadata.get("License-Expression") or distribution.metadata.get("License") or "See bundled license files"
        inventory.append({"name": name, "version": distribution.version, "license_metadata": license_name, "files": copied})

    python_license = root / ".tools" / "python" / "3.14.10" / "tools" / "LICENSE.txt"
    target = root / "licenses" / "python-3.14.10" / "LICENSE.txt"
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(python_license, target)
    (root / "licenses" / "development-inventory.json").write_text(json.dumps({
        "scope": "TASK-001 development environment; not a release compliance determination",
        "packages": inventory,
        "python_license": {"path": target.relative_to(root).as_posix(), "sha256": sha256(target.read_bytes()).hexdigest()},
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"packages": len(inventory), "license_files": sum(len(item["files"]) for item in inventory) + 1}))


if __name__ == "__main__":
    main()
