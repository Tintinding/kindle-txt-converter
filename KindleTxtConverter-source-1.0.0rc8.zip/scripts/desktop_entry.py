"""PyInstaller 的 Windows GUI 入口。"""

from kindle_converter.main import main

raise SystemExit(main())
