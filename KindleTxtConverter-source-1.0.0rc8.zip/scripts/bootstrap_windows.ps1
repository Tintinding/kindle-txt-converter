﻿param([switch]$Offline)

$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$manifest = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'dev-runtime.json') -Raw | ConvertFrom-Json
$pythonVersion = $manifest.python_version
$downloadDir = Join-Path $projectRoot '.tools\downloads'
$runtimeDir = Join-Path $projectRoot ".tools\python\$pythonVersion"
$tempDir = Join-Path $projectRoot 'build\temp'
$pipCache = Join-Path $projectRoot '.cache\pip'
$pythonExe = Join-Path $runtimeDir 'tools\python.exe'
$venvPython = Join-Path $projectRoot '.venv\Scripts\python.exe'
$packagePath = Join-Path $downloadDir "python.$pythonVersion.nupkg"

if ([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT -or -not [Environment]::Is64BitOperatingSystem) {
    throw '此初始化脚本需要 64 位 Windows。'
}
New-Item -ItemType Directory -Path $downloadDir,$runtimeDir,$tempDir,$pipCache -Force | Out-Null

# 下载与安装仅使用项目内目录；不修改系统 PATH 或安装注册信息。
if (-not (Test-Path -LiteralPath $packagePath)) {
    if ($Offline) { throw '项目内没有缓存的 Python 包，无法离线初始化。' }
    Invoke-WebRequest -Uri $manifest.package_url -OutFile $packagePath -TimeoutSec 180
}
$expectedHash = [BitConverter]::ToString([Convert]::FromBase64String($manifest.sha512_base64)).Replace('-', '')
$actualHash = (Get-FileHash -LiteralPath $packagePath -Algorithm SHA512).Hash
if ($actualHash -ne $expectedHash) { throw 'Python 包校验失败，请检查下载文件。' }
if (-not (Test-Path -LiteralPath $pythonExe)) {
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [IO.Compression.ZipFile]::ExtractToDirectory($packagePath, $runtimeDir)
}

$savedEnvironment = @{}
foreach ($name in @('TEMP', 'TMP', 'PYTHONNOUSERSITE', 'PYTHONDONTWRITEBYTECODE', 'UV_PYTHON_DOWNLOADS')) {
    $savedEnvironment[$name] = [Environment]::GetEnvironmentVariable($name, 'Process')
}
try {
    $env:TEMP = $tempDir
    $env:TMP = $tempDir
    $env:PYTHONNOUSERSITE = '1'
    $env:PYTHONDONTWRITEBYTECODE = '1'
    $env:UV_PYTHON_DOWNLOADS = 'never'
    & $pythonExe -X utf8 -I -c 'import sys; assert sys.version_info[:3] == (3, 14, 10), "Python 版本不匹配"'
    if ($LASTEXITCODE -ne 0) { throw 'Python 运行时验证失败。' }
    if (-not (Test-Path -LiteralPath $venvPython)) {
        & $pythonExe -X utf8 -I -m venv (Join-Path $projectRoot '.venv') --copies
        if ($LASTEXITCODE -ne 0) { throw '创建项目虚拟环境失败。' }
    }
    $pipArgs = @('--isolated', 'install', '--require-hashes', '--only-binary=:all:', '--cache-dir', $pipCache, '-r', (Join-Path $projectRoot 'requirements.lock'))
    if ($Offline) {
        $pipArgs += @('--no-index', '--find-links', (Join-Path $projectRoot '.tools\wheels'))
    } else {
        $pipArgs += @('--index-url', 'https://pypi.org/simple')
    }
    & $venvPython -X utf8 -I -m pip @pipArgs
    if ($LASTEXITCODE -ne 0) { throw '安装锁定依赖失败。' }
    & $venvPython -X utf8 -I -m pip --isolated install --no-deps --no-build-isolation --no-index --cache-dir $pipCache --editable $projectRoot
    if ($LASTEXITCODE -ne 0) { throw '安装本地项目失败。' }
    & $venvPython -X utf8 -I -m kindle_converter --environment
    if ($LASTEXITCODE -ne 0) { throw '项目环境检查失败。' }
    Write-Host 'TASK-001 开发环境已初始化。此结果不代表转换或独立 EXE 验收通过。'
} finally {
    foreach ($name in $savedEnvironment.Keys) {
        [Environment]::SetEnvironmentVariable($name, $savedEnvironment[$name], 'Process')
    }
}
