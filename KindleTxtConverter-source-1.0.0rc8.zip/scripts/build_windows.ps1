﻿$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$python = Join-Path $root '.venv\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $python)) { throw '请先初始化项目开发环境。' }
& $python -X utf8 -I (Join-Path $PSScriptRoot 'build_windows.py')
if ($LASTEXITCODE -ne 0) { throw 'Windows 便携候选包构建未完成。' }
