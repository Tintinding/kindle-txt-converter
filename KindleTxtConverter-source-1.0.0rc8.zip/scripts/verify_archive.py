"""从固定哈希的 ZIP 实际解压并运行验证，不代替干净 Windows 验收。"""

import argparse
from datetime import datetime, timezone
from hashlib import file_digest
import importlib.util
import json
from pathlib import Path, PurePosixPath
import shutil
import stat
import zipfile


def sha256(path: Path) -> str:
    with path.open('rb') as stream:
        return file_digest(stream, 'sha256').hexdigest()


def local_child(root: Path, path: Path) -> Path:
    result = path.resolve()
    if result == root or not result.is_relative_to(root):
        raise ValueError('验证目录必须位于本项目内。')
    return result


def safe_relative(name: str) -> Path:
    parts = PurePosixPath(name)
    if parts.is_absolute() or not parts.parts or any(part in {'.', '..'} or ':' in part for part in parts.parts) or '\\' in name:
        raise ValueError('ZIP 内含不安全路径。')
    if parts.parts[0] not in {'Kindle电子书转换器_技术验证版', 'Kindle电子书转换器_便携候选版'}:
        raise ValueError('ZIP 顶层目录不符合当前验证包。')
    return Path(*parts.parts)


def verify(archive: Path, output: Path, expected_hash: str) -> dict:
    root = Path(__file__).resolve().parent.parent
    archive = local_child(root, archive)
    output = local_child(root, output)
    if output.exists():
        raise ValueError('解压验证目录已存在，拒绝覆盖。')
    if sha256(archive) != expected_hash.lower():
        raise ValueError('ZIP SHA-256 与验证基线不一致。')
    output.mkdir(parents=True)
    seen = set()
    top_levels = set()
    with zipfile.ZipFile(archive) as zipped:
        for entry in zipped.infolist():
            relative = safe_relative(entry.filename)
            top_levels.add(relative.parts[0])
            if len(top_levels) != 1:
                raise ValueError('ZIP 含多个顶层目录。')
            key = str(relative).casefold()
            if key in seen or stat.S_ISLNK(entry.external_attr >> 16):
                raise ValueError('ZIP 含重复路径或链接。')
            seen.add(key)
            destination = local_child(output, output / relative)
            if entry.is_dir():
                destination.mkdir(parents=True, exist_ok=True)
            else:
                destination.parent.mkdir(parents=True, exist_ok=True)
                with zipped.open(entry) as source, destination.open('xb') as target:
                    shutil.copyfileobj(source, target, 1024 * 1024)

    if not top_levels:
        raise ValueError('ZIP 内没有应用文件。')
    package = output / top_levels.pop()
    manifest = json.loads((package / 'package-manifest.json').read_text(encoding='utf-8'))
    expected_files = {'package-manifest.json'}
    for item in manifest['files']:
        path = local_child(package.resolve(), package / item['path'])
        if path.stat().st_size != item['bytes'] or sha256(path) != item['sha256']:
            raise ValueError('ZIP 解压后的文件大小或哈希不一致。')
        expected_files.add(path.relative_to(package).as_posix())
    actual_files = {path.relative_to(package).as_posix() for path in package.rglob('*') if path.is_file()}
    if actual_files != expected_files:
        raise ValueError('ZIP 解压结果与固定文件清单不一致。')

    # 复用已验证的进程隔离和实际结果检查，不再从开发目录复制程序。
    specification = importlib.util.spec_from_file_location('portable_helpers', root / 'scripts/verify_portable.py')
    helpers = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(helpers)
    helpers._check_package_contents(package)
    environment = helpers._isolated_environment(package)
    reports = package / 'validation-reports'
    executable = package / helpers.EXECUTABLE
    runtime = helpers._run(executable, ['--environment'], reports / 'environment.json', environment, 180)
    for key in ('frozen', 'application_runtime_inside_bundle', 'calibre_runtime_inside_bundle'):
        if runtime.get(key) is not True:
            raise ValueError('ZIP 内的冻结 EXE 未使用包内运行时。')
    inputs = package / 'validation-inputs'
    inputs.mkdir()
    source = inputs / '中文 解压验证.txt'
    standard = manifest.get('task') == 'TASK-018'
    source_text = helpers.SOURCE_TEXT
    if standard:
        source_text = '更多精彩小说请访问：www.fiction.invalid\n\n' + source_text
    source.write_text(source_text, encoding='utf-8')
    original_hash = sha256(source)
    original_mtime = source.stat().st_mtime_ns
    results = []
    for fmt in ('azw3', 'mobi'):
        book = package / 'outputs' / f'解压验证书.{fmt}'
        arguments = ['--convert', str(source), '--output', str(book),
                     '--title', '解压验证书', '--author', '测试作者', '--encoding', 'utf-8']
        if standard:
            arguments.append('--standard-cleaning')
        report = helpers._run(executable, arguments, reports / f'{fmt}.json', environment, 180)
        if standard and report.get('cleaning', {}).get('applied_rule_counts') != {'STD-001': 1}:
            raise ValueError('便携候选包未应用预期的标准清理规则。')
        results.append(helpers._check_output(book, fmt, report, original_hash))
    if sha256(source) != original_hash or source.stat().st_mtime_ns != original_mtime:
        raise ValueError('合成输入的只读保护检查失败。')
    summary = {
        'case': f"{manifest.get('task', 'TASK-003')}-archive-extraction", 'result': 'passed',
        'recorded_utc': datetime.now(timezone.utc).isoformat(),
        'evidence_scope': 'archive_extracted_on_development_host',
        'zip_sha256': expected_hash.lower(), 'zip_hash_verified': True,
        'manifest_files_verified': len(actual_files), 'frozen': True,
        'application_runtime_inside_bundle': True, 'calibre_runtime_inside_bundle': True,
        'development_path_cleared': True, 'original_unchanged': True, 'results': results,
        'clean_windows_verified': False, 'network_disconnected_verified': False,
        'ordinary_user_verified': False, 'physical_kindle_verified': False,
    }
    helpers._write_new_json(output / 'archive-smoke-summary.json', summary)
    return summary


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--archive', type=Path, required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--sha256', required=True)
    args = parser.parse_args()
    try:
        report = verify(args.archive, args.output_dir, args.sha256)
    except (ValueError, OSError, zipfile.BadZipFile) as error:
        # 不写入解压内容或任何小说正文。
        print(json.dumps({'result': 'failed', 'category': type(error).__name__, 'clean_windows_verified': False}))
        return 1
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
