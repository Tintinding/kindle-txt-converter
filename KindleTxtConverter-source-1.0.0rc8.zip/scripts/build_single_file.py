"""构建经裁剪的单文件便携版，发布 ZIP 仅包含 EXE 和使用说明。"""

from hashlib import file_digest
import json
import os
from pathlib import Path
import subprocess
import sys
import tomllib
import zipfile


def digest(path: Path, algorithm: str = "sha256") -> str:
    with path.open("rb") as stream:
        return file_digest(stream, algorithm).hexdigest()


def excluded(path: str) -> bool:
    name = path.lower()
    return any(part in name for part in (
        "/langtool/", "/espeak-ng-data/", "qtwebengine", "qt6webengine",
        "/qt6webchannel", "/qt6qml", "/qt6quick",
        "/onnxruntime", "/directml",
        "/pyqt6.qtweb", "/pyqt6.qtqml", "/pyqt6.qtquick",
    ))


def main() -> None:
    root = Path(__file__).resolve().parent.parent
    version = tomllib.loads((root / "pyproject.toml").read_text(encoding="utf-8"))["project"]["version"]
    target = root / "dist" / f"KindleConverter-{version}"
    target.mkdir(exist_ok=False)
    work = root / "build" / f"single-file-{version}"
    work.mkdir(exist_ok=False)
    runtime = json.loads((root / ".tools/calibre-runtime-inventory.json").read_text(encoding="utf-8"))
    config = json.loads((root / "scripts/converter-runtime.json").read_text(encoding="utf-8"))
    assert runtime["version"] == config["version"]
    payload = []
    omitted = []
    for item in runtime["files"]:
        if excluded(item["path"]):
            omitted.append(item)
            continue
        source = (root / "converter/calibre" / item["path"]).resolve()
        if not source.is_relative_to(root / "converter/calibre") or digest(source) != item["sha256"]:
            raise ValueError("转换组件哈希不一致。")
        payload.append({"source": str(source), "destination": "converter/calibre/" + item["path"]})
    for source in sorted((root / "licenses").rglob("*")):
        if source.is_file():
            payload.append({"source": str(source), "destination": "materials/" + source.relative_to(root).as_posix()})
    archive = root / ".tools/downloads" / config["source_url"].rsplit("/", 1)[1]
    if digest(archive, "sha512") != config["source_sha512"]:
        raise ValueError("Calibre 同版源码哈希不一致。")
    payload.append({"source": str(archive), "destination": "materials/sources/" + archive.name})
    source_zip = work / "application-source.zip"
    with zipfile.ZipFile(source_zip, "x", zipfile.ZIP_DEFLATED) as zipped:
        for folder in ("src", "scripts", "packaging", "rules"):
            for path in sorted((root / folder).rglob("*")):
                if path.is_file() and "__pycache__" not in path.parts and path.suffix in {".py", ".ps1", ".json", ".spec", ".ico"}:
                    zipped.write(path, path.relative_to(root))
        for name in ("README.md", "pyproject.toml", "requirements.lock"):
            zipped.write(root / name, name)
    payload.append({"source": str(source_zip), "destination": "materials/sources/application-source.zip"})
    payload.append({"source": str(root / "rules/standard.json"), "destination": "rules/standard.json"})
    payload_path = work / "payload.json"
    payload_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    reports = root / "build/reports"
    reports.mkdir(exist_ok=True)
    (reports / f"{version}-slim-inventory.json").write_text(json.dumps({
        "excluded": omitted, "excluded_bytes": sum(item["bytes"] for item in omitted),
        "included": payload,
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    env = os.environ.copy()
    env["KINDLE_SINGLE_PAYLOAD"] = str(payload_path)
    env["PATH"] = str(Path(sys.executable).parent) + os.pathsep + "C:/Windows/System32;C:/Windows"
    env["PYINSTALLER_CONFIG_DIR"] = str(root / ".cache/pyinstaller")
    env["TEMP"] = env["TMP"] = str(root / "build/packaging-temp")
    Path(env["TEMP"]).mkdir(exist_ok=True)
    with (reports / f"{version}-single-build.log").open("xb") as log:
        subprocess.run([
            sys.executable, "-X", "utf8", "-I", "-m", "PyInstaller",
            "--distpath", str(target), "--workpath", str(work / "pyinstaller"),
            str(root / "packaging/KindleConverterSingle.spec"),
        ], cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT, check=True, timeout=1200)
    (target / "使用说明.txt").write_text(
        f"Kindle 电子书转换器 {version} 单文件便携版\n\n"
        "双击 Kindle电子书转换器.exe 启动。启动时会释放临时运行组件，请稍候。\n"
        "正常退出后临时组件自动清理。运行时仍需临时磁盘空间。\n"
        "导入 TXT，填写书籍信息，在清理预览中勾选并删除所选建议。\n"
        "选择输出文件夹和 AZW3 或 MOBI 格式，点击生成电子书。\n"
        "文件名按书名自动生成，原始 TXT 保留。用户自行传送到 Kindle。\n"
        "菜单中的“许可与源码”可查看内置第三方材料。\n"
        "自定义规则保存在 EXE 旁的 settings，默认电子书保存在 outputs。\n"
        "当前为项目内候选版，公开分发材料继续核对。\n", encoding="utf-8-sig")
    destination = root / "dist" / f"KindleConverter_{version}_Windows_x64.zip"
    with zipfile.ZipFile(destination, "x", zipfile.ZIP_DEFLATED) as zipped:
        for path in sorted(target.iterdir()):
            zipped.write(path, path.name)
    summary = {
        "version": version, "exe_bytes": (target / "Kindle电子书转换器.exe").stat().st_size,
        "zip_bytes": destination.stat().st_size, "zip_sha256": digest(destination),
        "excluded_bytes": sum(item["bytes"] for item in omitted),
        "entries": ["Kindle电子书转换器.exe", "使用说明.txt"],
    }
    destination.with_suffix(".zip.sha256").write_text(summary["zip_sha256"] + "  " + destination.name + "\n", encoding="utf-8")
    (reports / f"{version}-single-summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary), flush=True)


if __name__ == "__main__":
    main()
