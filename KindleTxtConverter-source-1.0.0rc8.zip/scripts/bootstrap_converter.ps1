﻿param([switch]$Offline)
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$config = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'converter-runtime.json') -Raw | ConvertFrom-Json
$downloads = Join-Path $root '.tools\downloads'
New-Item -ItemType Directory -Path $downloads -Force | Out-Null
foreach ($kind in @('portable', 'source')) {
    $url = $config.($kind + '_url')
    $file = Join-Path $downloads ($url.Split('/')[-1])
    if (-not (Test-Path -LiteralPath $file)) {
        if ($Offline) { throw '缺少缓存的转换组件或同版源码。' }
        Invoke-WebRequest -Uri $url -OutFile $file -TimeoutSec 240
    }
    if ((Get-FileHash -LiteralPath $file -Algorithm SHA512).Hash -ne $config.($kind + '_sha512')) {
        throw '转换组件或源码 SHA-512 校验失败。'
    }
}
$python = Join-Path $root '.venv\Scripts\python.exe'
if (-not (Test-Path -LiteralPath (Join-Path $root $config.runtime_relative_path))) {
    & $python -X utf8 -I (Join-Path $PSScriptRoot 'extract_calibre.py')
    if ($LASTEXITCODE -ne 0) { throw '完整便携组件提取失败。' }
}
Write-Host '转换运行时已准备；实际转换及独立运行需分别验证。'
