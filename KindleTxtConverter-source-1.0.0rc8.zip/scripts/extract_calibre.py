"""离线提取官方便携包完整资源，避免上游启动器的 58 字符路径限制。"""

import hashlib
import json
import lzma
from pathlib import Path, PurePosixPath
import struct
import zipfile
import zlib

import pefile


def main() -> None:
    root = Path(__file__).resolve().parent.parent
    config = json.loads((root / 'scripts/converter-runtime.json').read_text(encoding='utf-8'))
    archive = root / '.tools/downloads' / config['portable_url'].rsplit('/', 1)[1]
    with archive.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha512').hexdigest()
    if digest != config['portable_sha512']:
        raise ValueError('官方便携包 SHA-512 不匹配。')
    target = (root / 'converter/calibre').resolve()
    if not target.is_relative_to(root):
        raise ValueError('提取目标超出项目目录。')
    if target.exists() and any(target.iterdir()):
        raise ValueError('目标目录非空，拒绝覆盖已有组件。')
    pe = pefile.PE(str(archive), fast_load=True)
    pe.parse_data_directories(directories=[pefile.DIRECTORY_ENTRY['IMAGE_DIRECTORY_ENTRY_RESOURCE']])
    resource = next(entry for entry in pe.DIRECTORY_ENTRY_RESOURCE.entries if str(entry.name).lower() == 'extra')
    data = resource.directory.entries[0].directory.entries[0].data.struct
    payload = pe.get_data(data.OffsetToData, data.Size)
    pe.close()
    if payload[:4] != b'LZIP' or payload[4] not in (0, 1):
        raise ValueError('官方资源不是支持的 LZIP 版本。')
    code = payload[5]
    base = 1 << (code & 31)
    dictionary = base - (base // 16) * ((code >> 5) & 7)
    decoder = lzma.LZMADecompressor(format=lzma.FORMAT_RAW, filters=[
        {'id': lzma.FILTER_LZMA1, 'dict_size': dictionary, 'lc': 3, 'lp': 0, 'pb': 2}
    ])
    zip_path = root / '.tools/downloads/calibre-portable-payload.zip'
    checksum, size, trailer = 0, 0, b''
    with zip_path.open('wb') as output:
        for offset in range(6, len(payload), 1024 * 1024):
            end = min(offset + 1024 * 1024, len(payload))
            chunk = decoder.decompress(payload[offset:end])
            checksum = zlib.crc32(chunk, checksum)
            size += len(chunk)
            output.write(chunk)
            if decoder.eof:
                trailer = decoder.unused_data + payload[end:]
                break
    if len(trailer) != (12 if payload[4] == 0 else 20):
        raise ValueError('LZIP 资源不完整。')
    expected_crc, expected_size = struct.unpack('<IQ', trailer[:12])
    member_size = len(payload) if payload[4] == 0 else struct.unpack('<Q', trailer[12:])[0]
    if checksum != expected_crc or size != expected_size or member_size != len(payload):
        raise ValueError('LZIP 校验失败。')
    files = []
    target.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_path) as archive_zip:
        for entry in archive_zip.infolist():
            parts = PurePosixPath(entry.filename.replace('\\', '/')).parts
            if not parts or parts[0] != 'Calibre Portable' or '..' in parts:
                raise ValueError('组件 ZIP 路径不符合预期。')
            destination = target.joinpath(*parts[1:]).resolve()
            if not destination.is_relative_to(target):
                raise ValueError('组件文件超出目标目录。')
            if entry.is_dir():
                destination.mkdir(parents=True, exist_ok=True)
            else:
                destination.parent.mkdir(parents=True, exist_ok=True)
                with archive_zip.open(entry) as source, destination.open('xb') as output:
                    while chunk := source.read(1024 * 1024):
                        output.write(chunk)
                with destination.open('rb') as source:
                    file_hash = hashlib.file_digest(source, 'sha256').hexdigest()
                files.append({'path': destination.relative_to(target).as_posix(), 'bytes': entry.file_size, 'sha256': file_hash})
    if not (root / config['runtime_relative_path']).is_file():
        raise ValueError('完整组件中未找到转换程序。')
    report = {'version': config['version'], 'complete_portable_payload': True, 'files': files, 'bytes': sum(f['bytes'] for f in files)}
    (root / '.tools/calibre-runtime-inventory.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps({'version': config['version'], 'files': len(files), 'bytes': report['bytes'], 'lzip_crc_verified': True}))


if __name__ == '__main__':
    main()
