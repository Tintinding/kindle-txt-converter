"""在开发机迁移目录中验证真实便携包；不冒充干净 Windows 验收。"""

import argparse
from datetime import datetime, timezone
from hashlib import file_digest, sha256
import json
import os
from pathlib import Path
import shutil
import struct
import subprocess


EXECUTABLE = 'Kindle电子书转换器.exe'
RELOCATION_FOLDER = '中文 路径 便携验证'
SOURCE_TEXT = (
    '第一章 初见\n'
    '这是自行编写的便携版测试，包含中文及 https://example.com。\n'
    '第二章 继续\n'
    '正文包含 <符号> & 普通对话，不包含用户小说。\n'
    '第三章 结尾\n'
    '最后一段应完整保留。\n'
)
CHAPTER_COUNT = 3


class CheckFailed(ValueError):
    """只展示安全类别，不包含用户输入或外部进程原始日志。"""


def _inside(root: Path, path: Path, label: str) -> Path:
    resolved = path.resolve()
    if resolved == root or not resolved.is_relative_to(root):
        raise CheckFailed(f'{label}必须是本项目内的独立目录。')
    return resolved


def _hash(path: Path) -> str:
    with path.open('rb') as stream:
        return file_digest(stream, 'sha256').hexdigest()


def _write_new_json(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8') as output:
        json.dump(value, output, ensure_ascii=False, indent=2)


def _check_package_contents(package: Path) -> dict[str, int]:
    if not (package / EXECUTABLE).is_file():
        raise CheckFailed('来源包缺少桌面可执行文件。')
    if not (package / '_internal').is_dir():
        raise CheckFailed('来源包缺少应用运行依赖目录。')
    if not (package / 'converter/calibre/Calibre/ebook-convert.exe').is_file():
        raise CheckFailed('来源包缺少实际转换运行时。')
    private_directories = {'.local', '.venv', '.tools', '.git', '.cache', 'node_modules'}
    allowed_root_txt = {'使用说明.txt', 'README.txt', 'readme.txt'}
    files, byte_count = 0, 0
    for entry in package.rglob('*'):
        relative = entry.relative_to(package)
        if entry.is_symlink() or entry.is_junction() or not entry.resolve().is_relative_to(package):
            raise CheckFailed('来源包包含链接或越界路径，不适合独立复制验证。')
        if any(part.lower() in private_directories for part in relative.parts):
            raise CheckFailed('来源包包含开发环境或个人配置目录。')
        if entry.is_dir():
            continue
        # 引擎和许可自身可包含文档；应用根目录不应夹带原始 TXT 或开发产物。
        if relative.parts[0].lower() in {'outputs', 'build', 'validation-inputs', 'validation-reports', 'validation-state'}:
            raise CheckFailed('来源包包含历史输出或测试数据，请先生成干净打包目录。')
        if len(relative.parts) == 1:
            if entry.suffix.lower() in {'.azw3', '.mobi', '.epub'}:
                raise CheckFailed('来源包根目录包含用户电子书输出。')
            if entry.suffix.lower() == '.txt' and entry.name not in allowed_root_txt:
                raise CheckFailed('来源包根目录包含未声明的 TXT。')
        files += 1
        byte_count += entry.stat().st_size
    return {'files': files, 'bytes': byte_count}


def _isolated_environment(package: Path) -> dict[str, str]:
    env = os.environ.copy()
    for name in list(env):
        upper = name.upper()
        if upper.startswith(('PYTHON', 'PYINSTALLER', '_PYI', 'CONDA', 'VIRTUAL_ENV', 'UV_')):
            env.pop(name, None)
        elif upper in {'QT_PLUGIN_PATH', 'QT_QPA_PLATFORM_PLUGIN_PATH', 'QML2_IMPORT_PATH', 'QML_IMPORT_PATH', 'QTDIR'}:
            env.pop(name, None)
    env['PATH'] = ''
    state = package / 'validation-state'
    for name, directory in (
        ('TEMP', 'temp'), ('TMP', 'temp'),
        ('CALIBRE_CONFIG_DIRECTORY', 'config'),
        ('CALIBRE_CACHE_DIRECTORY', 'cache'),
        ('CALIBRE_TEMP_DIR', 'temp'),
        ('CALIBRE_WORKER_TEMP_DIR', 'temp'),
    ):
        folder = state / directory
        folder.mkdir(parents=True, exist_ok=True)
        env[name] = str(folder)
    return env


def _run(executable: Path, arguments: list[str], report: Path, env: dict[str, str], timeout: int) -> dict:
    report.parent.mkdir(parents=True, exist_ok=True)
    if report.exists():
        raise CheckFailed('报告文件已存在，拒绝覆盖。')
    try:
        result = subprocess.run(
            [str(executable), *arguments, '--report', str(report)],
            cwd=executable.parent, env=env, shell=False,
            stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0), timeout=timeout,
        )
    except subprocess.TimeoutExpired as error:
        raise CheckFailed('迁移包进程超时；未视为验收成功。') from error
    except OSError as error:
        raise CheckFailed('迁移包进程无法启动。') from error
    if result.returncode != 0:
        raise CheckFailed(f'迁移包检查进程失败（退出码 {result.returncode}）。')
    try:
        data = json.loads(report.read_text(encoding='utf-8'))
    except (OSError, UnicodeError, json.JSONDecodeError) as error:
        raise CheckFailed('迁移包没有生成可读取的结构化报告。') from error
    if not isinstance(data, dict) or 'error' in data:
        raise CheckFailed('迁移包返回了错误报告。')
    return data


def _check_output(path: Path, fmt: str, report: dict, source_hash: str) -> dict:
    if not path.is_file():
        raise CheckFailed('迁移包没有生成电子书文件。')
    size = path.stat().st_size
    with path.open('rb') as stream:
        head = stream.read(86)
        if len(head) < 86 or head[60:68] != b'BOOKMOBI':
            raise CheckFailed('迁移包输出不是 Kindle 二进制格式。')
        offset = struct.unpack_from('>I', head, 78)[0]
        if offset + 40 > size:
            raise CheckFailed('迁移包输出的首记录越界。')
        stream.seek(offset + 16)
        mobi = stream.read(24)
        expected_version = 8 if fmt == 'azw3' else 6
        if len(mobi) != 24 or mobi[:4] != b'MOBI' or struct.unpack_from('>I', mobi, 20)[0] != expected_version:
            raise CheckFailed('迁移包输出实际版本不符合要求。')
    binary = report.get('binary', {})
    digest = _hash(path)
    if binary.get('bytes') != size or binary.get('sha256') != digest:
        raise CheckFailed('迁移包输出大小或哈希与验证报告不一致。')
    if report.get('format') != fmt or report.get('output_profile') != 'kindle_pw3':
        raise CheckFailed('迁移包报告的格式或设备配置不符合要求。')
    if report.get('source_sha256') != source_hash or report.get('original_unchanged') is not True:
        raise CheckFailed('迁移包的原始输入保护检查失败。')
    validation = report.get('roundtrip', {})
    for name in ('body_preserved', 'metadata_verified', 'toc_verified'):
        if validation.get(name) is not True:
            raise CheckFailed('迁移包电子书未通过正文、元数据或目录回读。')
    normalized = ''.join(character for character in SOURCE_TEXT if not character.isspace())
    if validation.get('source_text_sha256') != sha256(normalized.encode('utf-8')).hexdigest():
        raise CheckFailed('迁移包回读报告的正文校验不符合合成样本。')
    if report.get('chapters') != CHAPTER_COUNT or validation.get('toc_targets_verified') != CHAPTER_COUNT:
        raise CheckFailed('迁移包电子书的章节目标数量不正确。')
    return {
        'format': fmt, 'bytes': size, 'sha256': digest,
        'mobi_version': expected_version, 'body_preserved': True,
        'metadata_verified': True, 'toc_targets_verified': CHAPTER_COUNT,
    }


def verify(package: Path, output_directory: Path, timeout: int) -> dict:
    root = Path(__file__).resolve().parent.parent
    package = _inside(root, package, '来源包')
    output_directory = _inside(root, output_directory, '报告目录')
    if not package.is_dir():
        raise CheckFailed('来源包目录不存在。')
    relocated = _inside(root, output_directory / RELOCATION_FOLDER, '迁移包')
    if relocated.is_relative_to(package) or package.is_relative_to(relocated):
        raise CheckFailed('迁移包与来源包目录不能相互包含。')
    if output_directory.is_relative_to(package):
        raise CheckFailed('验证报告目录不能位于来源包中。')
    summary_path = output_directory / 'portable-smoke-summary.json'
    if summary_path.exists():
        raise CheckFailed('已有迁移验证报告，请选择新的输出目录。')
    if relocated.exists() and (not relocated.is_dir() or any(relocated.iterdir())):
        raise CheckFailed('迁移目录非空，拒绝覆盖或删除。')
    package_inventory = _check_package_contents(package)
    output_directory.mkdir(parents=True, exist_ok=True)
    # copytree 实际复制每个文件，不使用 hardlink 或开发目录映射。
    shutil.copytree(package, relocated, dirs_exist_ok=relocated.exists())
    executable = relocated / EXECUTABLE
    if _hash(executable) != _hash(package / EXECUTABLE):
        raise CheckFailed('复制后的可执行文件校验失败。')
    if executable.stat().st_ino and executable.stat().st_ino == (package / EXECUTABLE).stat().st_ino:
        raise CheckFailed('迁移包与来源包意外共享同一文件节点。')
    environment = _isolated_environment(relocated)
    reports = relocated / 'validation-reports'
    runtime = _run(executable, ['--environment'], reports / 'environment.json', environment, timeout)
    for name in ('frozen', 'application_runtime_inside_bundle', 'calibre_runtime_inside_bundle'):
        if runtime.get(name) is not True:
            raise CheckFailed('冻结程序的实际运行时没有全部定位到迁移包内。')
    input_directory = relocated / 'validation-inputs'
    input_directory.mkdir()
    source = input_directory / '中文 合成样本.txt'
    source.write_text(SOURCE_TEXT, encoding='utf-8')
    original_hash = _hash(source)
    original_mtime = source.stat().st_mtime_ns
    results = []
    for fmt in ('azw3', 'mobi'):
        output = relocated / 'outputs' / f'便携验证书.{fmt}'
        report = _run(executable, [
            '--convert', str(source), '--output', str(output),
            '--title', '便携验证书', '--author', '测试作者', '--encoding', 'utf-8',
        ], reports / f'{fmt}.json', environment, timeout)
        results.append(_check_output(output, fmt, report, original_hash))
    if _hash(source) != original_hash or source.stat().st_mtime_ns != original_mtime:
        raise CheckFailed('验证后合成输入发生变化。')
    summary = {
        'case': 'TASK-003-portable-smoke',
        'recorded_utc': datetime.now(timezone.utc).isoformat(),
        'evidence_scope': 'relocated_on_development_host',
        'result': 'passed',
        'package_directory': package.relative_to(root).as_posix(),
        'relocated_directory': relocated.relative_to(root).as_posix(),
        'package_inventory': package_inventory,
        'independent_copy': True, 'development_path_cleared': True,
        'frozen': True, 'application_runtime_inside_bundle': True,
        'calibre_runtime_inside_bundle': True, 'original_unchanged': True,
        'results': results,
        'clean_windows_verified': False,
        'network_disconnected_verified': False,
        'ordinary_user_verified': False,
        'physical_kindle_verified': False,
        'note': '清空开发环境变量和迁移目录运行，仅证明本开发机上的迁移验证，不代表干净系统、断网或普通用户验收。',
    }
    _write_new_json(summary_path, summary)
    return summary


def main() -> int:
    parser = argparse.ArgumentParser(description='开发机上的真实便携包迁移检查，不替代干净 Windows 验收')
    parser.add_argument('--package-dir', type=Path, required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--timeout', type=int, default=300)
    arguments = parser.parse_args()
    if arguments.timeout < 1 or arguments.timeout > 900:
        parser.error('--timeout 必须在 1～900 秒之间')
    try:
        summary = verify(arguments.package_dir, arguments.output_dir, arguments.timeout)
    except (CheckFailed, OSError) as error:
        # 外部进程的原始错误输出和任何小说内容都不进入普通报告。
        message = str(error) if isinstance(error, CheckFailed) else '复制、读取或保存迁移包时失败，请检查位置与空间。'
        print(json.dumps({'result': 'failed', 'error': message, 'clean_windows_verified': False}, ensure_ascii=False))
        return 1
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
