"""用独立手标区间测量清理初测指标，报告只含统计与位置。"""

import argparse
from collections import Counter
from dataclasses import dataclass
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
import re

from kindle_converter.core.cleaning import CleaningChange, CleaningPlan, RuleSet, analyze_cleaning, load_rules
from kindle_converter.core.cleaning_selection import CleaningSelection
from kindle_converter.core.encoding import decode_source
from kindle_converter.core.source import SourceSnapshot, read_source


ROOT = Path(__file__).resolve().parents[1]
CORPUS = ROOT / 'tests' / 'fixtures' / 'cleaning_accuracy_pilot.json'
_CODECS = {
    'utf-8': ('utf-8', b''),
    'utf-8-bom': ('utf-8', b'\xef\xbb\xbf'),
    'gbk': ('gbk', b''),
    'gb18030': ('gb18030', b''),
    'utf-16-le-bom': ('utf-16-le', b'\xff\xfe'),
    'utf-16-be-bom': ('utf-16-be', b'\xfe\xff'),
}
_AD_LABELS = {'clear_ad', 'clear_ad_review'}
_AUTO_LABELS = {'clear_ad', 'default_format'}
_REVIEW_LABELS = {'clear_ad_review', 'review_only'}
_LABELS = _AUTO_LABELS | _REVIEW_LABELS | {'keep'}
_AD_CATEGORIES = {'C01', 'C02', 'C03', 'C04', 'C05', 'C13'}


@dataclass(frozen=True)
class Annotation:
    kind: str
    start: int
    end: int


def _change_metadata(case_id: str, change: CleaningChange) -> dict:
    return {
        'case_id': case_id, 'rule_id': change.rule_id, 'category': change.category,
        'line_number': change.line_number, 'start': change.start, 'end': change.end,
    }


def _touches_visible_text(text: str, change: CleaningChange, protected: list[Annotation]) -> bool:
    for span in protected:
        start, end = max(change.start, span.start), min(change.end, span.end)
        if start < end and text[start:end].strip(' \t\u3000\r\n'):
            return True
    return False


def score_case(case_id: str, plan: CleaningPlan, labels: list[Annotation]) -> dict:
    """完整区间相等才算正确，正文保护按非布局字符重叠检查。"""
    ads = {(span.start, span.end) for span in labels if span.kind in _AD_LABELS}
    safe_deletions = {(span.start, span.end) for span in labels if span.kind in _AUTO_LABELS}
    recognized = {
        (change.start, change.end) for change in plan.changes
        if not change.replacement and change.category in _AD_CATEGORIES
    }
    defaults = [change for change in plan.changes if change.default_selected]
    default_deletions = [change for change in defaults if not change.replacement]
    keep = [span for span in labels if span.kind == 'keep']
    review_only = [span for span in labels if span.kind in _REVIEW_LABELS]
    text = plan.source.text
    return {
        'clear_ad_count': len(ads),
        'detected_clear_ad_count': len(ads & recognized),
        'default_deletion_count': len(default_deletions),
        'default_replacement_count': len(defaults) - len(default_deletions),
        'correct_default_deletion_count': sum(
            (change.start, change.end) in safe_deletions for change in default_deletions
        ),
        'missed_clear_ads': [
            {'case_id': case_id, 'start': start, 'end': end}
            for start, end in sorted(ads - recognized)
        ],
        'incorrect_default_changes': [
            _change_metadata(case_id, change) for change in defaults
            if change.replacement or (change.start, change.end) not in safe_deletions
        ],
        'default_changes_touching_body': [
            _change_metadata(case_id, change) for change in defaults
            if _touches_visible_text(text, change, keep)
        ],
        'default_changes_touching_review_only': [
            _change_metadata(case_id, change) for change in defaults
            if _touches_visible_text(text, change, review_only)
        ],
        'review_suggestions_touching_body': [
            _change_metadata(case_id, change) for change in plan.changes
            if change.risk == 'review' and _touches_visible_text(text, change, keep)
        ],
    }


def _metric(numerator: int, denominator: int, target_percent: int) -> dict:
    return {
        'numerator': numerator, 'denominator': denominator,
        'percent': round(100 * numerator / denominator, 2) if denominator else None,
        'target_percent': target_percent,
        'meets_target': bool(denominator and 100 * numerator >= target_percent * denominator),
    }


def _prepare_case(case: dict, rules: RuleSet) -> tuple[CleaningPlan, list[Annotation]]:
    encoding, bom = _CODECS[case['encoding']]
    pieces, labels = [], []
    offset = 0
    for kind, text in case['segments']:
        if kind not in _LABELS or not isinstance(text, str) or not text:
            raise ValueError('语料包含无效的标注区间。')
        labels.append(Annotation(kind, offset, offset + len(text)))
        pieces.append(text)
        offset += len(text)
    if not pieces:
        raise ValueError('语料样例必须包含正文。')
    text = ''.join(pieces)
    raw = bom + text.encode(encoding)
    source = SourceSnapshot(Path(case['id'] + '.txt'), len(raw), sha256(raw).hexdigest(), raw)
    decoded = decode_source(source, encoding)
    if decoded.text != text:
        raise ValueError('语料无法按标注编码原样复现。')
    # 合成语料的编码已经明确，异常字符仍参与清理安全评估。
    return analyze_cleaning(decoded, encoding_confirmed=True, rules=rules), labels


def evaluate_corpus(raw: bytes, rules: RuleSet) -> dict:
    corpus = json.loads(raw.decode('utf-8'))
    if corpus['schema_version'] != 1 or not corpus['cases']:
        raise ValueError('语料版本无效或缺少样例。')
    case_ids = set()
    scores = []
    for case in corpus['cases']:
        identifier = case['id']
        if not re.fullmatch(r'ACC-[0-9]{3}', identifier) or identifier in case_ids:
            raise ValueError('语料样例编号无效或重复。')
        case_ids.add(identifier)
        plan, labels = _prepare_case(case, rules)
        scores.append(score_case(identifier, plan, labels))

    totals = {
        key: sum(score[key] for score in scores)
        for key in ('clear_ad_count', 'detected_clear_ad_count',
                    'default_deletion_count', 'correct_default_deletion_count', 'default_replacement_count')
    }
    evidence = {
        key: [record for score in scores for record in score[key]]
        for key in ('missed_clear_ads', 'incorrect_default_changes', 'default_changes_touching_body',
                    'default_changes_touching_review_only', 'review_suggestions_touching_body')
    }
    recall = _metric(totals['detected_clear_ad_count'], totals['clear_ad_count'], 95)
    precision = _metric(totals['correct_default_deletion_count'], totals['default_deletion_count'], 99)
    return {
        'schema_version': 1, 'corpus_id': corpus['corpus_id'], 'corpus_sha256': sha256(raw).hexdigest(),
        'scope': 'hand_labeled_synthetic_pilot',
        'rules_version': rules.version, 'document_count': len(scores),
        'encoding_counts': dict(Counter(case['encoding'] for case in corpus['cases'])),
        'clear_ad_recall': recall, 'default_deletion_precision': precision,
        'default_replacement_count': totals['default_replacement_count'],
        'pilot_thresholds_met': (
            recall['meets_target'] and precision['meets_target']
            and not evidence['default_changes_touching_body']
            and not evidence['default_changes_touching_review_only']
            and not totals['default_replacement_count']
        ),
        **evidence,
    }


def verify_user_body(rules: RuleSet) -> dict:
    """在原文件上下文中核对已标注的正文行，不计入合成语料指标。"""
    config = json.loads((ROOT / '.local' / 'test-input.json').read_text(encoding='utf-8'))
    labels = json.loads((ROOT / '.local' / 'cleaning-accuracy-user-body.json').read_text(encoding='utf-8'))
    if (labels['schema_version'] != 1 or labels['case_id'] != config['alias']
            or labels['source_sha256'] != config['sha256'].lower()):
        raise ValueError('用户正文标注与授权输入不一致。')
    path = Path(config['source_path'])
    before_mtime = path.stat().st_mtime_ns
    source = read_source(path)
    if source.sha256 != labels['source_sha256'] or source.size_bytes != config['size_bytes']:
        raise ValueError('用户原文件与正文标注的基线不一致。')
    decoded = decode_source(source)
    plan = analyze_cleaning(decoded, rules=rules)
    rows = [match.span() for match in re.finditer(r'[^\r\n]*(?:\r\n|\r|\n|$)', decoded.text)
            if match.start() < match.end()]
    protected = []
    protected_lines = set()
    for first, last in labels['protected_line_ranges']:
        if not 1 <= first <= last <= len(rows):
            raise ValueError('用户正文标注的行范围无效。')
        protected.append(Annotation('keep', rows[first - 1][0], rows[last - 1][1]))
        protected_lines.update(range(first, last + 1))
    if not protected_lines:
        raise ValueError('用户正文标注为空。')

    overlaps = [change for change in plan.changes if _touches_visible_text(decoded.text, change, protected)]
    selection = CleaningSelection(plan)
    result = selection.apply()
    selection.verify_application(result, source)
    selection.restore_original()
    restored = source.content[:decoded.bom_bytes] + selection.render().encode(decoded.encoding)
    after = read_source(path)
    if restored != source.content or after.sha256 != source.sha256 or path.stat().st_mtime_ns != before_mtime:
        raise ValueError('用户原文件保护或恢复核对失败。')
    return {
        'case_id': labels['case_id'], 'source_sha256': source.sha256,
        'source_size_bytes': source.size_bytes, 'encoding': decoded.encoding,
        'protected_line_ranges': labels['protected_line_ranges'],
        'protected_nonblank_line_count': sum(
            bool(decoded.text[start:end].strip(' \t\u3000\r\n'))
            for number, (start, end) in enumerate(rows, 1) if number in protected_lines
        ),
        'default_changes_touching_protected_excerpt': [
            _change_metadata(labels['case_id'], change) for change in overlaps if change.default_selected
        ],
        'review_suggestions_touching_protected_excerpt': [
            _change_metadata(labels['case_id'], change) for change in overlaps if change.risk == 'review'
        ],
        'default_application_count': len(result.applied_changes),
        'restored_original_bytes_match_source': True,
        'source_hash_unchanged': True, 'source_mtime_unchanged': True,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description='测量独立手标语料的清理准确率。')
    parser.add_argument('--report', type=Path, help='项目内新的 JSON 报告路径')
    parser.add_argument('--user-body-check', action='store_true', help='核对已授权原文的私有行标注')
    parser.add_argument('--require-targets', action='store_true', help='初测未达门槛时返回非零状态')
    args = parser.parse_args()
    target = args.report.resolve() if args.report else None
    if target is not None and not target.is_relative_to(ROOT):
        parser.error('报告必须保存在项目目录内。')
    try:
        rules = load_rules()
        report = evaluate_corpus(CORPUS.read_bytes(), rules)
        if args.user_body_check:
            report['user_body_check'] = verify_user_body(rules)
        report['recorded_utc'] = datetime.now(timezone.utc).isoformat()
        output = json.dumps(report, ensure_ascii=False, indent=2)
        if target is not None:
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open('x', encoding='utf-8') as stream:
                stream.write(output + '\n')
    except (OSError, ValueError, KeyError, TypeError):
        parser.exit(2, '清理初测失败，请检查项目语料、授权输入和报告位置。\n')
    print(output)
    return int(args.require_targets and not report['pilot_thresholds_met'])


if __name__ == '__main__':
    raise SystemExit(main())
