"""以明确白名单组装本地技术验证包，不包含用户输入和开发缓存。"""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tomllib
import zipfile


def digest(path: Path, algorithm: str = 'sha256') -> str:
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, algorithm).hexdigest()


def main() -> None:
    root = Path(__file__).resolve().parent.parent
    with (root / 'pyproject.toml').open('rb') as stream:
        version = tomllib.load(stream)['project']['version']
    if not version or any(character not in '0123456789.rc' for character in version):
        raise ValueError('项目版本号无效。')
    target = root / 'dist' / f'KindleConverter-{version}'
    if target.exists():
        raise ValueError('目标构建目录已存在，拒绝覆盖已有验证包。')
    runtime = json.loads((root / '.tools/calibre-runtime-inventory.json').read_text(encoding='utf-8'))
    config = json.loads((root / 'scripts/converter-runtime.json').read_text(encoding='utf-8'))
    if runtime['version'] != config['version']:
        raise ValueError('运行时清单与固定版本不一致。')
    env = os.environ.copy()
    env.pop('KINDLE_BUILD_CONSOLE', None)
    env['KINDLE_BUILD_NAME'] = target.name
    windows = Path(os.environ.get('SystemRoot', 'C:/Windows'))
    env['PATH'] = os.pathsep.join([str(Path(sys.executable).parent), str(windows / 'System32'), str(windows)])
    env['PYINSTALLER_CONFIG_DIR'] = str(root / '.cache/pyinstaller')
    env['TEMP'] = env['TMP'] = str(root / 'build/packaging-temp')
    env['PYTHONUTF8'] = '1'
    Path(env['TEMP']).mkdir(parents=True, exist_ok=True)
    (root / 'build/reports').mkdir(parents=True, exist_ok=True)
    with (root / f'build/reports/TASK-018-{version}-pyinstaller.log').open('xb') as log:
        result = subprocess.run([sys.executable, '-X', 'utf8', '-I', '-m', 'PyInstaller',
            '--distpath', str(root / 'dist'), '--workpath', str(root / 'build/pyinstaller-task018'),
            str(root / 'packaging/KindleConverter.spec')],
            cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT,
            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0), timeout=900)
    if result.returncode:
        raise RuntimeError('EXE 构建失败，参见项目内构建日志。')
    base = (root / 'converter/calibre').resolve()
    for item in runtime['files']:
        relative = Path(item['path'])
        source = (base / relative).resolve()
        if not source.is_relative_to(base) or digest(source) != item['sha256']:
            raise ValueError('转换运行时文件校验失败。')
        destination = target / 'converter/calibre' / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, destination)
    shutil.copytree(root / 'licenses', target / 'licenses')
    (target / 'rules').mkdir()
    shutil.copyfile(root / 'rules/standard.json', target / 'rules/standard.json')
    (target / 'sources').mkdir()
    archive = root / '.tools/downloads' / config['source_url'].rsplit('/', 1)[1]
    if digest(archive, 'sha512') != config['source_sha512']:
        raise ValueError('同版源码校验失败。')
    shutil.copyfile(archive, target / 'sources' / archive.name)
    with zipfile.ZipFile(target / 'sources/application-source.zip', 'w', zipfile.ZIP_DEFLATED) as output:
        for folder in ('src', 'scripts', 'packaging', 'rules'):
            for path in (root / folder).rglob('*'):
                if path.is_file() and '__pycache__' not in path.parts and path.suffix in {'.py', '.ps1', '.json', '.spec', '.ico'}:
                    output.write(path, path.relative_to(root))
        for name in ('README.md', 'pyproject.toml', 'requirements.lock'):
            output.write(root / name, name)
    (target / '使用说明.txt').write_text(
        f'Kindle 电子书转换器 {version} · Windows x64 便携候选版\n\n'
        '请完整解压到可写目录，双击 Kindle电子书转换器.exe。\n'
        '选择或拖入 TXT，核对编码。进入“清理预览”，点击“分析标准清理”。\n'
        '勾选或全选后点击“删除所选”。取消勾选可恢复，原始 TXT 始终保留。\n'
        '可在“书籍信息”设置书名、作者、简介和封面，在“章节目录”识别或修正目录。\n'
        '默认导出 AZW3，也可选择 MOBI。输出默认位于软件目录下的 outputs。\n'
        '点击“选择文件夹”指定输出目录，文件名按书名和格式自动生成。\n'
        '转换完成后可打开输出目录，找到电子书文件。请自行将电子书传到 Kindle。\n'
        '请随 EXE 保留 _internal、converter、rules、licenses 和 sources 目录。\n'
        '本地候选包附带所需运行时。新版电子书的 PW3 阅读兼容性需实机核对。\n'
        '分发材料仍待核验，当前用于项目内试用和验收。\n',
        encoding='utf-8-sig')
    manifest = []
    for path in sorted(target.rglob('*')):
        if path.is_file():
            manifest.append({'path': path.relative_to(target).as_posix(), 'bytes': path.stat().st_size, 'sha256': digest(path)})
    size = sum(item['bytes'] for item in manifest)
    (target / 'package-manifest.json').write_text(json.dumps({
        'task': 'TASK-018', 'version': version, 'build_only': True, 'clean_windows_verified': False,
        'files': manifest, 'bytes': size}, ensure_ascii=False, indent=2), encoding='utf-8')
    summary = {'files': len(manifest), 'bytes': size, 'build_complete': True,
               'clean_windows_verified': False, 'portable_directory': target.relative_to(root).as_posix()}
    (root / f'build/reports/TASK-018-{version}-build-summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
    print(json.dumps(summary))


if __name__ == '__main__':
    main()
