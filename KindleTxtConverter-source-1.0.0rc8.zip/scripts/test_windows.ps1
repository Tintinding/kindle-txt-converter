﻿param([ValidateSet('TASK-001', 'TASK-002', 'TASK-003')][string]$Task = 'TASK-003')
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$pythonExe = Join-Path $projectRoot '.venv\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $pythonExe)) { throw '请先执行 scripts/bootstrap_windows.ps1。' }
$testTemp = [IO.Path]::GetFullPath((Join-Path $projectRoot ('build\pytest-' + $Task.ToLowerInvariant())))
$rootPrefix = [IO.Path]::GetFullPath($projectRoot).TrimEnd('\') + '\'
if (-not $testTemp.StartsWith($rootPrefix, [StringComparison]::OrdinalIgnoreCase)) {
    throw '测试临时目录超出项目范围。'
}
# pytest 会清理此专用临时目录；不会接触用户小说或其他目录。
$testReport = Join-Path $projectRoot ('build\reports\' + $Task + '-pytest.xml')
& $pythonExe -X utf8 -I -m pytest --basetemp $testTemp --junitxml $testReport -o "cache_dir=$projectRoot/.cache/pytest" (Join-Path $projectRoot 'tests')
exit $LASTEXITCODE
