"""在开发机上的解压候选包中验证 100 KiB 至 20 MiB TXT。"""

import argparse
from hashlib import file_digest, sha256
import importlib.util
import json
from pathlib import Path
from time import perf_counter


SIZES = (100 * 1024, 1024 ** 2, 5 * 1024 ** 2, 10 * 1024 ** 2, 20 * 1024 ** 2)
CHAPTERS = 12
PARAGRAPH = (
    "雾散以后，渡船仍拴在旧木桩边。阿遥顺着河岸走了一会儿，才想起今天要去镇上拿信。"
    "她绕过桥洞，从石阶上去，看见一扇漆成蓝色的门。"
).encode("utf-8") + b"\n\n"


def sample(size: int) -> bytes:
    content = bytearray()
    for index in range(CHAPTERS):
        content.extend(f"第{index + 1}章\n\n".encode("utf-8"))
        target = size * (index + 1) // CHAPTERS
        count, padding = divmod(target - len(content) - 2, len(PARAGRAPH))
        content.extend(PARAGRAPH * count)
        content.extend(b"x" * padding + b"\n\n")
    assert len(content) == size
    return bytes(content)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--package-dir", type=Path, required=True)
    arguments = parser.parse_args()
    root = Path(__file__).resolve().parent.parent
    specification = importlib.util.spec_from_file_location("portable_helpers", root / "scripts/verify_portable.py")
    helpers = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(helpers)
    package = helpers._inside(root, arguments.package_dir, "解压候选包")
    executable = package / helpers.EXECUTABLE
    if not executable.is_file() or not (package / "rules" / "standard.json").is_file():
        raise ValueError("候选包缺少可执行文件或标准清理规则。")
    output = helpers._inside(package, package / "large-text-validation", "大文件验证目录")
    output.mkdir()
    env = helpers._isolated_environment(package)
    results = []
    for size in SIZES:
        source = output / f"样本-{size}.txt"
        content = sample(size)
        with source.open("xb") as stream:
            stream.write(content)
        raw_hash = sha256(content).hexdigest()
        normalized_hash = sha256(b"".join(content.split())).hexdigest()
        original_time = source.stat().st_mtime_ns
        book = output / f"样本-{size}.azw3"
        report = output / f"样本-{size}.json"
        start = perf_counter()
        result = helpers._run(executable, ["--convert", str(source), "--output", str(book),
            "--encoding", "utf-8", "--standard-cleaning"], report, env, 600)
        elapsed = round(perf_counter() - start, 2)
        verification = result["roundtrip"]
        with source.open("rb") as stream:
            unchanged = raw_hash == file_digest(stream, "sha256").hexdigest()
        if (not unchanged or source.stat().st_mtime_ns != original_time or not book.is_file()
                or verification["source_text_sha256"] != normalized_hash
                or verification["toc_targets_verified"] != CHAPTERS):
            raise ValueError("大文件正文、目录或输入保护核对失败。")
        entry = {"input_bytes": size, "azw3_bytes": book.stat().st_size,
                 "chapters_verified": CHAPTERS, "elapsed_seconds": elapsed, "original_unchanged": True}
        results.append(entry)
        print(json.dumps(entry, ensure_ascii=False), flush=True)
    helpers._write_new_json(output / "large-text-summary.json", {
        "evidence_scope": "archive_extracted_on_development_host", "results": results,
        "gui_responsiveness_verified": False, "clean_windows_verified": False,
    })


if __name__ == "__main__":
    main()
