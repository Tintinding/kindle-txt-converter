"""按授权的本地配置验证小说转换；不将个人路径或全文写入报告。"""

import argparse
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path

from kindle_converter.converter.calibre import CalibreEngine
from kindle_converter.core.source import read_source
from kindle_converter.services.paths import application_root


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', type=Path, required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--title', required=True)
    parser.add_argument('--author', default='未知')
    args = parser.parse_args()
    root = application_root()
    destination = args.output_dir.resolve()
    if not destination.is_relative_to(root):
        raise ValueError('输出目录超出项目范围。')
    config = json.loads(args.config.read_text(encoding='utf-8'))
    source = Path(config['source_path'])
    before = read_source(source)
    before_stat = source.stat()
    if before.sha256.lower() != config['sha256'].lower():
        raise ValueError('用户输入与授权配置中的校验基线不一致。')
    reports = []
    for fmt in ('azw3', 'mobi'):
        output = destination / f'user-test-001.{fmt}'
        report = CalibreEngine(root).convert(source, output, args.title, args.author)
        reports.append(report)
    after = read_source(source)
    unchanged = before.sha256 == after.sha256 and before_stat.st_mtime_ns == source.stat().st_mtime_ns
    if not unchanged:
        raise ValueError('原文保护检查失败。')
    summary = {
        'case': config['alias'], 'recorded_utc': datetime.now(timezone.utc).isoformat(),
        'source_bytes': after.size_bytes, 'source_sha256': after.sha256,
        'original_unchanged': unchanged, 'fulltext_logged': False, 'cleaning_applied': False,
        'results': reports,
    }
    (destination / 'validation-summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
