"""按构建清单创建本地技术验证 ZIP，拒绝混入任何后生成的用户文件。"""
from hashlib import file_digest
import json
from pathlib import Path
import tomllib
import zipfile


def main() -> None:
    root = Path(__file__).resolve().parent.parent
    with (root / 'pyproject.toml').open('rb') as stream:
        version = tomllib.load(stream)['project']['version']
    if not version or any(character not in '0123456789.rc' for character in version):
        raise ValueError('项目版本号无效。')
    package = root / 'dist' / f'KindleConverter-{version}'
    destination = root / 'dist' / f'KindleConverter_{version}_Windows_x64.zip'
    if destination.exists():
        raise ValueError('验证 ZIP 已存在，拒绝覆盖。')
    manifest = json.loads((package / 'package-manifest.json').read_text(encoding='utf-8'))
    paths = []
    for item in manifest['files']:
        path = (package / item['path']).resolve()
        if not path.is_relative_to(package) or not path.is_file():
            raise ValueError('清单文件越界或不存在。')
        with path.open('rb') as stream:
            if file_digest(stream, 'sha256').hexdigest() != item['sha256']:
                raise ValueError('构建清单文件哈希不一致。')
        paths.append(path)
    paths.append(package / 'package-manifest.json')
    with zipfile.ZipFile(destination, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as output:
        for path in paths:
            output.write(path, Path('Kindle电子书转换器_便携候选版') / path.relative_to(package))
    with destination.open('rb') as stream:
        digest = file_digest(stream, 'sha256').hexdigest()
    destination.with_suffix('.zip.sha256').write_text(digest + '  ' + destination.name + '\n', encoding='utf-8')
    summary = {'file': destination.relative_to(root).as_posix(), 'bytes': destination.stat().st_size,
               'sha256': digest, 'entries': len(paths), 'formal_release': False}
    (root / f'build/reports/TASK-018-{version}-archive-summary.json').write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(summary, ensure_ascii=False))


if __name__ == '__main__':
    main()
