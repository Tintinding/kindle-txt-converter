# -*- mode: python ; coding: utf-8 -*-
import json
import os
from pathlib import Path

root = Path(SPECPATH).parent
payload = json.loads(Path(os.environ["KINDLE_SINGLE_PAYLOAD"]).read_text(encoding="utf-8"))
a = Analysis(
    [str(root / "scripts/desktop_entry.py")],
    pathex=[str(root / "src")], binaries=[], datas=[],
    hiddenimports=["PySide6.QtWidgets"],
    hookspath=[], hooksconfig={}, runtime_hooks=[],
    excludes=["PyInstaller", "pytest", "tkinter", "unittest"],
    noarchive=False, optimize=0,
)
a.binaries = [
    entry for entry in a.binaries
    if Path(entry[0]).name.lower() not in {"icuuc.dll", "icudt78.dll"}
]
# Calibre 自带独立运行时，保持原目录关系，避免再按宿主依赖重新收集。
a.datas += [(item["destination"], item["source"], "DATA") for item in payload]
pyz = PYZ(a.pure)
exe = EXE(
    pyz, a.scripts, a.binaries, a.datas, [],
    name="Kindle电子书转换器",
    debug=False, bootloader_ignore_signals=False,
    strip=False, upx=False, console=False,
    disable_windowed_traceback=False,
    icon=str(root / "packaging/KindleConverter.ico"),
)
