# -*- mode: python ; coding: utf-8 -*-
from pathlib import Path
import os

root = Path(SPECPATH).parent
diagnostic = os.environ.get('KINDLE_BUILD_CONSOLE') == '1'
a = Analysis(
    [str(root / 'scripts/desktop_entry.py')],
    pathex=[str(root / 'src')], binaries=[], datas=[],
    hiddenimports=['PySide6.QtWidgets'],
    hookspath=[], hooksconfig={}, runtime_hooks=[],
    excludes=['PyInstaller', 'pytest', 'tkinter', 'unittest'],
    noarchive=False, optimize=0,
)
# Qt 官方 Windows 轮子使用系统 ICU；开发宿主的 Poppler ICU 同名但 ABI 不同。
a.binaries = [entry for entry in a.binaries if Path(entry[0]).name.lower() not in {'icuuc.dll', 'icudt78.dll'}]
pyz = PYZ(a.pure)
exe = EXE(
    pyz, a.scripts, [], exclude_binaries=True,
    name='Kindle电子书转换器', debug=False, bootloader_ignore_signals=False,
    strip=False, upx=False, console=diagnostic, disable_windowed_traceback=False,
    icon=str(root / 'packaging/KindleConverter.ico'),
)
coll = COLLECT(exe, a.binaries, a.datas, strip=False, upx=False,
               name='KindleConverter-Diagnostic' if diagnostic else os.environ.get('KINDLE_BUILD_NAME', 'KindleConverter'))
