"""真实后台 GUI 转换检查；offscreen 不代表人工桌面点击或干净系统验收。"""
import os
import time
import pytest

os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')

from PySide6.QtWidgets import QApplication, QFileDialog
from kindle_converter.converter.calibre import CalibreEngine
from kindle_converter.gui import MainWindow
from kindle_converter.gui.batch import BatchDialog


@pytest.mark.parametrize("fmt", ["azw3", "mobi"])
def test_gui_background_uses_real_conversion_engine(tmp_path, fmt, monkeypatch):
    app = QApplication.instance() or QApplication([])
    source = tmp_path / '合成中文.txt'
    source.write_text('第一章 初见\n\n更多精彩小说请访问：www.fiction.invalid\n\n'
                      '这是自己编写的正文。\n\n第二章 继续\n结尾完整。\n', encoding='utf-8')
    original = source.read_bytes()
    window = MainWindow()
    window.select_source(source)
    deadline = time.monotonic() + 10
    while window.busy and time.monotonic() < deadline:
        app.processEvents()
        time.sleep(0.01)
    assert not window.busy
    window.title_edit.setText('桌面后台验证书')
    window.author_edit.setText('测试作者')
    window.description_edit.setPlainText("桌面端验证简介")
    window.format_combo.setCurrentIndex(window.format_combo.findData(fmt))
    output = tmp_path / f'桌面后台验证书.{fmt}'
    monkeypatch.setattr(QFileDialog, 'getExistingDirectory', lambda *args: str(tmp_path))
    window.output_button.click()
    window._analyze_cleaning()
    deadline = time.monotonic() + 10
    while window.busy and time.monotonic() < deadline:
        app.processEvents()
        time.sleep(0.01)
    assert not window.busy
    window.cleaning_preview.select_all.click()
    window.cleaning_preview.delete_button.click()
    assert not window.cleaning_preview.has_pending
    window.navigation_preview.analyze_button.click()
    deadline = time.monotonic() + 10
    while window.busy and time.monotonic() < deadline:
        app.processEvents()
        time.sleep(0.01)
    assert window.navigation_preview.editor is not None
    window.navigation_preview.editor.rename(1, "手动改名后的目录")
    window.start_conversion()
    assert window.busy
    deadline = time.monotonic() + 180
    while window.busy and time.monotonic() < deadline:
        app.processEvents()
        time.sleep(0.01)
    app.processEvents()
    assert not window.busy
    assert output.is_file(), window.status_label.text()
    assert window.last_report['roundtrip']['body_preserved'] is True
    assert window.last_report['roundtrip']['toc_targets_verified'] == 2
    assert window.last_report['cleaning']['applied_rule_counts'] == {'STD-001': 1}
    assert 'www.fiction.invalid' not in str(window.last_report)
    assert source.read_bytes() == original
    assert '转换成功' in window.status_label.text()
    assert window.convert_button.isEnabled()
    window.close()


def test_batch_dialog_real_queue_reports_independent_results(tmp_path):
    app = QApplication.instance() or QApplication([])
    source = tmp_path / "批量小说.txt"
    source.write_bytes("第一章\n窗外下着雨。".encode())
    invalid = tmp_path / "空书.txt"
    invalid.touch()
    engine = CalibreEngine()
    dialog = BatchDialog(tmp_path, lambda: engine, str)
    dialog.add_sources([invalid, source])
    dialog.start_jobs()
    deadline = time.monotonic() + 180
    while dialog.thread is not None and time.monotonic() < deadline:
        app.processEvents()
        time.sleep(0.01)
    assert dialog.thread is None
    assert [dialog.table.item(row, 1).text() for row in range(2)] == ["失败", "成功"]
    assert (tmp_path / "outputs/批量小说.azw3").is_file()
    assert not (tmp_path / "outputs/空书.azw3").exists()
    dialog.close()
    dialog.deleteLater()
