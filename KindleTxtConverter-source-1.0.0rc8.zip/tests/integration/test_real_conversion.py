from hashlib import sha256
import os
from pathlib import Path

import pytest
from PySide6.QtGui import QImage

from kindle_converter.converter.calibre import CalibreEngine
from kindle_converter.converter.layout import LayoutOptions
from kindle_converter.core.chapters import ChapterEditor
from kindle_converter.core.encoding import decode_source
from kindle_converter.core.source import read_source
from kindle_converter.services.paths import application_root


@pytest.mark.parametrize('fmt', ['azw3', 'mobi'])
def test_actual_engine_roundtrip_with_chinese_metadata(tmp_path, fmt, monkeypatch):
    engine = CalibreEngine(application_root())
    if not engine.executable.is_file():
        pytest.skip('尚未准备项目内真实转换引擎')
    text = '第一章 初见\n正常中文正文，网址 https://example.com 应保留。\n第二章 继续\n正文包含 <文本> & 符号。\n第三章 终章\n结尾完整。\n'
    source = tmp_path / '中文 测试.txt'
    source.write_text(text, encoding='utf-8')
    original = sha256(source.read_bytes()).hexdigest()
    output = tmp_path / f'测试电子书.{fmt}'
    commit = os.rename if os.name == 'nt' else os.link
    committed = []

    def same_directory_commit(source, destination):
        # 模拟跨盘改名限制：最终提交必须从输出目录中的暂存目录完成。
        assert Path(source).parent.parent == Path(destination).parent
        committed.append(Path(source))
        return commit(source, destination)

    monkeypatch.setattr(os, 'rename' if os.name == 'nt' else 'link', same_directory_commit)
    report = engine.convert(source, output, '合成测试书', '测试作者')
    assert output.is_file()
    assert report['binary']['mobi_version'] == (8 if fmt == 'azw3' else 6)
    assert report['roundtrip']['body_preserved']
    assert report['roundtrip']['toc_targets_verified'] == 3
    assert report['source_sha256'] == sha256(source.read_bytes()).hexdigest() == original
    assert report['standalone_verified'] is False
    assert committed and not committed[0].parent.exists()


@pytest.mark.parametrize('fmt', ['azw3', 'mobi'])
def test_actual_engine_preserves_volume_hierarchy_and_edited_targets(tmp_path, fmt):
    engine = CalibreEngine(application_root())
    if not engine.executable.is_file():
        pytest.skip('尚未准备项目内真实转换引擎')
    source = tmp_path / '卷章试读.txt'
    content = (
        '序章\n\n前文。外头正下着雨。\n\n第一卷 潮声\n第一章\n她回到了渡口。\n'
        '这里由读者指定为一处目录目标。\n第二卷 第一章 归家\n廊下有盏旧灯。\n第二章\n结尾完整。'
    ).encode('utf-8')
    source.write_bytes(content)
    editor = ChapterEditor(decode_source(read_source(source)))
    editor.add(8, '渡口外')
    editor.rename(9, '归家')
    editor.remove(11)
    output = tmp_path / f'卷章试读.{fmt}'
    layout = LayoutOptions(1, "loose", "left", False, visible_toc=fmt == 'azw3')
    result = engine.convert(source, output, '卷章试读', '甲 & 乙', editor=editor, layout=layout)
    assert result['chapters'] == 5
    assert result['roundtrip']['toc_targets_verified'] == 6
    assert result['roundtrip']['toc_depth'] == 2
    assert result['roundtrip']['visible_toc_verified'] is (fmt == 'azw3')
    assert result['roundtrip']['body_preserved']
    assert output.is_file() and source.read_bytes() == content


def test_no_headings_keeps_a_body_entry_in_a_real_azw3(tmp_path):
    engine = CalibreEngine(application_root())
    if not engine.executable.is_file():
        pytest.skip('尚未准备项目内真实转换引擎')
    source = tmp_path / '无章节.txt'
    source.write_text('前面是一阵海风。\n她在窗边听雨。', encoding='utf-8')
    result = engine.convert(source, tmp_path / '正文.azw3', '无章节')
    assert result['chapters'] == 0
    assert result['chapter_warnings']
    assert result['roundtrip']['toc_targets_verified'] == 1


def test_visible_toc_label_identical_to_short_body_does_not_mask_body_location(tmp_path):
    engine = CalibreEngine(application_root())
    if not engine.executable.is_file():
        pytest.skip('尚未准备项目内真实转换引擎')
    source = tmp_path / '短文.txt'
    source.write_text('正文', encoding='utf-8')
    result = engine.convert(source, tmp_path / '短文.azw3', '短文', layout=LayoutOptions(visible_toc=True))
    assert result['roundtrip']['visible_toc_verified']
    assert result['roundtrip']['toc_targets_verified'] == 1


@pytest.mark.parametrize(("fmt", "image_extension"), [("azw3", "png"), ("mobi", "jpg")])
def test_real_conversion_verifies_cover_description_language_and_default_title(tmp_path, fmt, image_extension):
    engine = CalibreEngine(application_root())
    if not engine.executable.is_file():
        pytest.skip('尚未准备项目内真实转换引擎')
    source = tmp_path / '海边试读.txt'
    source.write_text('第一章\n她看着潮水。\n第二章\n窗外是晚霞。', encoding='utf-8')
    cover = tmp_path / f'海边试读.{image_extension}'
    image = QImage(360, 480, QImage.Format.Format_RGB32)
    image.fill(0xff21445e)
    assert image.save(str(cover))
    output = tmp_path / f'试读.{fmt}'
    result = engine.convert(source, output, author='', language='en', description='第一行 <潮水>\n第二行 & 海风', cover=cover)
    assert result['roundtrip']['metadata_verified']
    assert result['roundtrip']['cover_verified']
    assert result['roundtrip']['toc_targets_verified'] == 2
    assert output.is_file()
