import os
from pathlib import Path
import threading
import time

os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')

from PySide6.QtCore import QMimeData, QPointF, Qt, QUrl
from PySide6.QtGui import QCloseEvent, QDesktopServices, QDropEvent
from PySide6.QtWidgets import QApplication, QFileDialog, QInputDialog, QLabel, QPushButton
import pytest

from kindle_converter.converter.calibre import ConversionError
from kindle_converter.gui import MainWindow


@pytest.fixture(scope='module')
def app():
    return QApplication.instance() or QApplication([])


def process_until(app, predicate, timeout=3):
    deadline = time.monotonic() + timeout
    while not predicate() and time.monotonic() < deadline:
        app.processEvents()
        time.sleep(0.005)
    app.processEvents()
    assert predicate()


def analyze_cleaning(app, window):
    window._analyze_cleaning()
    process_until(app, lambda: not window.busy)
    assert window.cleaning_preview.selection is not None


def test_main_window_defaults_to_azw3_with_simplified_tabs(app, tmp_path):
    window = MainWindow(root=tmp_path)
    assert window.format_combo.currentData() == 'azw3'
    assert window.source_edit.isReadOnly()
    assert [window.tabs.tabText(i) for i in range(window.tabs.count())] == ['书籍信息', '清理预览', '章节目录']
    assert all(label.text() != "书籍语言" for label in window.findChildren(QLabel))
    assert all("发送到 Kindle" not in button.text() for button in window.findChildren(QPushButton))
    assert window.open_output_button.text() == "打开输出目录"
    window.close()


def test_missing_input_is_explained_without_starting_a_thread(app, tmp_path):
    window = MainWindow(root=tmp_path)
    window.start_conversion()
    assert '请先选择 TXT' in window.status_label.text()
    assert not window.busy
    assert window._thread is None
    window.close()


def test_existing_output_is_protected(app, tmp_path):
    source = tmp_path / 'source.txt'
    source.write_text('自行编写的测试句子', encoding='utf-8')
    output = tmp_path / 'outputs' / 'source.azw3'
    output.parent.mkdir()
    output.write_bytes(b'existing-user-file')
    window = MainWindow(root=tmp_path)
    window.select_source(source)
    process_until(app, lambda: not window.busy)
    window.start_conversion()
    assert '同名电子书已存在' in window.status_label.text()
    assert output.read_bytes() == b'existing-user-file'
    assert not window.busy
    window.close()


def test_folder_picker_can_choose_output_before_importing_txt(app, tmp_path, monkeypatch):
    source = tmp_path / 'source.txt'
    source.write_text('自行编写的测试句子', encoding='utf-8')
    software_root = tmp_path / 'portable'
    software_root.mkdir()
    destination = tmp_path / 'desktop'
    destination.mkdir()
    external_output = destination / '阅读_用.mobi'

    class FakeEngine:
        def convert(self, *args, **kwargs):
            assert args[1] == external_output
            assert not external_output.exists()
            return {'format': 'azw3', 'chapters': 1}

    window = MainWindow(root=software_root, engine_factory=FakeEngine)
    picks = iter((str(destination), ""))
    opened_at = []

    def choose_directory(parent, caption, directory):
        opened_at.append(Path(directory))
        return next(picks)

    monkeypatch.setattr(QFileDialog, 'getExistingDirectory', choose_directory)
    window.output_button.click()
    window.output_button.click()
    assert opened_at == [software_root, destination]
    window.select_source(source)
    process_until(app, lambda: not window.busy)
    window.title_edit.setText('阅读:用')
    window.format_combo.setCurrentIndex(window.format_combo.findData('mobi'))
    assert Path(window.output_edit.text()) == destination
    analyze_cleaning(app, window)
    window.start_conversion()
    process_until(app, lambda: not window.busy)
    assert '转换成功' in window.status_label.text()
    window.close()


def test_format_change_keeps_default_output_folder(app, tmp_path):
    window = MainWindow(root=tmp_path)
    source = tmp_path / '中文 小说.txt'
    source.write_text('小说正文。', encoding='utf-8')
    window.select_source(source)
    process_until(app, lambda: not window.busy)
    assert Path(window.output_edit.text()) == tmp_path / 'outputs'
    window.format_combo.setCurrentIndex(1)
    assert Path(window.output_edit.text()) == tmp_path / 'outputs'
    window.close()


def test_background_success_disables_controls_and_prevents_early_close(app, tmp_path, monkeypatch):
    gate = threading.Event()
    entered = threading.Event()
    execution_threads = []

    class FakeEngine:
        def convert(self, *args, **kwargs):
            execution_threads.append(threading.get_ident())
            kwargs['progress'](2, "正在生成 AZW3…")
            entered.set()
            gate.wait(2)
            return {'format': 'azw3', 'chapters': 2}

    source = tmp_path / 'source.txt'
    source.write_text('自行编写的测试句子', encoding='utf-8')
    window = MainWindow(root=tmp_path, engine_factory=FakeEngine)
    window.select_source(source)
    process_until(app, lambda: not window.busy)
    analyze_cleaning(app, window)
    window.start_conversion()
    try:
        process_until(app, entered.is_set)
        assert window.busy
        assert not window.convert_button.isEnabled()
        assert not window.title_edit.isEnabled()
        event = QCloseEvent()
        window.closeEvent(event)
        assert not event.isAccepted()
        assert len(execution_threads) == 1
        assert execution_threads[0] != threading.get_ident()
    finally:
        gate.set()
        process_until(app, lambda: not window.busy)
    assert '转换成功' in window.status_label.text()
    assert window.convert_button.isEnabled()
    assert window.last_report['chapters'] == 2
    assert window._thread is None
    opened = []
    monkeypatch.setattr(QDesktopServices, "openUrl", lambda url: opened.append(url.toLocalFile()) or True)
    window.open_output_button.click()
    assert Path(opened[0]) == tmp_path / "outputs"
    window.close()


@pytest.mark.parametrize('error, expected', [
    (ConversionError('输出文件已存在，请使用新的文件名。'), '输出文件已存在'),
    (RuntimeError('private-novel-fragment'), '转换未完成'),
])
def test_background_failure_restores_controls_without_leaking_unexpected_text(app, tmp_path, error, expected):
    class FakeEngine:
        def convert(self, *args, **kwargs):
            raise error

    source = tmp_path / 'source.txt'
    source.write_text('自行编写的测试句子', encoding='utf-8')
    window = MainWindow(root=tmp_path, engine_factory=FakeEngine)
    window.select_source(source)
    process_until(app, lambda: not window.busy)
    analyze_cleaning(app, window)
    window.start_conversion()
    process_until(app, lambda: not window.busy)
    assert expected in window.status_label.text()
    assert 'private-novel-fragment' not in window.status_label.text()
    assert window.convert_button.isEnabled()
    assert window.last_report is None
    window.close()


def test_dropped_file_is_decoded_with_default_title(app, tmp_path):
    source = tmp_path / "中文 路径.TXT"
    source.write_bytes(("试读段落。\r\n" * 400).encode("utf-16"))
    mime = QMimeData()
    mime.setUrls([QUrl.fromLocalFile(str(source))])
    event = QDropEvent(QPointF(10, 10), Qt.DropAction.CopyAction, mime, Qt.MouseButton.LeftButton,
                       Qt.KeyboardModifier.NoModifier)
    window = MainWindow(root=tmp_path)
    window.dropEvent(event)
    process_until(app, lambda: not window.busy)
    assert event.isAccepted()
    assert window.title_edit.text() == source.stem
    assert "UTF-16" in window.encoding_label.text()
    assert f"{source.stat().st_size:,} 字节" in window.encoding_label.text()
    window.close()


def test_tentative_encoding_requires_confirmation_or_manual_override(app, tmp_path):
    source = tmp_path / "ascii.txt"
    source.write_bytes(b"One line of text.\n")
    window = MainWindow(root=tmp_path)
    window.select_source(source)
    process_until(app, lambda: not window.busy)
    window.start_conversion()
    assert not window.busy
    assert "使用当前编码" in window.status_label.text()
    assert not window.encoding_confirmation.isHidden()
    window.encoding_confirmation.click()
    window.start_conversion()
    process_until(app, lambda: not window.busy)
    assert window.cleaning_preview.selection is not None
    window.encoding_combo.setCurrentIndex(1)
    window._load_source()
    process_until(app, lambda: not window.busy)
    assert window._decoded is not None and not window._decoded.requires_confirmation
    assert window.encoding_confirmation.isHidden()
    window.close()


def test_cleaning_all_delete_then_restore_selected_items(app, tmp_path):
    source = tmp_path / "清理样例.txt"
    text = ("更多精彩小说请访问：www.fiction.invalid\n\n正文从此开始。\n\n"
            "本书来源：https://source.invalid/book\n\n尾声。\n")
    source.write_bytes(text.encode("utf-8"))
    window = MainWindow(root=tmp_path)
    window.select_source(source)
    process_until(app, lambda: not window.busy)
    analyze_cleaning(app, window)
    preview = window.cleaning_preview
    index = preview.model.index(0, 0)
    preview.table.setCurrentIndex(index)
    assert "正文从此开始" in preview.context.toPlainText()
    assert preview.model.rowCount() == 2
    assert not preview.delete_button.isEnabled()
    preview.select_all.click()
    assert preview.delete_button.isEnabled()
    assert preview.selection.render() == text
    for row in range(preview.model.rowCount()):
        assert preview.model.data(preview.model.index(row, 0), Qt.ItemDataRole.CheckStateRole) == Qt.CheckState.Checked
    window.start_conversion()
    assert "删除所选" in window.status_label.text()
    assert not window.busy
    preview.delete_button.click()
    assert not preview.has_pending
    assert len(preview.selection.confirmed_review_ids) == 1
    assert "fiction.invalid" not in preview.selection.render()
    assert "source.invalid" not in preview.selection.render()
    assert preview.model.data(preview.model.index(0, 3)) == "已删除"
    preview.model.setData(index, Qt.CheckState.Unchecked, Qt.ItemDataRole.CheckStateRole)
    assert "fiction.invalid" in preview.selection.render()
    assert "source.invalid" not in preview.selection.render()
    preview.select_all.click()
    preview.select_all.click()
    assert preview.selection.render() == text
    assert not preview.delete_button.isEnabled()
    assert source.read_bytes() == text.encode("utf-8")
    window.close()


def test_navigation_tree_editing_and_cleaning_change_invalidation(app, tmp_path, monkeypatch):
    source = tmp_path / "卷章.txt"
    source.write_text("第一卷\n第一章\n桥头正文。\n第二章\n末尾正文。\n\n"
                      "更多精彩小说请访问：www.fiction.invalid\n", encoding="utf-8")
    window = MainWindow(root=tmp_path)
    window.select_source(source)
    process_until(app, lambda: not window.busy)
    analyze_cleaning(app, window)
    panel = window.navigation_preview
    panel.analyze_button.click()
    process_until(app, lambda: not window.busy)
    assert panel.editor is not None
    volume = panel.tree.topLevelItem(0)
    assert volume.text(0) == "第一卷" and volume.childCount() == 2
    panel.tree.setCurrentItem(volume.child(0))
    monkeypatch.setattr(QInputDialog, "getText", lambda *args, **kwargs: ("渡口", True))
    panel.rename_button.click()
    assert panel.tree.topLevelItem(0).child(0).text(0) == "渡口"
    panel.line.setText("3")
    panel.title.setText("桥头")
    panel.add_button.click()
    assert panel.tree.topLevelItem(0).child(1).text(0) == "桥头"
    panel.remove_button.click()
    assert panel.tree.topLevelItem(0).childCount() == 2
    window.cleaning_preview.select_all.click()
    assert panel.editor is not None
    window.cleaning_preview.delete_button.click()
    assert panel.editor is None and panel.analyze_button.isEnabled()
    window.close()


def test_background_cancel_restores_controls(app, tmp_path):
    gate = threading.Event()

    class FakeEngine:
        def convert(self, *args, **kwargs):
            gate.wait(2)
            kwargs["control"].check()
            raise AssertionError("conversion should be cancelled")

    source = tmp_path / "取消测试.txt"
    source.write_text("正文内容。", encoding="utf-8")
    window = MainWindow(root=tmp_path, engine_factory=FakeEngine)
    window.select_source(source)
    process_until(app, lambda: not window.busy)
    analyze_cleaning(app, window)
    window.start_conversion()
    assert window.cancel_button.isEnabled()
    window.cancel_button.click()
    gate.set()
    process_until(app, lambda: not window.busy)
    assert "转换已取消" in window.status_label.text()
    assert window.convert_button.isEnabled() and not window.open_output_button.isEnabled()
    assert not (Path(window.output_edit.text()) / '取消测试.azw3').exists()
    logfile = tmp_path / "诊断.json"
    window.export_diagnostic(logfile)
    log = logfile.read_text(encoding="utf-8")
    assert "转换已取消" in log and "正文内容" not in log
    with pytest.raises(FileExistsError):
        window.export_diagnostic(logfile)
    window.close()
