"""TASK-005-04 有限重复标题候选的人工标注、安全边界和可恢复检查。"""

from collections import Counter
from copy import deepcopy
from dataclasses import replace
import json
from pathlib import Path

import pytest

from kindle_converter.core.cleaning import CleaningError, analyze_cleaning, load_rules
from kindle_converter.core.encoding import decode_source
from kindle_converter.core.source import read_source


PROJECT_ROOT = Path(__file__).resolve().parents[2]
CASE_PATH = PROJECT_ROOT / 'tests' / 'fixtures' / 'cleaning_heading_cases.json'
RULE_PATH = PROJECT_ROOT / 'rules' / 'standard.json'
CASES = json.loads(CASE_PATH.read_text(encoding='utf-8'))['cases']


def make_plan(tmp_path, text, *, codec='utf-8', bom=b''):
    path = tmp_path / '独立合成标题样本.txt'
    path.write_bytes(bom + text.encode(codec))
    source = read_source(path)
    decoded = decode_source(source, encoding=codec)
    return source, decoded, analyze_cleaning(decoded, encoding_confirmed=True)


@pytest.mark.parametrize('case', CASES, ids=[case['id'] for case in CASES])
def test_human_labeled_duplicate_heading_cases(tmp_path, case):
    source, decoded, plan = make_plan(tmp_path, case['text'])
    before_mtime = source.path.stat().st_mtime_ns
    assert Counter(change.rule_id for change in plan.changes if change.default_selected) == Counter(case['expected_default_rule_ids'])
    assert Counter(change.rule_id for change in plan.changes if change.risk == 'review') == Counter(case['expected_review_rule_ids'])
    assert len(plan.changes) == len(case['expected_default_rule_ids']) + len(case['expected_review_rule_ids'])
    assert plan.source_sha256 == source.sha256
    for change in plan.changes:
        assert change.original == decoded.text[change.start:change.end]
        assert change.replacement == ''
        assert change.byte_start == decoded.byte_offset(change.start)
        assert change.byte_end == decoded.byte_offset(change.end)
        assert not change.default_selected or change.risk == 'low'
    assert plan.render() == case['text']
    assert plan.render(plan.default_selected_ids) == case['expected_default_text']
    review_ids = tuple(change.id for change in plan.changes if change.risk == 'review')
    if review_ids:
        with pytest.raises(CleaningError):
            plan.render(review_ids)
        assert plan.render(review_ids, confirmed_review_ids=review_ids) == case['expected_review_text']
    assert plan.render() == case['text']
    assert source.path.read_bytes() == source.content
    assert source.path.stat().st_mtime_ns == before_mtime


def test_three_repeats_keep_first_raw_and_allow_individual_restoration(tmp_path):
    first_raw = '第十二章 远行\n'
    text = first_raw * 3
    _, _, plan = make_plan(tmp_path, text)
    second, third = plan.changes
    assert (second.start, second.end) == (len(first_raw), 2 * len(first_raw))
    assert (third.start, third.end) == (2 * len(first_raw), 3 * len(first_raw))
    assert second.original == third.original == first_raw
    assert plan.render((second.id,)) == first_raw * 2
    assert plan.render((third.id,)) == first_raw * 2
    assert plan.render(plan.default_selected_ids) == first_raw
    assert plan.render() == text


def test_blank_and_heading_suggestions_are_ordered_disjoint_and_not_implicitly_reapplied(tmp_path):
    case = next(case for case in CASES if case['id'] == 'HDG-018')
    _, _, plan = make_plan(tmp_path, case['text'])
    blank, duplicate = plan.changes
    assert (blank.rule_id, duplicate.rule_id) == ('STD-009', 'STD-010')
    assert blank.end <= duplicate.start
    assert plan.render((blank.id,)) == '第一章 初见\n\n第一章 初见\n\n合成正文。\n'
    assert plan.render((duplicate.id,)) == '第一章 初见\n\n\n\n合成正文。\n'
    assert plan.render(plan.default_selected_ids) == '第一章 初见\n\n\n合成正文。\n'
    assert plan.render() == case['text']


def test_utf16_bom_emoji_heading_byte_positions_preserve_original(tmp_path):
    text = '😀𠀀正文。\r\n\r\n第一章 初见\r\n第一章 初见\r\n\r\n后面的正文。\r\n'
    source, _, plan = make_plan(tmp_path, text, codec='utf-16-be', bom=b'\xfe\xff')
    change, = plan.changes
    assert change.rule_id == 'STD-010'
    assert change.original == '第一章 初见\r\n'
    assert change.byte_start == 2 + len(text[:change.start].encode('utf-16-be'))
    assert change.byte_end == 2 + len(text[:change.end].encode('utf-16-be'))
    assert source.content[change.byte_start:change.byte_end] == change.original.encode('utf-16-be')
    assert plan.render(plan.default_selected_ids) == '😀𠀀正文。\r\n\r\n第一章 初见\r\n\r\n后面的正文。\r\n'
    assert plan.render() == text
    assert source.path.read_bytes() == source.content


def test_disabled_duplicate_heading_rule_keeps_all_repeats(tmp_path):
    text = '第一章 初见\n第一章 初见\n'
    _, decoded, _ = make_plan(tmp_path, text)
    rules = load_rules()
    disabled = replace(rules, rules=tuple(replace(rule, default_enabled=False) if rule.id == 'STD-010' else rule for rule in rules.rules))
    plan = analyze_cleaning(decoded, rules=disabled)
    assert plan.changes == ()
    assert plan.render(plan.default_selected_ids) == text


def test_heading_preview_is_explicit_and_diagnostics_hide_title_and_path(tmp_path):
    secret = '私密合成标题勿入日志'
    title = '第一章 ' + secret + '\n'
    source, _, plan = make_plan(tmp_path, title * 2 + '\n合成正文。\n')
    change, = plan.changes
    preview = plan.preview(change.id)
    assert preview.before == title
    assert preview.after == ''
    for output in (json.dumps(plan.summary(), ensure_ascii=False), repr((plan, change, preview))):
        assert secret not in output
        assert str(source.path) not in output


@pytest.mark.parametrize('fault', [0, 61, '60', True, None, 'duplicate_kind'], ids=['zero', 'too_large', 'string', 'bool', 'missing', 'second_heading_rule'])
def test_heading_rule_rejects_invalid_limits_or_multiple_heading_rules(tmp_path, fault):
    payload = json.loads(RULE_PATH.read_text(encoding='utf-8'))
    rule = next(rule for rule in payload['rules'] if rule['id'] == 'STD-010')
    if fault is None:
        del rule['match']['max_title_characters']
    elif fault == 'duplicate_kind':
        extra = deepcopy(rule)
        extra['id'] = 'STD-011'
        payload['rules'].append(extra)
    else:
        rule['match']['max_title_characters'] = fault
    path = tmp_path / '合成标题规则.json'
    path.write_text(json.dumps(payload, ensure_ascii=False), encoding='utf-8')
    with pytest.raises(CleaningError) as failure:
        load_rules(path)
    assert str(failure.value)
    assert str(path) not in str(failure.value)
