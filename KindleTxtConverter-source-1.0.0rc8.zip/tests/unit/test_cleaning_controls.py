"""控制字符的独立手标、原位置、确认、布局与可恢复边界。"""

from collections import Counter
from copy import deepcopy
from dataclasses import replace
import json
from pathlib import Path

import pytest

from kindle_converter.core.cleaning import CleaningError, analyze_cleaning, load_rules
from kindle_converter.core.encoding import decode_source
from kindle_converter.core.source import read_source


ROOT = Path(__file__).resolve().parents[2]
CASES = json.loads((ROOT / 'tests/fixtures/cleaning_control_cases.json').read_text(encoding='utf-8'))['cases']


def make_plan(tmp_path, text, codec='utf-8', bom=b''):
    path = tmp_path / '独立合成控制字符.txt'
    path.write_bytes(bom + text.encode(codec))
    source = read_source(path)
    before_mtime = path.stat().st_mtime_ns
    decoded = decode_source(source, encoding=codec)
    plan = analyze_cleaning(decoded, encoding_confirmed=True)
    assert path.stat().st_mtime_ns == before_mtime
    assert path.read_bytes() == source.content
    return source, decoded, plan


@pytest.mark.parametrize('case', CASES, ids=[c['id'] for c in CASES])
def test_human_labeled_control_cases(tmp_path, case):
    source, decoded, plan = make_plan(tmp_path, case['text'])
    assert Counter(c.rule_id for c in plan.changes if c.default_selected) == Counter(case['expected_default_rule_ids'])
    assert Counter(c.rule_id for c in plan.changes if c.risk == 'review') == Counter(case['expected_review_rule_ids'])
    assert len(plan.changes) == len(case['expected_default_rule_ids']) + len(case['expected_review_rule_ids'])
    assert plan.render() == case['text']
    assert plan.render(plan.default_selected_ids) == case['text']
    all_ids = tuple(c.id for c in plan.changes)
    reviews = tuple(c.id for c in plan.changes if c.risk == 'review')
    if reviews:
        with pytest.raises(CleaningError):
            plan.render(all_ids)
    assert plan.render(all_ids, confirmed_review_ids=reviews) == case['expected_applied_text']
    for change in plan.changes:
        assert change.original == decoded.text[change.start:change.end]
        assert change.byte_start == decoded.byte_offset(change.start)
        assert change.byte_end == decoded.byte_offset(change.end)
        if change.rule_id == 'STD-012':
            assert change.risk == 'review' and not change.default_selected
            assert 'U+' in change.reason
            assert change.replacement == ''
    assert all(a.end <= b.start for a, b in zip(plan.changes, plan.changes[1:]))
    assert plan.render() == case['text']
    assert source.path.read_bytes() == source.content


@pytest.mark.parametrize('codec,bom', [('utf-16-le', b'\xff\xfe'), ('utf-16-be', b'\xfe\xff'), ('gb18030', b'')])
def test_original_control_byte_spans_after_emoji_and_c1_are_exact(tmp_path, codec, bom):
    text = '😀𠀀前\u0080\u0081文\r\n\r\n甲\u0000\u001f乙\r\n'
    source, _, plan = make_plan(tmp_path, text, codec, bom)
    first, second = plan.changes
    assert first.original == '\u0080\u0081' and second.original == '\u0000\u001f'
    for change in plan.changes:
        assert change.byte_start == len(bom) + len(text[:change.start].encode(codec))
        assert change.byte_end == len(bom) + len(text[:change.end].encode(codec))
        assert source.content[change.byte_start:change.byte_end] == change.original.encode(codec)
    ids = tuple(c.id for c in plan.changes)
    assert plan.render(ids, confirmed_review_ids=ids) == '😀𠀀前文\r\n\r\n甲乙\r\n'
    assert plan.render() == text


def test_decoding_confirmation_and_control_confirmation_are_both_required(tmp_path):
    _, decoded, plan = make_plan(tmp_path, '甲\u0000乙\n')
    assert decoded.requires_confirmation
    with pytest.raises(CleaningError):
        analyze_cleaning(decoded)
    change, = plan.changes
    with pytest.raises(CleaningError):
        plan.render((change.id,))
    assert plan.render((change.id,), confirmed_review_ids=(change.id,)) == '甲乙\n'


def test_controls_and_html_rows_can_be_selected_independently(tmp_path):
    text = '甲\u0000乙\n\n<b>合成&amp;文本</b>\n'
    _, _, plan = make_plan(tmp_path, text)
    control, html = plan.changes
    assert (control.rule_id, html.rule_id) == ('STD-012', 'STD-011')
    assert control.end <= html.start
    assert plan.render((control.id,), confirmed_review_ids=(control.id,)) == '甲乙\n\n<b>合成&amp;文本</b>\n'
    assert plan.render((html.id,), confirmed_review_ids=(html.id,)) == '甲\u0000乙\n\n合成&文本\n'
    ids = tuple(c.id for c in plan.changes)
    assert plan.render(ids, confirmed_review_ids=ids) == '甲乙\n\n合成&文本\n'
    assert plan.render() == text


def test_long_adjacent_controls_are_one_bounded_preview_and_remain_recoverable(tmp_path):
    text = '甲' + '\u0000' * 10000 + '乙\n'
    _, _, plan = make_plan(tmp_path, text)
    change, = plan.changes
    assert len(change.original) == 10000
    preview = plan.preview(change.id)
    assert len(preview.before) == 2000 and preview.before_truncated
    assert 'U+0000' in change.reason and '\u0000' not in change.reason
    assert plan.render((change.id,), confirmed_review_ids=(change.id,)) == '甲乙\n'
    assert plan.render() == text


def test_disabled_control_rule_preserves_candidates(tmp_path):
    _, decoded, _ = make_plan(tmp_path, '甲\u0000乙\n')
    rules = load_rules()
    disabled = replace(rules, rules=tuple(replace(r, default_enabled=False) if r.id == 'STD-012' else r for r in rules.rules))
    plan = analyze_cleaning(decoded, rules=disabled, encoding_confirmed=True)
    assert plan.changes == () and plan.render() == decoded.text


def test_control_diagnostics_hide_content_and_never_emit_raw_controls(tmp_path):
    secret = 'PRIVATE_CONTROL_合成正文不入日志'
    source, _, plan = make_plan(tmp_path, secret + '\u0000结尾\n')
    change, = plan.changes
    preview = plan.preview(change.id)
    assert preview.before == '\u0000' and secret in preview.context_before
    assert 'U+0000' in change.reason
    for output in (repr((plan, change, preview)), json.dumps(plan.summary(), ensure_ascii=False)):
        assert secret not in output and str(source.path) not in output
        assert '\u0000' not in output and '\\u0000' not in output


@pytest.mark.parametrize('fault', ['low_risk', 'default_selected', 'wrong_category', 'duplicate'])
def test_control_configuration_requires_safe_confirmation_policy(tmp_path, fault):
    payload = json.loads((ROOT / 'rules/standard.json').read_text(encoding='utf-8'))
    rule = next(r for r in payload['rules'] if r['id'] == 'STD-012')
    if fault == 'low_risk':
        rule['risk'] = 'low'
    elif fault == 'default_selected':
        rule['default_selected'] = True
    elif fault == 'wrong_category':
        rule['category'] = 'C02'
    else:
        extra = deepcopy(rule)
        extra['id'] = 'STD-999'
        payload['rules'].append(extra)
    path = tmp_path / '合成控制规则.json'
    path.write_text(json.dumps(payload, ensure_ascii=False), encoding='utf-8')
    with pytest.raises(CleaningError) as failure:
        load_rules(path)
    assert str(failure.value) and str(path) not in str(failure.value)
