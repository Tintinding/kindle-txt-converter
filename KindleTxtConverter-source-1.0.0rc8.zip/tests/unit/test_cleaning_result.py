"""TASK-006 的清理结果、实际应用记录和转换前核对。"""

from dataclasses import FrozenInstanceError, replace
from hashlib import sha256
import json
from pathlib import Path

import pytest

from kindle_converter.core.cleaning import CleaningError, analyze_cleaning, load_rules
from kindle_converter.core.cleaning_selection import CleaningSelection
from kindle_converter.core.encoding import decode_source
from kindle_converter.core.source import SourceSnapshot, read_source


INTRO = '第一章 合成前文𠀀😀\r\n\r\n'
AD = '小说广告链接：https://fiction.invalid/private-link\r\n'
HTML = '<b>隐私合成&amp;片段</b>\r\n'
REQUEST = '求推荐票！\r\n'
END = '合成结尾。'
BLANK = '\r\n'
TEXT = INTRO + AD + BLANK + HTML + BLANK + REQUEST + BLANK + END
WITH_HTML_APPLIED = INTRO + BLANK + '隐私合成&片段\r\n' + BLANK + REQUEST + BLANK + END


def make_source(text, *, encoding='utf-8', bom=b''):
    raw = bom + text.encode(encoding)
    return SourceSnapshot(Path('私有合成应用输入.txt'), len(raw), sha256(raw).hexdigest(), raw)


def make_selection(source, encoding=None, *, rules=None):
    return CleaningSelection(analyze_cleaning(decode_source(source, encoding), rules=rules))


@pytest.fixture
def book():
    source = make_source(TEXT, encoding='utf-16-be', bom=b'\xfe\xff')
    selection = make_selection(source)
    assert tuple(c.rule_id for c in selection.plan.changes) == ('STD-014', 'STD-011', 'STD-013')
    return source, selection


def apply_html(selection):
    _, html, _ = selection.plan.changes
    selection.select((html.id,))
    selection.confirm_review((html.id,))
    return selection.apply()


def test_application_binds_rendered_text_and_actual_choices_to_source_and_plan(book):
    source, selection = book
    ad, html, _ = selection.plan.changes
    result = apply_html(selection)
    assert result.text == WITH_HTML_APPLIED == selection.render()
    assert result.result_utf8_sha256 == sha256(WITH_HTML_APPLIED.encode('utf-8')).hexdigest()
    assert result.source_sha256 == source.sha256
    assert result.source_encoding == 'utf-16-be' and result.source_character_count == len(TEXT)
    assert result.rules_version == selection.plan.rules_version
    assert result.plan_fingerprint == selection.plan.fingerprint
    assert tuple(row.change for row in result.applied_changes) == (ad, html)
    assert tuple(row.review_confirmed for row in result.applied_changes) == (False, True)
    for applied in result.applied_changes:
        change = applied.change
        assert source.content[change.byte_start:change.byte_end] == change.original.encode('utf-16-be')
    selection.verify_application(result, source)


def test_application_is_rejected_until_all_selected_review_items_are_confirmed(book):
    _, selection = book
    _, html, request = selection.plan.changes
    selection.select((html.id, request.id))
    selection.confirm_review((html.id,))
    before = selection.summary()
    with pytest.raises(CleaningError, match='确认'):
        selection.apply()
    assert selection.summary() == before
    selection.confirm_review((request.id,))
    assert selection.apply().log_metadata()['confirmed_review_count'] == 2


def test_old_application_cannot_be_verified_after_its_confirmation_is_revoked(book):
    source, selection = book
    _, html, _ = selection.plan.changes
    result = apply_html(selection)
    selection.deselect((html.id,))
    selection.select((html.id,))
    assert selection.selected_ids == {row.change.id for row in result.applied_changes}
    assert selection.pending_review_ids == {html.id}
    with pytest.raises(CleaningError, match='选择'):
        selection.verify_application(result, source)
    selection.confirm_review((html.id,))
    selection.verify_application(selection.apply(), source)


def test_restoring_original_creates_a_new_result_and_preserves_previous_snapshot(book):
    source, selection = book
    applied = apply_html(selection)
    log = applied.log_metadata()
    selection.restore_original()
    with pytest.raises(CleaningError, match='选择'):
        selection.verify_application(applied, source)
    assert applied.text == WITH_HTML_APPLIED and applied.log_metadata() == log
    with pytest.raises(FrozenInstanceError):
        applied.text = TEXT
    restored = selection.apply()
    assert restored.text == TEXT and not restored.applied_changes
    assert b'\xfe\xff' + restored.text.encode('utf-16-be') == source.content
    assert restored.log_metadata()['applied_count'] == 0
    selection.verify_application(restored, source)


def test_verification_rejects_a_same_length_edit_to_the_source_file(tmp_path):
    path = tmp_path / '私有合成原文件.txt'
    path.write_bytes(TEXT.encode('utf-8'))
    initial = read_source(path)
    selection = make_selection(initial)
    result = apply_html(selection)
    selection.verify_application(result, read_source(path))

    changed = TEXT.replace('合成前文', '修改前文').encode('utf-8')
    assert len(changed) == initial.size_bytes and changed != initial.content
    path.write_bytes(changed)
    with pytest.raises(CleaningError, match='原文') as failure:
        selection.verify_application(result, read_source(path))
    assert str(path) not in str(failure.value)
    assert path.read_bytes() == changed


@pytest.mark.parametrize('basis', ['rules', 'encoding'])
def test_verification_rejects_a_different_plan_even_without_suggestions(basis):
    source = make_source('Synthetic text.\r\n')
    rules = load_rules()
    selection = make_selection(source, 'utf-8', rules=rules)
    if basis == 'rules':
        altered = replace(rules, max_line_characters=rules.max_line_characters - 1)
        current = make_selection(source, 'utf-8', rules=altered)
    else:
        current = make_selection(source, 'gb18030', rules=rules)
    assert not selection.plan.changes and not current.plan.changes
    assert current.plan.rules_version == selection.plan.rules_version
    assert current.plan.fingerprint != selection.plan.fingerprint
    with pytest.raises(CleaningError, match='规则或编码'):
        current.verify_application(selection.apply(), source)


@pytest.mark.parametrize('damage', ['text_and_hash', 'hash', 'source_count'])
def test_verification_rejects_inconsistent_result_content_or_digest(book, damage):
    source, selection = book
    result = apply_html(selection)
    if damage == 'text_and_hash':
        altered = result.text.replace('合成结尾', '替换结尾')
        broken = replace(result, text=altered, result_utf8_sha256=sha256(altered.encode('utf-8')).hexdigest())
    elif damage == 'hash':
        broken = replace(result, result_utf8_sha256='0' * 64)
    else:
        broken = replace(result, source_character_count=result.source_character_count + 1)
    with pytest.raises(CleaningError, match='内容与应用记录'):
        selection.verify_application(broken, source)


@pytest.mark.parametrize('damage', ['missing_row', 'modified_confirmation', 'modified_position'])
def test_verification_checks_actual_application_records(book, damage):
    source, selection = book
    result = apply_html(selection)
    ad, html = result.applied_changes
    if damage == 'missing_row':
        applied = (ad,)
    elif damage == 'modified_confirmation':
        applied = (ad, replace(html, review_confirmed=False))
    else:
        applied = (ad, replace(html, change=replace(html.change, byte_start=html.change.byte_start + 1)))
    with pytest.raises(CleaningError, match='选择'):
        selection.verify_application(replace(result, applied_changes=applied), source)


def test_log_exposes_only_metadata_for_applied_changes_and_is_safe_to_export(book):
    source, selection = book
    result = apply_html(selection)
    ad, html, request = selection.plan.changes
    log = result.log_metadata()
    assert log['event'] == 'cleaning_applied' and log['schema_version'] == 1
    assert log['applied_count'] == 2 and log['confirmed_review_count'] == 1
    assert log['applied_rule_counts'] == {'STD-014': 1, 'STD-011': 1}
    assert [row['change_id'] for row in log['changes']] == [ad.id, html.id]
    assert log['changes'][1] == {
        'change_id': html.id, 'rule_id': 'STD-011', 'category': 'C09', 'risk': 'review',
        'line_number': html.line_number, 'start': html.start, 'end': html.end,
        'byte_start': html.byte_start, 'byte_end': html.byte_end,
        'replacement_character_count': len('隐私合成&片段\r\n'), 'review_confirmed': True,
    }
    exported = json.dumps(log, ensure_ascii=False)
    assert json.loads(exported) == log
    assert request.id not in exported
    for output in (exported, repr(result), repr(result.applied_changes)):
        for private in ('private-link', '合成前文', '隐私合成', '求推荐票', str(source.path), html.reason):
            assert private not in output
    log['changes'].clear()
    assert result.log_metadata()['applied_count'] == 2
