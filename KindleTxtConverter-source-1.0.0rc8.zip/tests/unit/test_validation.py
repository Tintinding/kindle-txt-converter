from pathlib import Path

import pytest

from kindle_converter.converter.validation import validate_oeb


SOURCE = "第一章 初见\n正常中文正文。\n第二章 继续\n结尾没有缺失。"
CHAPTERS = ["第一章 初见", "第二章 继续"]


def make_oeb(directory: Path, *, with_ncx: bool = True) -> None:
    directory.mkdir(parents=True, exist_ok=True)
    (directory / "chapter1.xhtml").write_text('''<html xmlns="http://www.w3.org/1999/xhtml"><head><title>不属于正文</title></head><body><div><h2 id="c1">第一章 初见</h2><p>正常<span>中文</span>正文。</p></div></body></html>''', encoding="utf-8")
    (directory / "chapter2.xhtml").write_text('''<html xmlns="http://www.w3.org/1999/xhtml"><body><h2 id="c2">第二章 继续</h2><p>结尾没有缺失。</p><div>自动生成的末尾可见目录</div></body></html>''', encoding="utf-8")
    ncx_item = '<item id="ncx" href="toc.ncx" media-type="application/x-dtbncx+xml"/>' if with_ncx else ""
    (directory / "content.opf").write_text(f'''<package xmlns="http://www.idpf.org/2007/opf"><metadata xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:title>合成测试书</dc:title><dc:creator>测试作者</dc:creator></metadata><manifest><item id="one" href="chapter1.xhtml" media-type="application/xhtml+xml"/><item id="two" href="chapter2.xhtml" media-type="application/xhtml+xml"/>{ncx_item}</manifest><spine toc="ncx"><itemref idref="one"/><itemref idref="two"/></spine></package>''', encoding="utf-8")
    if with_ncx:
        (directory / "toc.ncx").write_text('''<ncx xmlns="http://www.daisy.org/z3986/2005/ncx/"><navMap><navPoint><navLabel><text>第一章 初见</text></navLabel><content src="chapter1.xhtml#c1"/></navPoint><navPoint><navLabel><text>第二章 继续</text></navLabel><content src="chapter2.xhtml#c2"/></navPoint></navMap></ncx>''', encoding="utf-8")


def validate(directory: Path, chapters: list[str] = CHAPTERS):
    return validate_oeb(directory, SOURCE, chapters, "合成测试书", "测试作者")


def replace_text(path: Path, old: str, new: str) -> None:
    path.write_text(path.read_text(encoding="utf-8").replace(old, new), encoding="utf-8")


def test_roundtrip_handles_nested_inline_text_and_generated_toc(tmp_path):
    make_oeb(tmp_path)
    result = validate(tmp_path)
    assert result["body_preserved"] is True
    assert result["toc_targets_verified"] == 2
    assert result["spine_documents"] == 2
    assert SOURCE not in str(result)
    assert CHAPTERS[0] not in str(result)


def test_missing_body_character_is_rejected(tmp_path):
    make_oeb(tmp_path)
    replace_text(tmp_path / "chapter1.xhtml", "正文", "文")
    with pytest.raises(ValueError, match="正文内容缺失"):
        validate(tmp_path)


def test_changed_metadata_is_rejected(tmp_path):
    make_oeb(tmp_path)
    replace_text(tmp_path / "content.opf", "测试作者", "其他作者")
    with pytest.raises(ValueError, match="元数据不一致"):
        validate(tmp_path)


@pytest.mark.parametrize("old,new,reason", [
    ("#c2", "#missing", "跳转片段不存在"),
    ("chapter2.xhtml#c2", "missing.xhtml#c2", "引用文件不存在"),
    ("第二章 继续", "改错的目录标题", "章节目录数量"),
])
def test_invalid_toc_is_rejected(tmp_path, old, new, reason):
    make_oeb(tmp_path)
    replace_text(tmp_path / "toc.ncx", old, new)
    with pytest.raises(ValueError, match=reason):
        validate(tmp_path)


def test_navigation_outside_working_directory_is_rejected(tmp_path):
    outside = tmp_path / "outside.xhtml"
    outside.write_text('<html><body id="c2">外部内容</body></html>', encoding="utf-8")
    directory = tmp_path / "oeb"
    make_oeb(directory)
    replace_text(directory / "toc.ncx", "chapter2.xhtml#c2", "../outside.xhtml#c2")
    with pytest.raises(ValueError, match="路径超出工作目录"):
        validate(directory)


def test_missing_ncx_requires_known_chapters(tmp_path):
    make_oeb(tmp_path, with_ncx=False)
    with pytest.raises(ValueError, match="章节导航目录缺失"):
        validate(tmp_path)
    assert validate(tmp_path, []) ["toc_entries"] == 0


def test_empty_source_is_not_an_automatic_success(tmp_path):
    make_oeb(tmp_path)
    with pytest.raises(ValueError, match="源正文为空"):
        validate_oeb(tmp_path, " \n", CHAPTERS, "合成测试书", "测试作者")


def test_existing_fragment_for_wrong_chapter_is_rejected(tmp_path):
    make_oeb(tmp_path)
    replace_text(tmp_path / 'toc.ncx', 'chapter2.xhtml#c2', 'chapter1.xhtml#c1')
    with pytest.raises(ValueError, match='对应章节开头'):
        validate(tmp_path)
