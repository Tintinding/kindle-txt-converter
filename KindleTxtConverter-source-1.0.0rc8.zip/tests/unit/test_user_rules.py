from hashlib import sha256
from pathlib import Path

import pytest

from kindle_converter.core.cleaning import analyze_cleaning
from kindle_converter.core.cleaning_selection import CleaningSelection
from kindle_converter.core.encoding import decode_source
from kindle_converter.core.source import SourceSnapshot
from kindle_converter.core.user_rules import UserRule, UserRuleError, compile_user_rules, load_user_rules, save_user_rules


def rule(number, kind, value, enabled=True):
    return UserRule(f"{number:032x}", kind, value, enabled)


def test_custom_rules_persist_and_suggest_without_overriding_standard_rules(tmp_path):
    path = tmp_path / "settings/user-rules.json"
    rules = (
        rule(1, "keyword", "兑换优惠"), rule(2, "line", "欢迎订阅示例"),
        rule(3, "domain", "shop.invalid"), rule(4, "regex", r"^广告第[0-9]{2}条$"),
        rule(5, "keyword", "仍需保留", False),
    )
    assert load_user_rules(path) == ()
    save_user_rules(path, rules)
    assert load_user_rules(path) == rules
    text = ("第一章\n\n更多精彩小说请访问：www.fiction.invalid\n\n兑换优惠。\n\n欢迎订阅示例\n\n"
            "https://www.shop.invalid/deal\n\n广告第03条\n\n仍需保留。\n\nwww.shop.invalid.bad\n")
    raw = text.encode()
    decoded = decode_source(SourceSnapshot(Path("合成.txt"), len(raw), sha256(raw).hexdigest(), raw))
    standard = analyze_cleaning(decoded)
    plan = analyze_cleaning(decoded, user_rules=rules)
    custom = [item for item in plan.changes if item.rule_id.startswith("USER-")]
    assert len(custom) == 4
    assert all(item.risk == "review" and not item.default_selected for item in custom)
    assert [item.rule_id for item in plan.changes if not item.rule_id.startswith("USER-")] == [
        item.rule_id for item in standard.changes
    ]
    selection = CleaningSelection(plan)
    assert "兑换优惠" in selection.render()
    selection.select([custom[0].id])
    selection.confirm_review([custom[0].id])
    assert "兑换优惠" not in selection.render()
    save_user_rules(path, rules[1:])
    assert load_user_rules(path) == rules[1:]


@pytest.mark.parametrize("value", ["[", ".*", "(*LIMIT_MATCH=90000)abc", "a\nb"])
def test_invalid_or_empty_matching_regex_is_rejected(value):
    with pytest.raises(UserRuleError):
        compile_user_rules((rule(1, "regex", value),))


def test_backtracking_limit_returns_no_match():
    _, match = compile_user_rules((rule(1, "regex", r"^(a+)+$"),))[0]
    assert match("aaa")
    assert not match("a" * 700 + "!")
