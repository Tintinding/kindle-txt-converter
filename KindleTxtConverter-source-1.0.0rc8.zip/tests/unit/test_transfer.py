from pathlib import Path
from types import SimpleNamespace

import pytest
from PySide6 import QtCore

from kindle_converter.device import transfer


def test_auto_detection_requires_kindle_label_and_documents(tmp_path, monkeypatch):
    root = tmp_path / "Kindle"
    (root / "documents").mkdir(parents=True)

    def volume(name, path):
        return SimpleNamespace(isReady=lambda: True, isReadOnly=lambda: False, displayName=lambda: name,
                               rootPath=lambda: str(path), bytesAvailable=lambda: 12345)

    monkeypatch.setattr(QtCore, "QStorageInfo", SimpleNamespace(mountedVolumes=lambda: [
        volume("KINDLE", root), volume("Kindle 空目录", tmp_path), volume("其他磁盘", root),
    ]))
    device, = transfer.detect_kindles()
    assert device.documents == root / "documents" and device.free_bytes == 12345


def test_copy_commits_verified_content_and_preserves_existing_file(tmp_path):
    source = tmp_path / "试读.azw3"
    content = b"test bytes" * (128 * 1024)
    source.write_bytes(content)
    root = tmp_path / "Kindle"
    documents = root / "documents"
    documents.mkdir(parents=True)
    target = transfer.copy_book(source, root)
    assert target == documents / source.name
    assert target.read_bytes() == content and source.read_bytes() == content
    assert list(documents.iterdir()) == [target]
    with pytest.raises(transfer.TransferError, match="同名"):
        transfer.copy_book(source, documents)
    assert target.read_bytes() == content


def test_copy_refuses_unconfirmed_folder_and_insufficient_space(tmp_path, monkeypatch):
    source = tmp_path / "试读.mobi"
    source.write_bytes(b"test bytes")
    with pytest.raises(transfer.TransferError, match="documents"):
        transfer.copy_book(source, tmp_path)
    documents = tmp_path / "documents"
    documents.mkdir()
    monkeypatch.setattr(transfer, "disk_usage", lambda folder: SimpleNamespace(free=0))
    with pytest.raises(transfer.TransferError, match="空间不足"):
        transfer.copy_book(source, documents)
    assert list(documents.iterdir()) == []


def test_commit_io_error_cleans_partial_file(tmp_path, monkeypatch):
    source = tmp_path / "试读.azw3"
    source.write_bytes(b"temporary copy")
    documents = tmp_path / "documents"
    documents.mkdir()

    def fail(*args):
        raise OSError("模拟拔出")

    monkeypatch.setattr(transfer.os, "rename" if transfer.os.name == "nt" else "link", fail)
    with pytest.raises(transfer.TransferError, match="传输失败"):
        transfer.copy_book(source, documents)
    assert list(documents.iterdir()) == []
    assert source.read_bytes() == b"temporary copy"
