import json

from kindle_converter.main import main


def test_inspect_reports_only_size_and_hash(tmp_path, capsys):
    source = tmp_path / "测试.txt"
    source.write_text("仅供测试的句子", encoding="utf-8")
    assert main(["--inspect", str(source)]) == 0
    report = json.loads(capsys.readouterr().out)
    assert set(report) == {"size_bytes", "sha256"}
    assert report["size_bytes"] == source.stat().st_size
    assert len(report["sha256"]) == 64


def test_inspect_missing_file_returns_failure(tmp_path, capsys):
    assert main(["--inspect", str(tmp_path / "missing.txt")]) == 1
    assert "文件不存在" in json.loads(capsys.readouterr().out)["error"]


def test_detection_reports_metadata_without_text_or_path(tmp_path, capsys):
    source = tmp_path / "私有文件名.txt"
    body = "不能出现在普通诊断里的测试句子\r\n第二段"
    source.write_bytes(body.encode("utf-8-sig"))
    assert main(["--detect-encoding", str(source)]) == 0
    output = capsys.readouterr().out
    report = json.loads(output)
    assert report["encoding"] == "utf-8"
    assert report["bom_bytes"] == 3
    assert report["character_count"] == len(body)
    assert report["requires_confirmation"] is False
    assert len(report["source_sha256"]) == 64
    assert body not in output and "不能出现在" not in output
    assert str(source) not in output and "私有文件名" not in output


def test_detection_accepts_manual_encoding(tmp_path, capsys):
    source = tmp_path / "测试.txt"
    source.write_bytes("手动选择编码".encode("gbk"))
    assert main(["--detect-encoding", str(source), "--encoding", "cp936"]) == 0
    report = json.loads(capsys.readouterr().out)
    assert report["encoding"] == "gbk"
    assert report["confidence"] == "manual"


def test_detection_returns_safe_chinese_error(tmp_path, capsys):
    source = tmp_path / "测试.txt"
    source.write_bytes(b"private text\xff")
    assert main(["--detect-encoding", str(source), "--encoding", "utf-8"]) == 1
    output = capsys.readouterr().out
    assert "无法按" in json.loads(output)["error"]
    assert "private text" not in output


def test_detection_can_save_metadata_report(tmp_path, capsys):
    from kindle_converter.services.paths import application_root
    from uuid import uuid4

    source = tmp_path / "测试.txt"
    source.write_text("独立的诊断样本", encoding="utf-8")
    destination = application_root() / "build" / "reports" / f"encoding-{uuid4().hex}.json"
    try:
        assert main(["--detect-encoding", str(source), "--report", str(destination)]) == 0
        report = json.loads(destination.read_text(encoding="utf-8"))
        assert report == json.loads(capsys.readouterr().out)
        assert "独立的诊断样本" not in destination.read_text(encoding="utf-8")
    finally:
        destination.unlink(missing_ok=True)
