"""疑似推广的独立标注、确认、保留和恢复检查。"""

from collections import Counter
from dataclasses import replace
import json
from pathlib import Path

import pytest

from kindle_converter.core.cleaning import CleaningError, analyze_cleaning, load_rules
from kindle_converter.core.encoding import decode_source
from kindle_converter.core.source import read_source


ROOT = Path(__file__).resolve().parents[2]
CASES = json.loads((ROOT / 'tests/fixtures/cleaning_promotion_cases.json').read_text(encoding='utf-8'))['cases']
PROMOTION_RULE = 'STD-017'


def make_plan(tmp_path, text, codec='utf-8', bom=b''):
    path = tmp_path / '合成疑似推广.txt'
    path.write_bytes(bom + text.encode(codec))
    source = read_source(path)
    decoded = decode_source(source, encoding=codec)
    plan = analyze_cleaning(decoded, encoding_confirmed=True)
    return source, decoded, plan


@pytest.mark.parametrize('case', CASES, ids=[case['id'] for case in CASES])
def test_independently_labeled_suspected_promotion_cases(tmp_path, case):
    source, decoded, plan = make_plan(tmp_path, case['text'])
    default = Counter(change.rule_id for change in plan.changes if change.default_selected)
    review = Counter(change.rule_id for change in plan.changes if change.risk == 'review')
    assert default == Counter(case['expected_default_rule_ids'])
    assert review == Counter(case['expected_review_rule_ids'])
    assert len(plan.changes) == sum(default.values()) + sum(review.values())
    if not default:
        assert plan.render(plan.default_selected_ids) == case['text']

    selected = tuple(change.id for change in plan.changes)
    confirmed = tuple(change.id for change in plan.changes if change.risk == 'review')
    if confirmed:
        with pytest.raises(CleaningError):
            plan.render(selected)
    assert plan.render(selected, confirmed_review_ids=confirmed) == case['expected_applied_text']
    assert plan.render() == case['text']
    assert source.path.read_bytes() == source.content

    for change in plan.changes:
        assert change.original == decoded.text[change.start:change.end]
        assert source.content[change.byte_start:change.byte_end] == change.original.encode(decoded.encoding)
        if change.rule_id == PROMOTION_RULE:
            assert change.category == 'C13'
            assert change.risk == 'review' and not change.default_selected
            assert change.replacement == ''
    assert all(first.end <= second.start for first, second in zip(plan.changes, plan.changes[1:]))


@pytest.mark.parametrize('codec,bom', [('utf-16-be', b'\xfe\xff'), ('gb18030', b'')])
def test_promotion_positions_confirmation_and_individual_restore(tmp_path, codec, bom):
    intro = '前文😀𠀀。\r\n\r\n'
    first_row = '　打开链接，领取阅读礼包：https://fiction.invalid/pack\r\n'
    second_row = '点击链接领取限时福利：https://fiction.invalid/bonus'
    text = intro + first_row + '\r\n' + second_row
    source, decoded, plan = make_plan(tmp_path, text, codec, bom)
    first, second = plan.changes
    assert (first.rule_id, second.rule_id) == (PROMOTION_RULE, PROMOTION_RULE)
    assert (first.line_number, second.line_number) == (3, 5)
    assert (first.original, second.original) == (first_row, second_row)
    for change in (first, second):
        assert change.byte_start == decoded.byte_offset(change.start)
        assert change.byte_end == decoded.byte_offset(change.end)
        assert source.content[change.byte_start:change.byte_end] == change.original.encode(codec)

    selected = (first.id, second.id)
    assert plan.default_selected_ids == ()
    with pytest.raises(CleaningError):
        plan.render(selected, confirmed_review_ids=(first.id,))
    assert plan.render((first.id,), confirmed_review_ids=(first.id,)) == intro + '\r\n' + second_row
    assert plan.render((second.id,), confirmed_review_ids=(second.id,)) == intro + first_row + '\r\n'
    assert plan.render(selected, confirmed_review_ids=selected) == intro + '\r\n'
    assert plan.render() == text
    assert source.path.read_bytes() == bom + text.encode(codec)


def test_disabling_suspected_promotion_preserves_existing_link_rules(tmp_path):
    case = next(case for case in CASES if case['id'] == 'PROM-004')
    _, decoded, _ = make_plan(tmp_path, case['text'])
    rules = load_rules()
    disabled = replace(rules, rules=tuple(
        replace(rule, default_enabled=False) if rule.id == PROMOTION_RULE else rule
        for rule in rules.rules
    ))
    plan = analyze_cleaning(decoded, rules=disabled)
    explicit, homepage = plan.changes
    assert (explicit.rule_id, homepage.rule_id) == ('STD-014', 'STD-015')
    assert plan.default_selected_ids == (explicit.id,)
    assert plan.render(plan.default_selected_ids) == (
        '\n点击下方链接，领取专属优惠：https://fiction.invalid/bonus\n\nhttp://xiaoshuotxt.com/\n'
    )
    assert plan.render((explicit.id, homepage.id), confirmed_review_ids=(homepage.id,)) == (
        '\n点击下方链接，领取专属优惠：https://fiction.invalid/bonus\n\n'
    )


@pytest.mark.parametrize('case_id', ['PROM-023', 'PROM-024', 'PROM-025', 'PROM-027'])
def test_promotion_context_protection_when_other_rules_are_disabled(tmp_path, case_id):
    case = next(case for case in CASES if case['id'] == case_id)
    _, decoded, _ = make_plan(tmp_path, case['text'])
    rules = load_rules()
    only_promotion = replace(rules, rules=tuple(
        replace(rule, default_enabled=rule.id == PROMOTION_RULE)
        for rule in rules.rules
    ))
    plan = analyze_cleaning(decoded, rules=only_promotion)
    assert [change.rule_id for change in plan.changes] == case['expected_review_rule_ids']
    selected = tuple(change.id for change in plan.changes)
    assert plan.render(selected, confirmed_review_ids=selected) == case['expected_applied_text']


def test_promotion_preview_keeps_context_and_url_out_of_default_metadata(tmp_path):
    private = 'PRIVATE_PROMOTION_合成前文。'
    promo = '访问链接即可查看限时优惠：https://fiction.invalid/secret-offer\n'
    source, _, plan = make_plan(tmp_path, private + '\n\n' + promo)
    change, = plan.changes
    preview = plan.preview(change.id)
    assert preview.before == promo and preview.after == ''
    assert private in preview.context_before
    for output in (repr((plan, change, preview)), json.dumps(plan.summary(), ensure_ascii=False)):
        assert private not in output and 'secret-offer' not in output
        assert str(source.path) not in output


def test_programmatic_promotion_rules_cannot_bypass_review(tmp_path):
    promo = '点击链接领取新人福利：https://fiction.invalid/welcome\n'
    _, decoded, _ = make_plan(tmp_path, promo)
    rules = load_rules()
    unsafe = replace(rules, rules=tuple(
        replace(rule, risk='low', default_selected=True) if rule.id == PROMOTION_RULE else rule
        for rule in rules.rules
    ))
    plan = analyze_cleaning(decoded, rules=unsafe)
    change, = plan.changes
    assert change.risk == 'review' and not change.default_selected
    assert plan.default_selected_ids == ()
    assert plan.render(plan.default_selected_ids) == promo
    with pytest.raises(CleaningError):
        plan.render((change.id,))
    assert plan.render((change.id,), confirmed_review_ids=(change.id,)) == ''


@pytest.mark.parametrize('fault', [
    'low_risk', 'default_selected', 'wrong_category', 'wrong_kind',
    'missing_actions', 'missing_offers', 'empty_actions', 'empty_offers',
])
def test_promotion_configuration_requires_review_and_both_phrase_groups(tmp_path, fault):
    payload = json.loads((ROOT / 'rules/standard.json').read_text(encoding='utf-8'))
    rule = next(rule for rule in payload['rules'] if rule['id'] == PROMOTION_RULE)
    if fault == 'low_risk':
        rule['risk'] = 'low'
    elif fault == 'default_selected':
        rule['default_selected'] = True
    elif fault == 'wrong_category':
        rule['category'] = 'C02'
    elif fault == 'wrong_kind':
        rule['match'] = {'kind': 'literal_line', 'values': ['点击链接领取新人福利']}
    elif fault == 'missing_actions':
        del rule['match']['calls_to_action']
    elif fault == 'missing_offers':
        del rule['match']['offers']
    elif fault == 'empty_actions':
        rule['match']['calls_to_action'] = []
    else:
        rule['match']['offers'] = []
    path = tmp_path / '合成疑似推广规则.json'
    path.write_text(json.dumps(payload, ensure_ascii=False), encoding='utf-8')
    with pytest.raises(CleaningError) as failure:
        load_rules(path)
    assert str(failure.value) and str(path) not in str(failure.value)
