"""独立推广链接的人工标注、正文保护、确认与恢复。"""

from collections import Counter
from dataclasses import replace
import json
from pathlib import Path

import pytest

from kindle_converter.core.cleaning import CleaningError, analyze_cleaning, load_rules
from kindle_converter.core.encoding import decode_source
from kindle_converter.core.source import read_source


ROOT = Path(__file__).resolve().parents[2]
CASES = json.loads((ROOT / 'tests/fixtures/cleaning_link_cases.json').read_text(encoding='utf-8'))['cases']


def make_plan(tmp_path, text, codec='utf-8', bom=b''):
    path = tmp_path / '独立合成推广链接.txt'
    path.write_bytes(bom + text.encode(codec))
    source = read_source(path)
    decoded = decode_source(source, encoding=codec)
    return source, decoded, analyze_cleaning(decoded, encoding_confirmed=True)


@pytest.mark.parametrize('case', CASES, ids=[case['id'] for case in CASES])
def test_independently_labeled_link_cases(tmp_path, case):
    source, decoded, plan = make_plan(tmp_path, case['text'])
    default = Counter(change.rule_id for change in plan.changes if change.default_selected)
    review = Counter(change.rule_id for change in plan.changes if change.risk == 'review')
    assert default == Counter(case['expected_default_rule_ids'])
    assert review == Counter(case['expected_review_rule_ids'])
    assert len(plan.changes) == sum(default.values()) + sum(review.values())

    all_ids = tuple(change.id for change in plan.changes)
    review_ids = tuple(change.id for change in plan.changes if change.risk == 'review')
    if review_ids:
        with pytest.raises(CleaningError):
            plan.render(all_ids)
    assert plan.render(all_ids, confirmed_review_ids=review_ids) == case['expected_applied_text']
    assert plan.render() == case['text']
    assert source.path.read_bytes() == source.content

    for change in plan.changes:
        assert change.original == decoded.text[change.start:change.end]
        assert source.content[change.byte_start:change.byte_end] == change.original.encode(decoded.encoding)
        if change.rule_id in {'STD-014', 'STD-015'}:
            assert change.category == 'C01'
            assert change.replacement == ''
    assert all(a.end <= b.start for a, b in zip(plan.changes, plan.changes[1:]))


@pytest.mark.parametrize('codec,bom', [('utf-16-be', b'\xfe\xff'), ('gb18030', b'')])
def test_link_positions_and_independent_restore_after_multibyte_text(tmp_path, codec, bom):
    prefix = '合成正文😀𠀀。\r\n\r\n'
    explicit_row = '　小说推广链接：https://fiction.invalid/a\r\n'
    homepage_row = 'https://xiaoshuotxt.com/\r'
    text = prefix + explicit_row + '\r\n' + homepage_row
    source, decoded, plan = make_plan(tmp_path, text, codec, bom)
    default, review = plan.changes
    assert (default.rule_id, review.rule_id) == ('STD-014', 'STD-015')
    assert (default.line_number, review.line_number) == (3, 5)
    assert (default.original, review.original) == (explicit_row, homepage_row)
    for change in (default, review):
        assert change.byte_start == decoded.byte_offset(change.start)
        assert change.byte_end == decoded.byte_offset(change.end)
        assert source.content[change.byte_start:change.byte_end] == change.original.encode(codec)

    both_ids = (default.id, review.id)
    assert plan.default_selected_ids == (default.id,)
    assert plan.render(plan.default_selected_ids) == prefix + '\r\n' + homepage_row
    assert plan.render(both_ids, confirmed_review_ids=(review.id,)) == prefix + '\r\n'
    assert plan.render((review.id,), confirmed_review_ids=(review.id,)) == prefix + explicit_row + '\r\n'
    assert plan.render(()) == text


def test_link_preview_keeps_url_and_body_out_of_default_metadata(tmp_path):
    secret = 'PRIVATE_LINK_合成正文'
    row = '小说广告链接：https://fiction.invalid/private-source-token\n'
    source, _, plan = make_plan(tmp_path, secret + '\n\n' + row)
    change, = plan.changes
    preview = plan.preview(change.id)
    assert preview.before == row and preview.after == ''
    assert secret in preview.context_before
    for output in (repr((plan, change, preview)), json.dumps(plan.summary(), ensure_ascii=False)):
        assert secret not in output
        assert 'private-source-token' not in output
        assert str(source.path) not in output


@pytest.mark.parametrize('case_id', ['LNK-023', 'LNK-024'])
def test_code_context_is_protected_with_html_rule_disabled(tmp_path, case_id):
    case = next(case for case in CASES if case['id'] == case_id)
    _, decoded, _ = make_plan(tmp_path, case['text'])
    rules = load_rules()
    disabled = replace(rules, rules=tuple(
        replace(rule, default_enabled=False) if rule.id == 'STD-011' else rule
        for rule in rules.rules
    ))
    plan = analyze_cleaning(decoded, rules=disabled)
    assert [change.rule_id for change in plan.changes] == case['expected_default_rule_ids']
    assert plan.render(plan.default_selected_ids) == case['expected_applied_text']


@pytest.mark.parametrize('fault', ['low_risk', 'default_selected', 'wrong_category', 'bad_domain', 'www_domain'])
def test_homepage_config_enforces_domain_shape_and_confirmation(tmp_path, fault):
    payload = json.loads((ROOT / 'rules/standard.json').read_text(encoding='utf-8'))
    rule = next(rule for rule in payload['rules'] if rule['id'] == 'STD-015')
    if fault == 'low_risk':
        rule['risk'] = 'low'
    elif fault == 'default_selected':
        rule['default_selected'] = True
    elif fault == 'wrong_category':
        rule['category'] = 'C02'
    elif fault == 'bad_domain':
        rule['match']['domains'] = ['https://xiaoshuotxt.com/']
    else:
        rule['match']['domains'] = ['www.xiaoshuotxt.com']
    path = tmp_path / '合成主页规则.json'
    path.write_text(json.dumps(payload, ensure_ascii=False), encoding='utf-8')
    with pytest.raises(CleaningError) as failure:
        load_rules(path)
    assert str(failure.value) and str(path) not in str(failure.value)
