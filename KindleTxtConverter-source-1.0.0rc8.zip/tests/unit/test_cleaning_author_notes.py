"""疑似作者附言的独立标注、正文保护、确认及恢复检查。"""

from collections import Counter
from dataclasses import replace
import json
from pathlib import Path

import pytest

from kindle_converter.core.cleaning import CleaningError, analyze_cleaning, load_rules
from kindle_converter.core.encoding import decode_source
from kindle_converter.core.source import read_source


ROOT = Path(__file__).resolve().parents[2]
CASES = json.loads((ROOT / 'tests/fixtures/cleaning_author_cases.json').read_text(encoding='utf-8'))['cases']


def make_plan(tmp_path, text, codec='utf-8', bom=b''):
    path = tmp_path / '合成作者附言.txt'
    path.write_bytes(bom + text.encode(codec))
    source = read_source(path)
    decoded = decode_source(source, encoding=codec)
    plan = analyze_cleaning(decoded, encoding_confirmed=True)
    return source, decoded, plan


@pytest.mark.parametrize('case', CASES, ids=[case['id'] for case in CASES])
def test_independently_labeled_author_note_cases(tmp_path, case):
    source, decoded, plan = make_plan(tmp_path, case['text'])
    default = Counter(change.rule_id for change in plan.changes if change.default_selected)
    review = Counter(change.rule_id for change in plan.changes if change.risk == 'review')
    assert default == Counter(case['expected_default_rule_ids'])
    assert review == Counter(case['expected_review_rule_ids'])
    assert len(plan.changes) == sum(default.values()) + sum(review.values())
    assert plan.render(plan.default_selected_ids) == case['text']

    all_ids = tuple(change.id for change in plan.changes)
    review_ids = tuple(change.id for change in plan.changes if change.risk == 'review')
    if review_ids:
        with pytest.raises(CleaningError):
            plan.render(all_ids)
    assert plan.render(all_ids, confirmed_review_ids=review_ids) == case['expected_applied_text']
    assert plan.render() == case['text']
    assert source.path.read_bytes() == source.content

    for change in plan.changes:
        assert change.original == decoded.text[change.start:change.end]
        assert source.content[change.byte_start:change.byte_end] == change.original.encode(decoded.encoding)
        if change.rule_id == 'STD-016':
            assert change.category == 'C11'
            assert change.risk == 'review' and not change.default_selected
            assert change.replacement == ''
    assert all(a.end <= b.start for a, b in zip(plan.changes, plan.changes[1:]))


@pytest.mark.parametrize('codec,bom', [('utf-16-be', b'\xfe\xff'), ('gb18030', b'')])
def test_author_note_positions_confirmation_and_individual_restore(tmp_path, codec, bom):
    prefix = '前文😀𠀀。\r\n\r\n'
    first_row = '　作者附言：下次更新见。\r\n'
    between = '\r\n作者的话：\r\n\r\n'
    second_row = '感谢大家的支持！'
    text = prefix + first_row + between + second_row
    source, decoded, plan = make_plan(tmp_path, text, codec, bom)
    first, second = plan.changes
    assert (first.rule_id, second.rule_id) == ('STD-016', 'STD-016')
    assert (first.line_number, second.line_number) == (3, 7)
    assert (first.original, second.original) == (first_row, second_row)
    for change in (first, second):
        assert change.byte_start == decoded.byte_offset(change.start)
        assert change.byte_end == decoded.byte_offset(change.end)
        assert source.content[change.byte_start:change.byte_end] == change.original.encode(codec)

    both_ids = (first.id, second.id)
    assert plan.default_selected_ids == ()
    with pytest.raises(CleaningError):
        plan.render(both_ids, confirmed_review_ids=(first.id,))
    assert plan.render((first.id,), confirmed_review_ids=(first.id,)) == prefix + between + second_row
    assert plan.render((second.id,), confirmed_review_ids=(second.id,)) == prefix + first_row + between
    assert plan.render(both_ids, confirmed_review_ids=both_ids) == prefix + between
    assert plan.render() == text
    assert source.path.read_bytes() == bom + text.encode(codec)


def test_disabling_author_note_rule_preserves_existing_reader_request(tmp_path):
    case = next(case for case in CASES if case['id'] == 'AUT-007')
    _, decoded, _ = make_plan(tmp_path, case['text'])
    rules = load_rules()
    disabled = replace(rules, rules=tuple(
        replace(rule, default_enabled=False) if rule.id == 'STD-016' else rule
        for rule in rules.rules
    ))
    plan = analyze_cleaning(decoded, rules=disabled)
    change, = plan.changes
    assert change.rule_id == 'STD-013'
    assert plan.render((change.id,), confirmed_review_ids=(change.id,)) == '作者的话：感谢大家的支持！\n\n'


@pytest.mark.parametrize('case_id', ['AUT-019', 'AUT-020'])
def test_author_note_code_protection_when_other_rules_are_disabled(tmp_path, case_id):
    case = next(case for case in CASES if case['id'] == case_id)
    _, decoded, _ = make_plan(tmp_path, case['text'])
    rules = load_rules()
    author_only = replace(rules, rules=tuple(
        replace(rule, default_enabled=rule.id == 'STD-016')
        for rule in rules.rules
    ))
    plan = analyze_cleaning(decoded, rules=author_only)
    assert [change.rule_id for change in plan.changes] == case['expected_review_rule_ids']
    selected = tuple(change.id for change in plan.changes)
    assert plan.render(selected, confirmed_review_ids=selected) == case['expected_applied_text']


def test_author_note_preview_does_not_expose_note_in_default_metadata(tmp_path):
    private = 'PRIVATE_NOTE_合成前文。'
    note = '作者附言：感谢各位读者的支持。\n'
    source, _, plan = make_plan(tmp_path, private + '\n\n' + note)
    change, = plan.changes
    preview = plan.preview(change.id)
    assert preview.before == note and preview.after == ''
    assert private in preview.context_before
    for output in (repr((plan, change, preview)), json.dumps(plan.summary(), ensure_ascii=False)):
        assert private not in output and note.strip() not in output
        assert str(source.path) not in output


@pytest.mark.parametrize('fault', [
    'low_risk', 'default_selected', 'wrong_category', 'wrong_kind', 'missing_headers', 'missing_values',
])
def test_author_note_configuration_requires_review_and_both_match_signals(tmp_path, fault):
    payload = json.loads((ROOT / 'rules/standard.json').read_text(encoding='utf-8'))
    rule = next(rule for rule in payload['rules'] if rule['id'] == 'STD-016')
    if fault == 'low_risk':
        rule['risk'] = 'low'
    elif fault == 'default_selected':
        rule['default_selected'] = True
    elif fault == 'wrong_category':
        rule['category'] = 'C02'
    elif fault == 'wrong_kind':
        rule['match'] = {'kind': 'literal_line', 'values': ['感谢大家的支持！']}
    elif fault == 'missing_headers':
        del rule['match']['headers']
    else:
        del rule['match']['values']
    path = tmp_path / '合成附言规则.json'
    path.write_text(json.dumps(payload, ensure_ascii=False), encoding='utf-8')
    with pytest.raises(CleaningError) as failure:
        load_rules(path)
    assert str(failure.value) and str(path) not in str(failure.value)
