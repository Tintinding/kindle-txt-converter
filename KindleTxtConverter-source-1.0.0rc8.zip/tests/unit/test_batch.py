from kindle_converter.converter.batch import batch_jobs, run_batch
from kindle_converter.converter.calibre import ConversionControl, ConversionError


def test_batch_names_avoid_existing_output_and_duplicate_source_paths(tmp_path):
    output = tmp_path / "输出"
    output.mkdir()
    previous = output / "同名.azw3"
    previous.write_bytes(b"existing")
    first = tmp_path / "甲/同名.txt"
    second = tmp_path / "乙/同名.TXT"
    jobs = batch_jobs([first, first, second, tmp_path / "图片.png"], output, "azw3")
    assert [job.output.name for job in jobs] == ["同名 (2).azw3", "同名 (3).azw3"]
    assert previous.read_bytes() == b"existing"


def test_batch_continues_after_errors_and_skips_pending_review_and_cancelled_rows(tmp_path):
    empty = tmp_path / "空文件.txt"
    empty.write_bytes(b"")
    uncertain = tmp_path / "待确认.txt"
    uncertain.write_bytes(b"ASCII body.")
    cancelled = tmp_path / "取消.txt"
    cancelled.write_bytes("正文。".encode())
    valid = tmp_path / "正常.txt"
    text = ("更多精彩小说请访问：www.fiction.invalid\n\n"
            "本书下载于：https://source.invalid/book\n\n保留的正文。")
    valid.write_bytes(text.encode())
    jobs = batch_jobs([empty, uncertain, cancelled, valid], tmp_path / "outputs", "azw3")
    controls = tuple(ConversionControl() for _ in jobs)
    controls[2].cancel()
    events = {}
    inspected = []

    class Engine:
        def convert(self, source, output, *, cleaning, control, progress):
            inspected.append(source)
            progress(2, "正在转换")
            result = cleaning.apply()
            assert result.log_metadata()["applied_rule_counts"] == {"STD-001": 1}
            assert "source.invalid" in result.text and "fiction.invalid" not in result.text
            control.commit(lambda: None)

    run_batch(Engine(), jobs, controls, lambda row, state, detail: events.update({row: (state, detail)}), str)
    assert [events[row][0] for row in range(4)] == ["失败", "失败", "已取消", "成功"]
    assert "确认" in events[1][1]
    assert inspected == [valid]
    assert valid.read_bytes() == text.encode()


def test_engine_failure_does_not_stop_following_job(tmp_path):
    sources = [tmp_path / f"小说{index}.txt" for index in range(2)]
    for source in sources:
        source.write_bytes("合成故事。".encode())
    jobs = batch_jobs(sources, tmp_path, "mobi")
    outcomes = {}

    class Engine:
        def convert(self, source, output, **kwargs):
            if source == sources[0]:
                raise ConversionError("测试转换失败")

    run_batch(Engine(), jobs, (ConversionControl(), ConversionControl()),
              lambda row, state, detail: outcomes.update({row: state}), str)
    assert outcomes == {0: "失败", 1: "成功"}
