"""TASK-005 基础规则与安全契约，使用人工标注的合成文本。"""

from collections import Counter
from copy import deepcopy
from dataclasses import replace
import json
from pathlib import Path

import pytest

from kindle_converter.core.cleaning import CleaningError, analyze_cleaning, load_rules
from kindle_converter.core.encoding import decode_source
from kindle_converter.core.source import read_source


PROJECT_ROOT = Path(__file__).resolve().parents[2]
CASE_PATH = PROJECT_ROOT / 'tests' / 'fixtures' / 'cleaning_cases.json'
RULE_PATH = PROJECT_ROOT / 'rules' / 'standard.json'
CASES = [
    *json.loads(CASE_PATH.read_text(encoding='utf-8'))['cases'],
    *json.loads(CASE_PATH.with_name('cleaning_domain_cases.json').read_text(encoding='utf-8'))['cases'],
]


def make_plan(tmp_path, text, *, codec='utf-8', bom=b''):
    path = tmp_path / '合成清理样本.txt'
    path.write_bytes(bom + text.encode(codec))
    source = read_source(path)
    decoded = decode_source(source, encoding=codec)
    return source, decoded, analyze_cleaning(decoded)


@pytest.mark.parametrize('case', CASES, ids=[case['id'] for case in CASES])
def test_independently_labeled_cleaning_cases(tmp_path, case):
    source, decoded, plan = make_plan(tmp_path, case['text'])
    before_mtime = source.path.stat().st_mtime_ns
    assert isinstance(plan.changes, tuple)
    assert isinstance(plan.default_selected_ids, tuple)
    assert plan.source_sha256 == source.sha256
    assert Counter(change.rule_id for change in plan.changes if change.default_selected) == Counter(case['expected_default_rule_ids'])
    assert Counter(change.rule_id for change in plan.changes if change.risk == 'review') == Counter(case['expected_review_rule_ids'])
    assert len(plan.changes) == len(case['expected_default_rule_ids']) + len(case['expected_review_rule_ids'])
    assert len({change.id for change in plan.changes}) == len(plan.changes)
    for change in plan.changes:
        assert change.risk in {'low', 'review'}
        assert not change.default_selected or change.risk == 'low'
        assert change.original == decoded.text[change.start:change.end]
        assert change.replacement == ''
        assert change.byte_start == decoded.byte_offset(change.start)
        assert change.byte_end == decoded.byte_offset(change.end)
    # 默认建议只是选择信息；调用者不传 IDs 时，不能产生隐式删除。
    assert plan.render() == case['text']
    assert plan.render(plan.default_selected_ids) == case['expected_default_text']
    assert plan.render(()) == case['text']
    review_ids = tuple(change.id for change in plan.changes if change.risk == 'review')
    if review_ids:
        with pytest.raises(CleaningError):
            plan.render(review_ids)
        assert plan.render(review_ids, confirmed_review_ids=review_ids) == case['expected_review_text']
        assert plan.render() == case['text']
    summary = plan.summary()
    assert summary['suggestion_count'] == len(plan.changes)
    assert summary['default_selected_count'] == len(case['expected_default_rule_ids'])
    assert summary['review_required_count'] == len(case['expected_review_rule_ids'])
    assert source.path.read_bytes() == source.content
    assert source.path.stat().st_mtime_ns == before_mtime


def test_selecting_and_restoring_individual_changes_uses_immutable_original(tmp_path):
    text = '更多精彩小说，请访问：https://one.invalid/book\n\n正文甲。\n\n更多精彩小说，请下载阅读APP：https://two.invalid/app\n\n正文乙。\n'
    source, _, plan = make_plan(tmp_path, text)
    first, second = plan.changes
    assert plan.render((first.id,)) == '\n正文甲。\n\n更多精彩小说，请下载阅读APP：https://two.invalid/app\n\n正文乙。\n'
    assert plan.render((second.id,)) == '更多精彩小说，请访问：https://one.invalid/book\n\n正文甲。\n\n\n正文乙。\n'
    assert plan.render(plan.default_selected_ids) == '\n正文甲。\n\n\n正文乙。\n'
    assert plan.render() == text
    assert source.path.read_bytes() == source.content


def test_utf16_bom_emoji_and_original_crlf_byte_spans(tmp_path):
    text = '第一章 😀\r\n\r\n更多精彩小说，请访问：https://fiction.invalid/book\r\n\r\n保留的正文𠀀。\r\n'
    source, decoded, plan = make_plan(tmp_path, text, codec='utf-16-le', bom=b'\xff\xfe')
    change, = plan.changes
    assert change.original == '更多精彩小说，请访问：https://fiction.invalid/book\r\n'
    assert change.byte_start == 2 + len(text[:change.start].encode('utf-16-le'))
    assert change.byte_end == 2 + len(text[:change.end].encode('utf-16-le'))
    assert source.content[change.byte_start:change.byte_end] == change.original.encode('utf-16-le')
    assert plan.render(plan.default_selected_ids) == '第一章 😀\r\n\r\n\r\n保留的正文𠀀。\r\n'
    assert plan.render() == decoded.text == text
    assert source.path.read_bytes() == source.content


@pytest.mark.parametrize('codec,bom', [('utf-16-be', b'\xfe\xff'), ('gb18030', b'')])
def test_domain_migration_keeps_original_byte_spans_and_restores_each_notice(tmp_path, codec, bom):
    prefix = '木桥下有一盏灯😀𠀀。\r\n\r\n'
    explicit_notice = '本站启用新域名，请收藏: https://bridge.invalid/novels\r\n'
    introduction = '\r\n有人留下了一行旧字：\n\n'
    quoted_notice = '本站网址已更新，请收藏新网址：https://plaque.invalid/\r'
    suffix = '风又响了。'
    text = prefix + explicit_notice + introduction + quoted_notice + suffix
    source, _, plan = make_plan(tmp_path, text, codec=codec, bom=bom)
    explicit, quoted = plan.changes
    assert (explicit.rule_id, quoted.rule_id) == ('STD-003', 'STD-003')
    assert (explicit.original, quoted.original) == (explicit_notice, quoted_notice)
    assert explicit.byte_start == len(bom) + len(prefix.encode(codec))
    assert quoted.byte_start == len(bom) + len((prefix + explicit_notice + introduction).encode(codec))
    for change in plan.changes:
        assert source.content[change.byte_start:change.byte_end] == change.original.encode(codec)
        assert plan.preview(change.id).before == change.original
    assert plan.default_selected_ids == (explicit.id,)
    assert plan.render(plan.default_selected_ids) == prefix + introduction + quoted_notice + suffix
    with pytest.raises(CleaningError, match='确认'):
        plan.render((explicit.id, quoted.id))
    assert plan.render((explicit.id, quoted.id), confirmed_review_ids=(quoted.id,)) == prefix + introduction + suffix
    assert plan.render((quoted.id,), confirmed_review_ids=(quoted.id,)) == prefix + explicit_notice + introduction + suffix
    assert bom + plan.render().encode(codec) == source.content


def test_selection_ids_cannot_be_reused_for_same_length_different_source(tmp_path):
    text_a = '更多精彩小说，请访问：https://a.invalid/books\n\n正文。\n'
    text_b = '更多精彩小说，请访问：https://b.invalid/books\n\n正文。\n'
    assert len(text_a) == len(text_b)
    _, _, plan_a = make_plan(tmp_path, text_a)
    _, _, plan_b = make_plan(tmp_path, text_b)
    assert plan_a.source_sha256 != plan_b.source_sha256
    assert plan_a.default_selected_ids != plan_b.default_selected_ids
    with pytest.raises(CleaningError):
        plan_b.render(plan_a.default_selected_ids)
    assert plan_b.render() == text_b
    assert plan_a.render() == text_a


def test_uncertain_encoding_requires_explicit_confirmation_before_analysis(tmp_path):
    source, decoded, _ = make_plan(tmp_path, CASES[0]['text'])
    uncertain = replace(decoded, requires_confirmation=True, warnings=('需要检查编码。',))
    with pytest.raises(CleaningError):
        analyze_cleaning(uncertain)
    plan = analyze_cleaning(uncertain, encoding_confirmed=True)
    assert tuple(change.rule_id for change in plan.changes) == ('STD-001',)
    assert plan.source_sha256 == source.sha256
    assert plan.render() == decoded.text


@pytest.mark.parametrize('selection,confirmation', [
    (('UNKNOWN-ID',), ()),
    ((), ('UNKNOWN-ID',)),
])
def test_unknown_change_ids_are_rejected(tmp_path, selection, confirmation):
    _, _, plan = make_plan(tmp_path, CASES[0]['text'])
    with pytest.raises(CleaningError):
        plan.render(selection, confirmed_review_ids=confirmation)


def test_preview_is_explicit_bounded_and_hidden_from_repr(tmp_path):
    _, _, plan = make_plan(tmp_path, CASES[0]['text'])
    change, = plan.changes
    preview = plan.preview(change.id, context_characters=5)
    assert preview.before == change.original
    assert preview.after == ''
    assert len(preview.context_before) <= 5
    assert len(preview.context_after) <= 5
    assert preview.context_before == CASES[0]['text'][change.start - 5:change.start]
    assert preview.context_after == CASES[0]['text'][change.end:change.end + 5]
    assert change.original not in repr(preview)
    assert 'https://' not in repr(preview)


def test_metadata_summary_and_reprs_do_not_expose_source_or_url(tmp_path):
    secret = 'VERY_PRIVATE_合成正文内容_请勿记录'
    text = secret + '\n\n更多精彩小说，请访问：https://private.invalid/hidden-book\n\n结尾。\n'
    source, _, plan = make_plan(tmp_path, text)
    change, = plan.changes
    preview = plan.preview(change.id)
    metadata = json.dumps(plan.summary(), ensure_ascii=False)
    representations = repr((plan, change, preview))
    for output in (metadata, representations):
        assert secret not in output
        assert text not in output
        assert 'private.invalid' not in output
        assert str(source.path) not in output
        assert '更多精彩小说，请访问：' not in output


def test_rule_configuration_references_actual_annotated_cases():
    cases = {case['id']: case for case in CASES}
    source_cases = json.loads((CASE_PATH.parent / 'cleaning_source_cases.json').read_text(encoding='utf-8'))['cases']
    cases.update({case['id']: case for case in source_cases})
    blank_cases = json.loads((CASE_PATH.parent / 'cleaning_blank_cases.json').read_text(encoding='utf-8'))['cases']
    cases.update({case['id']: case for case in blank_cases})
    heading_cases = json.loads((CASE_PATH.parent / 'cleaning_heading_cases.json').read_text(encoding='utf-8'))['cases']
    cases.update({case['id']: case for case in heading_cases})
    html_cases = json.loads((CASE_PATH.parent / 'cleaning_html_cases.json').read_text(encoding='utf-8'))['cases']
    cases.update({case['id']: case for case in html_cases})
    control_cases = json.loads((CASE_PATH.parent / 'cleaning_control_cases.json').read_text(encoding='utf-8'))['cases']
    cases.update({case['id']: case for case in control_cases})
    request_cases = json.loads((CASE_PATH.parent / 'cleaning_request_cases.json').read_text(encoding='utf-8'))['cases']
    cases.update({case['id']: case for case in request_cases})
    link_cases = json.loads((CASE_PATH.parent / 'cleaning_link_cases.json').read_text(encoding='utf-8'))['cases']
    cases.update({case['id']: case for case in link_cases})
    author_cases = json.loads((CASE_PATH.parent / 'cleaning_author_cases.json').read_text(encoding='utf-8'))['cases']
    cases.update({case['id']: case for case in author_cases})
    promotion_cases = json.loads((CASE_PATH.parent / 'cleaning_promotion_cases.json').read_text(encoding='utf-8'))['cases']
    cases.update({case['id']: case for case in promotion_cases})
    variant_cases = json.loads((CASE_PATH.parent / 'cleaning_promotion_variant_cases.json').read_text(encoding='utf-8'))['cases']
    cases.update({case['id']: case for case in variant_cases})
    app_cases = json.loads((CASE_PATH.parent / 'cleaning_app_cases.json').read_text(encoding='utf-8'))['cases']
    cases.update({case['id']: case for case in app_cases})
    watermark_cases = json.loads((CASE_PATH.parent / 'cleaning_watermark_cases.json').read_text(encoding='utf-8'))['cases']
    cases.update({case['id']: case for case in watermark_cases})
    rules = load_rules()
    assert {rule.id for rule in rules.rules} == {
        'STD-001', 'STD-002', 'STD-003', 'STD-004', 'STD-005', 'STD-006', 'STD-007',
        'STD-008', 'STD-009', 'STD-010', 'STD-011', 'STD-012', 'STD-013',
        'STD-014', 'STD-015', 'STD-016', 'STD-017', 'STD-018', 'STD-019', 'STD-020',
    }
    for rule in rules.rules:
        assert rule.test_case_ids
        assert set(rule.test_case_ids) <= cases.keys()
        assert any(rule.id in cases[identifier]['expected_default_rule_ids'] + cases[identifier]['expected_review_rule_ids'] for identifier in rule.test_case_ids)


@pytest.mark.parametrize('fault', ['duplicate_id', 'missing_required_field', 'review_default_selected'])
def test_invalid_rule_configuration_is_rejected_without_path_leak(tmp_path, fault):
    payload = deepcopy(json.loads(RULE_PATH.read_text(encoding='utf-8')))
    if fault == 'duplicate_id':
        payload['rules'].append(deepcopy(payload['rules'][0]))
    elif fault == 'missing_required_field':
        del payload['rules'][0]['risk']
    else:
        payload['rules'][-1]['risk'] = 'review'
        payload['rules'][-1]['default_selected'] = True
    path = tmp_path / '隐私规则配置.json'
    path.write_text(json.dumps(payload, ensure_ascii=False), encoding='utf-8')
    with pytest.raises(CleaningError) as failure:
        load_rules(path)
    assert str(failure.value)
    assert str(path) not in str(failure.value)
