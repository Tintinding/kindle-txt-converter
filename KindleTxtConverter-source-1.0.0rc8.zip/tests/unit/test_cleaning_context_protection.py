"""旧推广规则在引用和字面块中的正文保护回归。"""

from dataclasses import replace
from hashlib import sha256
from pathlib import Path

import pytest

from kindle_converter.core.cleaning import analyze_cleaning, load_rules
from kindle_converter.core.encoding import decode_source
from kindle_converter.core.source import SourceSnapshot


PROMOTIONS = [
    ('STD-001', '更多精彩小说请访问：'),
    ('STD-002', '更多精彩小说，请下载阅读APP：'),
    ('STD-003', '本站域名已更换，请牢记新网址：'),
    ('STD-008', '更多TXT小说免费下载：'),
]
CONTEXTS = [
    ('她抄下‘', '’便把纸折好。'),
    ('<pre class="example">', '</pre>'),
    ('~~~text', '~~~'),
]


def make_plan(text, *, rule_id=None, codec='utf-8', bom=b''):
    raw = bom + text.encode(codec)
    source = SourceSnapshot(Path('合成正文保护.txt'), len(raw), sha256(raw).hexdigest(), raw)
    rules = load_rules()
    if rule_id is not None:
        rules = replace(rules, rules=tuple(replace(rule, default_enabled=rule.id == rule_id) for rule in rules.rules))
    return source, analyze_cleaning(decode_source(source, codec), rules=rules)


@pytest.mark.parametrize('rule_id,prefix', PROMOTIONS, ids=[rule_id for rule_id, _ in PROMOTIONS])
@pytest.mark.parametrize('opening,closing', CONTEXTS, ids=['single_quote', 'html_block', 'fence'])
def test_legacy_promotion_only_applies_outside_protected_context(opening, closing, rule_id, prefix):
    example = prefix + 'https://story.invalid/example\r\n'
    actual = prefix + 'https://release.invalid/novels\r\n'
    protected = '合成前文😀𠀀。\r\n\r\n' + opening + '\r\n\r\n' + example + '\r\n' + closing + '\r\n\r\n'
    text = protected + actual
    source, plan = make_plan(text, rule_id=rule_id, codec='utf-16-le', bom=b'\xff\xfe')
    change, = plan.changes
    assert change.rule_id == rule_id and change.default_selected and change.risk == 'low'
    assert change.original == actual and change.start == len(protected)
    assert source.content[change.byte_start:change.byte_end] == actual.encode('utf-16-le')
    assert plan.render(plan.default_selected_ids) == protected
    assert plan.render() == text


@pytest.mark.parametrize('opening,inner,closing', [
    ('~~~html', '<pre>\n作者的话\n‘未闭合的示例', '~~~'),
    ('<pre>', '~~~text\n作者的话\n“未闭合的示例', '</pre>'),
], ids=['html_example_inside_fence', 'fence_example_inside_html'])
def test_literal_markers_and_editorial_examples_do_not_leak_out_of_closed_blocks(opening, inner, closing):
    example = '更多精彩小说请访问：https://story.invalid/example\n'
    actual = '更多精彩小说请访问：https://release.invalid/novels\n'
    block = opening + '\n' + inner + '\n\n' + example + '\n' + closing + '\n\n'
    _, plan = make_plan(block + actual)
    change, = plan.changes
    assert change.rule_id == 'STD-001' and change.default_selected
    assert change.original == actual
    assert plan.render(plan.default_selected_ids) == block


@pytest.mark.parametrize('prefix', [
    '她抄录‘这段是<code>“字面示例</code>\n\n',
    '<pre>\n“字面示例\n</pre>她抄录‘\n\n',
], ids=['quote_before_inline_html', 'quote_after_closing_html'])
def test_html_guard_keeps_quote_delimiters_in_surrounding_prose(prefix):
    example = '更多精彩小说请访问：https://story.invalid/example\n'
    actual = '更多精彩小说请访问：https://release.invalid/novels\n'
    protected = prefix + example + '\n’之后她收起了纸条。\n\n'
    _, plan = make_plan(protected + actual)
    change, = plan.changes
    assert change.rule_id == 'STD-001' and change.default_selected
    assert change.original == actual
    assert plan.render(plan.default_selected_ids) == protected


@pytest.mark.parametrize('opening,closing', CONTEXTS, ids=['single_quote', 'html_block', 'fence'])
def test_duplicate_headings_and_blank_lines_in_protected_context_require_review(opening, closing):
    text = opening + '\n\n第一章 示例\n第一章 示例\n\n\n内容仍保留。\n\n' + closing + '\n'
    _, plan = make_plan(text)
    assert tuple(change.rule_id for change in plan.changes) == ('STD-010', 'STD-009')
    assert all(change.risk == 'review' and not change.default_selected for change in plan.changes)
    assert plan.render(plan.default_selected_ids) == text


def test_fenced_html_example_is_kept_while_outside_html_can_be_reviewed():
    block = '~~~html\n\n<b>示例&amp;内容</b>\n\n~~~\n\n'
    tail = '<b>正文&amp;内容</b>\n'
    _, plan = make_plan(block + tail)
    change, = plan.changes
    assert change.rule_id == 'STD-011' and change.risk == 'review'
    assert change.original == tail
    assert plan.render((change.id,), confirmed_review_ids=(change.id,)) == block + '正文&内容\n'
