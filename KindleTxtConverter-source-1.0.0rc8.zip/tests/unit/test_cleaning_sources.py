"""网站水印、来源和下载声明的手标样例与安全边界。"""

from collections import Counter
from dataclasses import replace
import json
from pathlib import Path

import pytest

from kindle_converter.core.cleaning import CleaningError, analyze_cleaning, load_rules
from kindle_converter.core.encoding import decode_source
from kindle_converter.core.source import read_source


PROJECT_ROOT = Path(__file__).resolve().parents[2]
CASE_PATH = PROJECT_ROOT / 'tests' / 'fixtures' / 'cleaning_source_cases.json'
RULE_PATH = PROJECT_ROOT / 'rules' / 'standard.json'
CASES = [
    *json.loads(CASE_PATH.read_text(encoding='utf-8'))['cases'],
    *json.loads(CASE_PATH.with_name('cleaning_watermark_cases.json').read_text(encoding='utf-8'))['cases'],
]
WATERMARK_RULE = 'STD-020'
REVIEW_ONLY_RULES = {'STD-004', 'STD-005', 'STD-006', 'STD-007', WATERMARK_RULE}


def make_plan(tmp_path, text, *, codec='utf-8', bom=b''):
    path = tmp_path / '独立合成来源样本.txt'
    path.write_bytes(bom + text.encode(codec))
    source = read_source(path)
    decoded = decode_source(source, encoding=codec)
    return source, decoded, analyze_cleaning(decoded)


@pytest.mark.parametrize('case', CASES, ids=[case['id'] for case in CASES])
def test_human_labeled_source_and_download_cases(tmp_path, case):
    source, decoded, plan = make_plan(tmp_path, case['text'])
    mtime_before = source.path.stat().st_mtime_ns
    assert Counter(change.rule_id for change in plan.changes if change.default_selected) == Counter(case['expected_default_rule_ids'])
    assert Counter(change.rule_id for change in plan.changes if change.risk == 'review') == Counter(case['expected_review_rule_ids'])
    assert len(plan.changes) == len(case['expected_default_rule_ids']) + len(case['expected_review_rule_ids'])
    assert plan.render() == case['text']
    assert plan.render(plan.default_selected_ids) == case['expected_default_text']
    for change in plan.changes:
        assert decoded.text[change.start:change.end] == change.original
        assert change.replacement == ''
        assert change.byte_start == decoded.byte_offset(change.start)
        assert change.byte_end == decoded.byte_offset(change.end)
        if change.rule_id in REVIEW_ONLY_RULES:
            assert change.risk == 'review'
            assert change.default_selected is False
    review_ids = tuple(change.id for change in plan.changes if change.risk == 'review')
    if review_ids:
        with pytest.raises(CleaningError):
            plan.render(review_ids)
        assert plan.render(review_ids, confirmed_review_ids=review_ids) == case['expected_review_text']
        assert plan.render() == case['text']
    assert plan.summary()['review_required_count'] == len(case['expected_review_rule_ids'])
    assert source.path.read_bytes() == source.content
    assert source.path.stat().st_mtime_ns == mtime_before


def test_gb18030_four_byte_positions_and_mixed_selection_can_be_restored(tmp_path):
    text = '合成正文😀𠀀\r\n\r\n本书来源：https://source.invalid/book\r\n\r\n本电子书仅供试阅，请在下载后24小时内删除。\r\n\r\n更多TXT小说免费下载，请访问：https://fiction.invalid/book\r\n\r\n尾声。\r\n'
    source, _, plan = make_plan(tmp_path, text, codec='gb18030')
    assert tuple(change.rule_id for change in plan.changes) == ('STD-006', 'STD-007', 'STD-008')
    for change in plan.changes:
        assert change.byte_start == len(text[:change.start].encode('gb18030'))
        assert change.byte_end == len(text[:change.end].encode('gb18030'))
        assert source.content[change.byte_start:change.byte_end] == change.original.encode('gb18030')
    assert plan.render(plan.default_selected_ids) == '合成正文😀𠀀\r\n\r\n本书来源：https://source.invalid/book\r\n\r\n本电子书仅供试阅，请在下载后24小时内删除。\r\n\r\n\r\n尾声。\r\n'
    all_ids = tuple(change.id for change in plan.changes)
    review_ids = tuple(change.id for change in plan.changes if change.risk == 'review')
    with pytest.raises(CleaningError):
        plan.render(all_ids)
    assert plan.render(all_ids, confirmed_review_ids=review_ids) == '合成正文😀𠀀\r\n\r\n\r\n\r\n\r\n尾声。\r\n'
    assert plan.render() == text
    assert source.path.read_bytes() == source.content


@pytest.mark.parametrize('codec,bom', [('utf-16-le', b'\xff\xfe'), ('gb18030', b'')])
def test_watermark_byte_ranges_and_independent_restore(tmp_path, codec, bom):
    prefix = '合成开头😀𠀀。\r\n\r\n'
    download = '本书由松桥小说站整理制作，欢迎访问本站下载更多小说。\r\n'
    credit = '\r\n版权归原作者所有。\r\n\r\n'
    visit = '松桥书库电子版·本站整理，更多小说请访问：https://pinebridge.invalid/read'
    text = prefix + download + credit + visit
    source, _, plan = make_plan(tmp_path, text, codec=codec, bom=bom)
    first, second = plan.changes
    assert (first.rule_id, second.rule_id) == (WATERMARK_RULE, WATERMARK_RULE)
    assert (first.original, second.original) == (download, visit)
    assert first.byte_start == len(bom) + len(prefix.encode(codec))
    assert second.byte_start == len(bom) + len((prefix + download + credit).encode(codec))
    for change in plan.changes:
        assert source.content[change.byte_start:change.byte_end] == change.original.encode(codec)
        assert plan.preview(change.id).before == change.original
    assert plan.default_selected_ids == ()
    with pytest.raises(CleaningError, match='确认'):
        plan.render((first.id, second.id), confirmed_review_ids=(first.id,))
    assert plan.render((first.id, second.id), confirmed_review_ids=(first.id, second.id)) == prefix + credit
    assert plan.render((second.id,), confirmed_review_ids=(second.id,)) == prefix + download + credit
    assert bom + plan.render().encode(codec) == source.content
    assert source.path.read_bytes() == source.content


@pytest.mark.parametrize('case_id', ['WMK-016', 'WMK-019', 'WMK-021'])
def test_watermark_context_protection_with_only_its_rule_enabled(tmp_path, case_id):
    case = next(case for case in CASES if case['id'] == case_id)
    _, decoded, _ = make_plan(tmp_path, case['text'])
    rules = load_rules()
    watermark = next(rule for rule in rules.rules if rule.id == WATERMARK_RULE)
    plan = analyze_cleaning(decoded, rules=replace(rules, rules=(watermark,)))
    assert plan.changes == ()
    assert plan.render() == case['text']


def test_programmatic_source_watermark_cannot_bypass_review(tmp_path):
    case = next(case for case in CASES if case['id'] == 'WMK-002')
    _, decoded, _ = make_plan(tmp_path, case['text'])
    rules = load_rules()
    watermark = next(rule for rule in rules.rules if rule.id == WATERMARK_RULE)
    unsafe = replace(watermark, risk='low', default_selected=True)
    plan = analyze_cleaning(decoded, rules=replace(rules, rules=(unsafe,)))
    change, = plan.changes
    assert change.risk == 'review' and plan.default_selected_ids == ()
    with pytest.raises(CleaningError, match='确认'):
        plan.render((change.id,))
    assert plan.render((change.id,), confirmed_review_ids=(change.id,)) == case['expected_review_text']


def test_source_notice_preview_is_explicit_and_metadata_hides_source(tmp_path):
    secret = 'PRIVATE_SYNTHETIC_SOURCE_正文不入日志'
    text = secret + '\n\n' + CASES[0]['text']
    source, _, plan = make_plan(tmp_path, text)
    change, = plan.changes
    preview = plan.preview(change.id)
    assert preview.before == change.original
    assert preview.after == ''
    assert secret in preview.context_before
    for output in (json.dumps(plan.summary(), ensure_ascii=False), repr((plan, change, preview))):
        assert secret not in output
        assert change.original not in output
        assert 'http://xiaoshuotxt.com' not in output
        assert str(source.path) not in output


def test_source_rule_configuration_has_real_case_links_and_review_only_policy():
    cases = {case['id']: case for case in CASES}
    variant_cases = json.loads((CASE_PATH.parent / 'cleaning_promotion_variant_cases.json').read_text(encoding='utf-8'))['cases']
    cases.update({case['id']: case for case in variant_cases})
    rules = load_rules()
    assert rules.version == '2026.11.11.15'
    for rule in rules.rules:
        if rule.id in REVIEW_ONLY_RULES:
            assert rule.risk == 'review'
            assert rule.default_selected is False
        if rule.id in {'STD-005', 'STD-006', 'STD-007', 'STD-008', WATERMARK_RULE}:
            assert set(rule.test_case_ids) <= cases.keys()
            assert any(rule.id in cases[identifier]['expected_default_rule_ids'] + cases[identifier]['expected_review_rule_ids'] for identifier in rule.test_case_ids)


@pytest.mark.parametrize('fault', [
    'low_risk', 'default_selected', 'invalid_domain', 'missing_domains', 'missing_phrases',
])
def test_site_notice_configuration_rejects_unsafe_or_incomplete_fields(tmp_path, fault):
    payload = json.loads(RULE_PATH.read_text(encoding='utf-8'))
    notice = next(rule for rule in payload['rules'] if rule['id'] == 'STD-005')
    if fault == 'low_risk':
        notice['risk'] = 'low'
    elif fault == 'default_selected':
        notice['default_selected'] = True
    elif fault == 'invalid_domain':
        notice['match']['domains'] = ['https://xiaoshuotxt.com']
    elif fault == 'missing_domains':
        del notice['match']['domains']
    else:
        del notice['match']['required_phrases']
    path = tmp_path / '合成规则配置.json'
    path.write_text(json.dumps(payload, ensure_ascii=False), encoding='utf-8')
    with pytest.raises(CleaningError) as failure:
        load_rules(path)
    assert str(failure.value)
    assert str(path) not in str(failure.value)


@pytest.mark.parametrize(('in_match', 'key', 'value'), [
    (False, 'category', 'C02'),
    (False, 'risk', 'low'),
    (False, 'default_selected', True),
    (True, 'download_phrases', []),
    (True, 'link_actions', []),
    (True, 'link_actions', ['更多小说请访问：']),
], ids=['category', 'risk', 'default', 'download_phrases', 'link_actions', 'delimiter'])
def test_source_watermark_config_requires_review_and_fixed_prompts(tmp_path, in_match, key, value):
    payload = json.loads(RULE_PATH.read_text(encoding='utf-8'))
    entry = next(rule for rule in payload['rules'] if rule['id'] == WATERMARK_RULE)
    fields = entry['match'] if in_match else entry
    fields[key] = value
    path = tmp_path / '合成网站水印规则.json'
    path.write_text(json.dumps(payload, ensure_ascii=False), encoding='utf-8')
    with pytest.raises(CleaningError) as failure:
        load_rules(path)
    assert str(path) not in str(failure.value)
