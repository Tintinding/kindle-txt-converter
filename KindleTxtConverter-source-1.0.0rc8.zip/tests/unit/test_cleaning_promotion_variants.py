"""推广链接写法和组合推广的独立标注、原位置和保护回归。"""

from collections import Counter
from dataclasses import replace
from hashlib import sha256
import json
from pathlib import Path

import pytest

from kindle_converter.core.cleaning import CleaningError, analyze_cleaning, load_rules
from kindle_converter.core.encoding import decode_source
from kindle_converter.core.source import SourceSnapshot


ROOT = Path(__file__).resolve().parents[2]
CASES = json.loads((ROOT / 'tests/fixtures/cleaning_promotion_variant_cases.json').read_text(encoding='utf-8'))['cases']
COMBINED_RULE = 'STD-018'


def make_plan(text, *, codec='utf-8', bom=b'', rules=None):
    raw = bom + text.encode(codec)
    source = SourceSnapshot(Path('合成推广变体.txt'), len(raw), sha256(raw).hexdigest(), raw)
    decoded = decode_source(source, codec)
    return source, analyze_cleaning(decoded, rules=rules)


@pytest.mark.parametrize('case', CASES, ids=[case['id'] for case in CASES])
def test_independently_labeled_promotion_variants(case):
    source, plan = make_plan(case['text'])
    assert Counter(c.rule_id for c in plan.changes if c.default_selected) == Counter(case['expected_default_rule_ids'])
    assert Counter(c.rule_id for c in plan.changes if c.risk == 'review') == Counter(case['expected_review_rule_ids'])
    assert len(plan.changes) == len(case['expected_default_rule_ids']) + len(case['expected_review_rule_ids'])
    selected = tuple(c.id for c in plan.changes)
    review = tuple(c.id for c in plan.changes if c.risk == 'review')
    expected_default = case.get('expected_default_text', case['text'] if review else case['expected_applied_text'])
    assert plan.render(plan.default_selected_ids) == expected_default
    if review:
        with pytest.raises(CleaningError, match='确认'):
            plan.render(selected)
    assert plan.render(selected, confirmed_review_ids=review) == case['expected_applied_text']
    assert plan.render() == case['text']
    for change in plan.changes:
        assert source.content[change.byte_start:change.byte_end] == change.original.encode(plan.source.encoding)
        if change.rule_id == COMBINED_RULE:
            assert change.category == 'C02' and not change.default_selected and change.risk == 'review'


@pytest.mark.parametrize('codec,bom', [('utf-16-be', b'\xfe\xff'), ('gb18030', b'')])
def test_new_variants_keep_exact_multibyte_offsets_and_allow_individual_restore(codec, bom):
    prefix = '正文😀𠀀。\r\n\r\n'
    first = '　小说广告链接: www.first.invalid/catalog\r\n'
    second = '更多完结小说免费阅读！请访问：https://second.invalid/catalog\r'
    text = prefix + first + '\r\n' + second
    source, plan = make_plan(text, codec=codec, bom=bom)
    explicit, combined = plan.changes
    assert (explicit.rule_id, combined.rule_id) == ('STD-014', COMBINED_RULE)
    assert (explicit.original, combined.original) == (first, second)
    assert explicit.byte_start == len(bom) + len(prefix.encode(codec))
    assert combined.byte_start == len(bom) + len((prefix + first + '\r\n').encode(codec))
    for change in plan.changes:
        assert source.content[change.byte_start:change.byte_end] == change.original.encode(codec)
    assert plan.render((explicit.id,)) == prefix + '\r\n' + second
    assert plan.render((combined.id,), confirmed_review_ids=(combined.id,)) == prefix + first + '\r\n'
    assert plan.render((explicit.id, combined.id), confirmed_review_ids=(combined.id,)) == prefix + '\r\n'
    assert plan.render() == text


def test_combined_promotion_protection_applies_when_only_that_rule_is_enabled():
    rules = load_rules()
    only_combined = replace(rules, rules=tuple(
        replace(rule, default_enabled=rule.id == COMBINED_RULE) for rule in rules.rules
    ))
    for case_id in ('VAR-005', 'VAR-019', 'VAR-022', 'VAR-023'):
        case = next(case for case in CASES if case['id'] == case_id)
        _, plan = make_plan(case['text'], rules=only_combined)
        assert tuple(change.rule_id for change in plan.changes) == tuple(case['expected_review_rule_ids'])
        assert plan.render(plan.default_selected_ids) == case['text']


def test_disabled_combined_rule_keeps_existing_explicit_link_selection():
    case = next(case for case in CASES if case['id'] == 'VAR-025')
    rules = load_rules()
    disabled = replace(rules, rules=tuple(
        replace(rule, default_enabled=False) if rule.id == COMBINED_RULE else rule for rule in rules.rules
    ))
    _, plan = make_plan(case['text'], rules=disabled)
    change, = plan.changes
    assert change.rule_id == 'STD-014'
    assert plan.render(plan.default_selected_ids) == case['expected_default_text']


def test_programmatic_combined_rule_cannot_skip_confirmation():
    text = '海量小说免费阅读，立即阅读：https://library.invalid/catalog\n'
    rules = load_rules()
    changed = replace(rules, rules=tuple(
        replace(rule, risk='low', default_selected=True) if rule.id == COMBINED_RULE else rule
        for rule in rules.rules
    ))
    _, plan = make_plan(text, rules=changed)
    change, = plan.changes
    assert change.risk == 'review' and plan.default_selected_ids == ()
    assert plan.render(plan.default_selected_ids) == text
    with pytest.raises(CleaningError, match='确认'):
        plan.render((change.id,))


@pytest.mark.parametrize('fault', ['wrong_category', 'low_risk', 'default_selected', 'missing_phrases', 'empty_actions', 'separator'])
def test_combined_rule_requires_both_fixed_phrase_groups_and_confirmation(tmp_path, fault):
    payload = json.loads((ROOT / 'rules/standard.json').read_text(encoding='utf-8'))
    entry = next(rule for rule in payload['rules'] if rule['id'] == COMBINED_RULE)
    if fault == 'wrong_category':
        entry['category'] = 'C04'
    elif fault == 'low_risk':
        entry['risk'] = 'low'
    elif fault == 'default_selected':
        entry['default_selected'] = True
    elif fault == 'missing_phrases':
        del entry['match']['phrases']
    elif fault == 'empty_actions':
        entry['match']['link_actions'] = []
    else:
        entry['match']['link_actions'] = ['请访问：']
    path = tmp_path / '合成配置.json'
    path.write_text(json.dumps(payload, ensure_ascii=False), encoding='utf-8')
    with pytest.raises(CleaningError) as failure:
        load_rules(path)
    assert str(path) not in str(failure.value)
