"""TASK-006 的选择、确认与恢复流程，只使用合成输入。"""

from dataclasses import replace
from hashlib import sha256
from pathlib import Path

import pytest

from kindle_converter.core.cleaning import CleaningError, analyze_cleaning, load_rules
from kindle_converter.core.cleaning_selection import CleaningSelection
from kindle_converter.core.encoding import decode_source
from kindle_converter.core.source import SourceSnapshot, read_source


LEAD = '第一章 初见😀\r\n\r\n'
AD = '小说推广链接：https://fiction.invalid/novel\r\n'
HTML = '<b>合成&amp;正文</b>\r\n'
REQUEST = '求收藏！\r\n'
TAIL = '尾部正文𠀀。'
BLANK = '\r\n'
TEXT = LEAD + AD + BLANK + HTML + BLANK + REQUEST + BLANK + TAIL
DEFAULT_TEXT = LEAD + BLANK + HTML + BLANK + REQUEST + BLANK + TAIL
APPLIED_TEXT = LEAD + BLANK + '合成&正文\r\n' + BLANK + BLANK + TAIL


def make_plan(text=TEXT, *, encoding='utf-8', rules=None):
    data = text.encode(encoding)
    source = SourceSnapshot(Path('合成清理选择.txt'), len(data), sha256(data).hexdigest(), data)
    return analyze_cleaning(decode_source(source, encoding), rules=rules)


@pytest.fixture
def selection():
    plan = make_plan()
    assert tuple(change.rule_id for change in plan.changes) == ('STD-014', 'STD-011', 'STD-013')
    return CleaningSelection(plan)


def confirm_both(selection):
    _, html, request = selection.plan.changes
    ids = (html.id, request.id)
    selection.select(ids)
    selection.confirm_review(ids)


def test_initial_selection_contains_only_low_risk_defaults(selection):
    ad, _, _ = selection.plan.changes
    assert selection.selected_ids == {ad.id}
    assert selection.confirmed_review_ids == selection.pending_review_ids == frozenset()
    assert selection.summary() == {'selected_count': 1, 'confirmed_review_count': 0, 'pending_review_count': 0}
    assert selection.render() == DEFAULT_TEXT
    assert selection.plan.render() == TEXT


def test_review_selection_waits_for_each_explicit_confirmation(selection):
    _, html, request = selection.plan.changes
    selection.select((html.id, request.id))
    assert selection.pending_review_ids == {html.id, request.id}
    preview = selection.plan.preview(html.id)
    assert (preview.before, preview.after) == (HTML, '合成&正文\r\n')
    with pytest.raises(CleaningError, match='确认'):
        selection.render()
    selection.confirm_review((html.id,))
    assert selection.pending_review_ids == {request.id}
    assert selection.summary() == {'selected_count': 3, 'confirmed_review_count': 1, 'pending_review_count': 1}
    with pytest.raises(CleaningError, match='确认'):
        selection.render()
    selection.confirm_review((request.id,))
    assert selection.pending_review_ids == frozenset()
    assert selection.render() == APPLIED_TEXT


def test_deselecting_a_confirmed_change_restores_text_and_revokes_consent(selection):
    _, html, request = selection.plan.changes
    confirm_both(selection)
    selection.deselect((html.id,))
    assert selection.confirmed_review_ids == {request.id}
    assert selection.render() == LEAD + BLANK + HTML + BLANK + BLANK + TAIL
    selection.select((html.id,))
    assert selection.pending_review_ids == {html.id}
    with pytest.raises(CleaningError, match='确认'):
        selection.render()
    selection.confirm_review((html.id,))
    assert selection.render() == APPLIED_TEXT


@pytest.mark.parametrize('batch', [True, False])
def test_restore_original_clears_selections_and_confirmations(selection, batch):
    confirm_both(selection)
    assert selection.render() == APPLIED_TEXT
    if batch:
        selection.deselect(tuple(change.id for change in selection.plan.changes))
    else:
        selection.restore_original()
    assert selection.selected_ids == selection.confirmed_review_ids == selection.pending_review_ids == frozenset()
    assert selection.render() == TEXT


def test_restore_defaults_clears_both_confirmed_and_pending_review_changes(selection):
    ad, html, request = selection.plan.changes
    selection.deselect((ad.id,))
    selection.select((html.id, request.id))
    selection.confirm_review((html.id,))
    selection.restore_defaults()
    assert selection.selected_ids == {ad.id}
    assert selection.confirmed_review_ids == selection.pending_review_ids == frozenset()
    assert selection.render() == DEFAULT_TEXT
    selection.select((html.id, request.id))
    assert selection.pending_review_ids == {html.id, request.id}


@pytest.mark.parametrize('method', ['select', 'deselect', 'confirm_review'])
def test_batches_with_an_unknown_id_leave_the_entire_selection_unchanged(selection, method):
    _, html, request = selection.plan.changes
    if method != 'select':
        selection.select((html.id, request.id))
        selection.confirm_review((request.id,))
    known_id = request.id if method == 'deselect' else html.id
    before = (selection.selected_ids, selection.confirmed_review_ids, selection.pending_review_ids)
    with pytest.raises(CleaningError, match='未知'):
        getattr(selection, method)((known_id, 'UNKNOWN-PRIVATE-ID'))
    assert (selection.selected_ids, selection.confirmed_review_ids, selection.pending_review_ids) == before


def test_confirmation_rejects_low_risk_or_unselected_items_as_a_batch(selection):
    ad, html, request = selection.plan.changes
    selection.select((html.id,))
    for invalid_id in (ad.id, request.id):
        with pytest.raises(CleaningError, match='已勾选'):
            selection.confirm_review((html.id, invalid_id))
        assert selection.confirmed_review_ids == frozenset()
        assert selection.pending_review_ids == {html.id}


@pytest.mark.parametrize('ids', ['not-an-id-list', b'', bytearray(), None, [['nested']]])
def test_invalid_selection_collection_has_a_safe_error_and_keeps_defaults(selection, ids):
    with pytest.raises(CleaningError) as failure:
        selection.select(ids)
    assert 'not-an-id-list' not in str(failure.value)
    assert selection.render() == DEFAULT_TEXT


@pytest.mark.parametrize('change_basis', ['source', 'rules', 'encoding'])
def test_old_choices_are_rejected_after_source_rule_or_encoding_changes(change_basis):
    if change_basis == 'source':
        old_plan = make_plan()
        new_plan = make_plan(TEXT.replace('初见', '重逢'))
    elif change_basis == 'rules':
        rules = load_rules()
        altered = replace(rules, rules=tuple(
            replace(rule, reason='网页清理理由已更新。') if rule.id == 'STD-011' else rule
            for rule in rules.rules
        ))
        old_plan = make_plan(rules=rules)
        new_plan = make_plan(rules=altered)
        assert old_plan.rules_version == new_plan.rules_version
    else:
        old_plan = make_plan('<b>Sample</b>\r\n')
        new_plan = make_plan('<b>Sample</b>\r\n', encoding='gb18030')
        assert old_plan.source_sha256 == new_plan.source_sha256

    old_html = next(change for change in old_plan.changes if change.rule_id == 'STD-011')
    new_html = next(change for change in new_plan.changes if change.rule_id == 'STD-011')
    old = CleaningSelection(old_plan)
    old.select((old_html.id,))
    old.confirm_review((old_html.id,))
    new = CleaningSelection(new_plan)
    assert (old_html.start, old_html.end) == (new_html.start, new_html.end)
    assert old_html.id != new_html.id
    for method in (new.select, new.confirm_review, new.deselect):
        with pytest.raises(CleaningError, match='未知'):
            method((old_html.id,))
    assert new.confirmed_review_ids == frozenset()
    assert new.render() == new_plan.render(new_plan.default_selected_ids)
    assert old.confirmed_review_ids == {old_html.id}


def test_reanalysis_of_identical_input_starts_without_previous_approvals(selection):
    confirm_both(selection)
    new = CleaningSelection(analyze_cleaning(selection.plan.source))
    _, html, _ = new.plan.changes
    assert html.id == selection.plan.changes[1].id
    assert new.confirmed_review_ids == frozenset()
    assert new.render() == DEFAULT_TEXT
    with pytest.raises(CleaningError, match='已勾选'):
        new.confirm_review((html.id,))
    assert selection.render() == APPLIED_TEXT


def test_public_choice_snapshot_and_bound_plan_cannot_be_modified_in_place(selection):
    ad, html, _ = selection.plan.changes
    initial = selection.selected_ids
    assert isinstance(initial, frozenset)
    with pytest.raises(AttributeError):
        selection.plan = make_plan('另一部合成书。')
    selection.select((html.id,))
    assert initial == {ad.id}
    assert selection.selected_ids == {ad.id, html.id}


def test_duplicate_change_ids_fail_before_selection():
    plan = make_plan()
    first, second, third = plan.changes
    duplicate = replace(plan, changes=(first, replace(second, id=first.id), third))
    with pytest.raises(CleaningError, match='重复'):
        CleaningSelection(duplicate)


def test_selection_summary_and_debug_output_exclude_text_and_change_ids(selection):
    _, html, _ = selection.plan.changes
    selection.select((html.id,))
    for output in (repr(selection), repr(selection.summary())):
        assert 'fiction.invalid' not in output
        assert '合成&amp;正文' not in output
        assert html.id not in output


def test_empty_plan_remains_recoverable():
    text = '没有清理建议的合成正文。\r\n'
    selection = CleaningSelection(make_plan(text))
    assert selection.selected_ids == frozenset()
    selection.restore_defaults()
    selection.restore_original()
    assert selection.render() == text


def test_utf16_source_file_is_unchanged_through_application_and_restore(tmp_path):
    path = tmp_path / '合成选择原文.txt'
    original = b'\xff\xfe' + TEXT.encode('utf-16-le')
    path.write_bytes(original)
    before_mtime = path.stat().st_mtime_ns
    selection = CleaningSelection(analyze_cleaning(decode_source(read_source(path))))
    confirm_both(selection)
    assert selection.render() == APPLIED_TEXT
    selection.restore_original()
    assert b'\xff\xfe' + selection.render().encode('utf-16-le') == original
    assert path.read_bytes() == original
    assert path.stat().st_mtime_ns == before_mtime
