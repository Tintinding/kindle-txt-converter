"""网页残留的手标结果、非空替换、安全确认、字节位置及恢复。"""

from collections import Counter
from copy import deepcopy
from dataclasses import replace
import json
from pathlib import Path

import pytest

from kindle_converter.core.cleaning import CleaningError, analyze_cleaning, load_rules
from kindle_converter.core.encoding import decode_source
from kindle_converter.core.source import read_source


ROOT = Path(__file__).resolve().parents[2]
CASES = json.loads((ROOT / 'tests/fixtures/cleaning_html_cases.json').read_text(encoding='utf-8'))['cases']


def make_plan(tmp_path, text, codec='utf-8', bom=b''):
    path = tmp_path / '独立合成网页样本.txt'
    path.write_bytes(bom + text.encode(codec))
    source = read_source(path)
    decoded = decode_source(source, encoding=codec)
    return source, decoded, analyze_cleaning(decoded, encoding_confirmed=True)


@pytest.mark.parametrize('case', CASES, ids=[case['id'] for case in CASES])
def test_human_labeled_html_cases(tmp_path, case):
    source, decoded, plan = make_plan(tmp_path, case['text'])
    before_mtime = source.path.stat().st_mtime_ns
    assert Counter(c.rule_id for c in plan.changes if c.default_selected) == Counter(case['expected_default_rule_ids'])
    assert Counter(c.rule_id for c in plan.changes if c.risk == 'review') == Counter(case['expected_review_rule_ids'])
    assert len(plan.changes) == len(case['expected_default_rule_ids']) + len(case['expected_review_rule_ids'])
    assert plan.render() == case['text']
    assert plan.render(plan.default_selected_ids) == case.get('expected_default_text', case['text'])
    all_ids = tuple(c.id for c in plan.changes)
    reviews = tuple(c.id for c in plan.changes if c.risk == 'review')
    if reviews:
        with pytest.raises(CleaningError):
            plan.render(all_ids)
    assert plan.render(all_ids, confirmed_review_ids=reviews) == case['expected_applied_text']
    for change in plan.changes:
        assert decoded.text[change.start:change.end] == change.original
        assert change.byte_start == decoded.byte_offset(change.start)
        assert change.byte_end == decoded.byte_offset(change.end)
        if change.rule_id == 'STD-011':
            assert change.risk == 'review' and not change.default_selected
    assert plan.render() == case['text']
    assert source.path.read_bytes() == source.content
    assert source.path.stat().st_mtime_ns == before_mtime


def test_utf16_bom_source_positions_and_nonempty_replacement_can_be_restored(tmp_path):
    prefix = '😀𠀀前文。\r\n\r\n'
    raw_fragment = '<p>甲&#x1F600;&amp;乙</p>\r\n'
    source, _, plan = make_plan(tmp_path, prefix + raw_fragment, 'utf-16-le', b'\xff\xfe')
    change, = plan.changes
    assert change.original == raw_fragment
    assert change.replacement == '甲😀&乙\r\n'
    assert change.byte_start == 2 + len(prefix.encode('utf-16-le'))
    assert change.byte_end == len(source.content)
    assert source.content[change.byte_start:change.byte_end] == raw_fragment.encode('utf-16-le')
    preview = plan.preview(change.id)
    assert preview.before == raw_fragment and preview.after == '甲😀&乙\r\n'
    assert plan.render((change.id,), confirmed_review_ids=(change.id,)) == prefix + '甲😀&乙\r\n'
    assert plan.render() == prefix + raw_fragment


def test_html_replacements_combine_with_heading_blank_and_ad_without_overlap(tmp_path):
    text = '第一章\n第一章\n\n<p>合成&amp;正文</p>\n\n\n更多精彩小说，请访问：https://fiction.invalid/book\n\n尾声。\n'
    _, _, plan = make_plan(tmp_path, text)
    assert tuple(c.rule_id for c in plan.changes) == ('STD-010', 'STD-011', 'STD-009', 'STD-001')
    assert all(a.end <= b.start for a, b in zip(plan.changes, plan.changes[1:]))
    html_change = next(c for c in plan.changes if c.rule_id == 'STD-011')
    assert plan.render(plan.default_selected_ids) == '第一章\n\n<p>合成&amp;正文</p>\n\n\n尾声。\n'
    all_ids = tuple(c.id for c in plan.changes)
    assert plan.render(all_ids, confirmed_review_ids=(html_change.id,)) == '第一章\n\n合成&正文\n\n\n尾声。\n'
    assert plan.render() == text


def test_html_rule_disabled_and_oversized_fragments_are_preserved(tmp_path):
    _, decoded, _ = make_plan(tmp_path, '<b>合成</b>\n')
    rules = load_rules()
    disabled = replace(rules, rules=tuple(replace(r, default_enabled=False) if r.id == 'STD-011' else r for r in rules.rules))
    assert analyze_cleaning(decoded, rules=disabled).changes == ()
    long_text = '甲' * 4096 + ' &amp; 乙\n'
    _, _, plan = make_plan(tmp_path, long_text)
    assert plan.changes == () and plan.render() == long_text


def test_replacement_preview_and_metadata_hide_original_and_result(tmp_path):
    secret = '私密合成内容不可入日志'
    source, _, plan = make_plan(tmp_path, '<p>' + secret + '&amp;尾部</p>\n')
    change, = plan.changes
    preview = plan.preview(change.id)
    assert secret in preview.before and secret in preview.after
    for output in (repr((plan, change, preview)), json.dumps(plan.summary(), ensure_ascii=False)):
        assert secret not in output
        assert str(source.path) not in output
        assert change.original not in output and change.replacement not in output


@pytest.mark.parametrize('tag', ['script', 'style', 'pre', 'code', 'textarea'])
def test_multiline_literal_blocks_remain_unchanged(tmp_path, tag):
    text = f'<{tag}>\n&amp; &#65; &lt;p&gt;\n</{tag}>\n'
    _, _, plan = make_plan(tmp_path, text)
    assert plan.changes == ()
    assert plan.render() == text


@pytest.mark.parametrize('fault', ['zero', 'too_large', 'string', 'bool', 'missing', 'low_risk', 'default_selected', 'duplicate'])
def test_html_configuration_rejects_unsafe_or_invalid_values(tmp_path, fault):
    payload = json.loads((ROOT / 'rules/standard.json').read_text(encoding='utf-8'))
    rule = next(r for r in payload['rules'] if r['id'] == 'STD-011')
    if fault in {'zero', 'too_large', 'string', 'bool'}:
        rule['match']['max_fragment_characters'] = {'zero': 0, 'too_large': 10001, 'string': '4096', 'bool': True}[fault]
    elif fault == 'missing':
        del rule['match']['max_fragment_characters']
    elif fault == 'low_risk':
        rule['risk'] = 'low'
    elif fault == 'default_selected':
        rule['default_selected'] = True
    else:
        extra = deepcopy(rule)
        extra['id'] = 'STD-999'
        payload['rules'].append(extra)
    path = tmp_path / '合成网页规则.json'
    path.write_text(json.dumps(payload, ensure_ascii=False), encoding='utf-8')
    with pytest.raises(CleaningError) as failure:
        load_rules(path)
    assert str(failure.value) and str(path) not in str(failure.value)
