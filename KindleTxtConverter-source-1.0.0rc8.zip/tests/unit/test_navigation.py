from hashlib import sha256
from pathlib import Path

from kindle_converter.core.chapters import ChapterEditor
from kindle_converter.core.encoding import decode_source
from kindle_converter.core.navigation import build_navigation, walk_navigation
from kindle_converter.core.source import SourceSnapshot


def editor_for(text):
    content = text.encode("utf-8")
    snapshot = SourceSnapshot(Path("合成导航.txt"), len(content), sha256(content).hexdigest(), content)
    return ChapterEditor(decode_source(snapshot))


def test_navigation_preserves_volume_membership_and_source_order():
    editor = editor_for(
        "序章\n\n第一卷 潮声\n第一章\n第一卷 第二章\n"
        "第二卷：　第一章 雨至\n第二章\n\n番外一\n\n第三卷 长夜\n第一章\n"
    )
    entries = build_navigation(editor)
    assert [entry.title for entry in entries] == ["序章", "第一卷 潮声", "第二卷", "第三卷 长夜"]
    assert [[child.title for child in entry.children] for entry in entries] == [
        [], ["第一章", "第一卷 第二章"], ["第二卷：　第一章 雨至", "第二章", "番外一"], ["第一章"],
    ]
    locations = [(depth, entry.line_number, entry.start) for depth, entry in walk_navigation(entries)]
    assert [line_number for _, line_number, _ in locations] == [1, 3, 4, 5, 6, 6, 7, 9, 11, 12]
    assert sorted({start for _, _, start in locations}) == [start for _, _, start in locations]
    parent, first_chapter = entries[2], entries[2].children[0]
    assert editor.source.text[parent.start:first_chapter.start] == "第二卷：　"
    assert editor.source.text[first_chapter.start:].startswith("第一章 雨至")
    assert parent.anchor != first_chapter.anchor


def test_navigation_uses_edits_and_original_anchor_for_renamed_inline_chapter():
    editor = editor_for("原文开头。\n原文段落。\n第1卷 第1章\n第2章\n第3章\n")
    editor.add(1, "手动卷名", kind="volume")
    editor.add(2, "自拟目录标题")
    editor.rename(3, "重新命名")
    editor.remove(4)
    first, second = build_navigation(editor)
    assert first.title == "手动卷名" and first.children[0].title == "自拟目录标题"
    assert second.title == "第1卷"
    assert [child.title for child in second.children] == ["重新命名", "第3章"]
    assert editor.source.text[second.children[0].start:].startswith("第1章")
    assert "重新命名" not in repr(second)


def test_empty_and_flat_navigation():
    editor = editor_for("前面的正常正文。\r\n第一章\r\n正文仍在。")
    entry, = build_navigation(editor)
    assert (entry.kind, entry.line_number, entry.children) == ("chapter", 2, ())
    editor.remove(2)
    assert build_navigation(editor) == ()
