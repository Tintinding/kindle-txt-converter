import os
import sys

from kindle_converter.services.subprocess_environment import external_environment


def test_child_environment_does_not_inherit_development_or_qt_settings(tmp_path, monkeypatch):
    bundle = tmp_path / '_internal'
    monkeypatch.setattr(sys, 'frozen', True, raising=False)
    monkeypatch.setattr(sys, '_MEIPASS', str(bundle), raising=False)
    original = {'PATH': os.pathsep.join([str(bundle), str(bundle / 'PySide6'), str(tmp_path / 'system')]),
                'PYTHONPATH': 'private-development', 'PYTHONHOME': 'old-runtime', 'VIRTUAL_ENV': 'dev-env',
                '_PYI_APPLICATION_HOME_DIR': 'parent', 'QT_PLUGIN_PATH': 'parent-qt', 'SystemRoot': 'system'}
    clean = external_environment(original)
    assert clean['PATH'] == str(tmp_path / 'system')
    assert clean['SystemRoot'] == 'system'
    assert 'PYTHONPATH' not in clean and 'QT_PLUGIN_PATH' not in clean
    assert '_PYI_APPLICATION_HOME_DIR' not in clean
    assert original['PYTHONPATH'] == 'private-development'
