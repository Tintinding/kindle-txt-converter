from xml.etree import ElementTree as ET
from zipfile import ZipFile

import pytest
from PySide6.QtGui import QImage

from kindle_converter.converter.epub import write_epub
from kindle_converter.converter.metadata import book_language, read_cover
from kindle_converter.converter.prepare import prepare_book


@pytest.mark.parametrize(("extension", "media_type"), [("png", "image/png"), ("jpg", "image/jpeg")])
def test_intermediate_epub_contains_selected_cover_and_metadata(tmp_path, extension, media_type):
    cover_path = tmp_path / f"封面.{extension}"
    image = QImage(120, 160, QImage.Format.Format_RGB32)
    image.fill(0xff21445e)
    assert image.save(str(cover_path))
    cover = read_cover(cover_path)
    assert (cover.extension, cover.media_type) == (extension, media_type)
    book = prepare_book("第一章\n海风起了。".encode(), "潮汐 & 归途", "")
    intermediate = tmp_path / "试读.epub"
    write_epub(intermediate, book, "潮汐 & 归途", "", language="EN", description="简介 <原文>\n第二行", cover=cover)

    with ZipFile(intermediate) as archive:
        assert archive.testzip() is None
        opf = ET.fromstring(archive.read("OEBPS/book.opf"))
        assert opf.find(".//{*}title").text == "潮汐 & 归途"
        assert opf.find(".//{*}language").text == "en"
        assert opf.find(".//{*}creator") is None
        assert opf.find(".//{*}description").text == "<p>简介 &lt;原文&gt;<br/>第二行</p>"
        assert opf.find('.//{*}meta[@name="cover"]').get("content") == "cover-image"
        assert opf.find('.//{*}item[@id="cover-image"]').get("media-type") == media_type
        assert archive.read(f"OEBPS/cover.{extension}") == cover_path.read_bytes()


def test_file_extension_alone_does_not_make_a_valid_cover(tmp_path):
    cover = tmp_path / "封面.png"
    cover.write_bytes(b"no image here")
    with pytest.raises(ValueError, match="JPG 或 PNG"):
        read_cover(cover)


def test_language_codes_are_normalized_and_validated():
    assert book_language(" ZH ") == "zh"
    with pytest.raises(ValueError, match="语言代码"):
        book_language("中文")
