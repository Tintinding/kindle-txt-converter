"""初测计分口径和安全判定的独立检查。"""

from hashlib import sha256
import json
from pathlib import Path
import runpy

import pytest

from kindle_converter.core.cleaning import CleaningChange, CleaningPlan, load_rules
from kindle_converter.core.encoding import decode_source
from kindle_converter.core.source import SourceSnapshot


ROOT = Path(__file__).resolve().parents[2]
SCORE = runpy.run_path(str(ROOT / 'scripts' / 'verify_cleaning_accuracy.py'))
Annotation = SCORE['Annotation']
score_case = SCORE['score_case']


def make_plan(text, specs):
    raw = text.encode('utf-8')
    source_hash = sha256(raw).hexdigest()
    source = SourceSnapshot(Path('synthetic.txt'), len(raw), source_hash, raw)
    decoded = decode_source(source, 'utf-8')
    changes = tuple(
        CleaningChange(
            str(number), source_hash, f'STD-{number:03}', '合成建议', category, '合成理由',
            'low' if default else 'review', default, 1, start, end,
            decoded.byte_offset(start), decoded.byte_offset(end), text[start:end], replacement,
        )
        for number, (start, end, category, default, replacement) in enumerate(specs, 1)
    )
    return CleaningPlan(decoded, 'test', 1, changes, 'synthetic')


def test_recall_accepts_exact_review_candidates_but_excludes_unrelated_rules():
    text = '广告甲广告乙广告丙重复标题'
    labels = [Annotation('clear_ad', 0, 3), Annotation('clear_ad_review', 3, 6),
              Annotation('clear_ad', 6, 9), Annotation('default_format', 9, 13)]
    plan = make_plan(text, [(0, 3, 'C02', True, ''), (3, 6, 'C04', False, ''),
                            (6, 9, 'C06', False, ''), (9, 13, 'C08', True, '')])
    report = score_case('ACC-001', plan, labels)
    assert report['clear_ad_count'] == 3 and report['detected_clear_ad_count'] == 2
    assert report['default_deletion_count'] == report['correct_default_deletion_count'] == 2
    assert report['missed_clear_ads'] == [{'case_id': 'ACC-001', 'start': 6, 'end': 9}]
    assert not report['incorrect_default_changes']


@pytest.mark.parametrize('start,end,touches_body', [(4, 7, False), (3, 8, True)])
def test_partial_or_excessive_deletion_never_counts_as_a_correct_ad_match(start, end, touches_body):
    text = '前正文广告正文后文'
    labels = [Annotation('keep', 0, 3), Annotation('clear_ad', 3, 7), Annotation('keep', 7, 9)]
    plan = make_plan(text, [(start, end, 'C02', True, '')])
    report = score_case('ACC-001', plan, labels)
    assert report['detected_clear_ad_count'] == report['correct_default_deletion_count'] == 0
    assert len(report['missed_clear_ads']) == len(report['incorrect_default_changes']) == 1
    assert bool(report['default_changes_touching_body']) is touches_body


def test_default_deletion_of_a_review_only_ad_is_detected_but_unsafe():
    text = '来源推广'
    plan = make_plan(text, [(0, len(text), 'C04', True, '')])
    report = score_case('ACC-001', plan, [Annotation('clear_ad_review', 0, len(text))])
    assert report['detected_clear_ad_count'] == 1
    assert report['correct_default_deletion_count'] == 0
    assert len(report['default_changes_touching_review_only']) == 1
    assert not report['default_changes_touching_body']


def test_review_of_protected_prose_is_reported_separately_without_text():
    text = 'PRIVATE_合成正文\r\n'
    plan = make_plan(text, [(0, len(text), 'C02', False, '')])
    report = score_case('ACC-001', plan, [Annotation('keep', 0, len(text))])
    assert report['default_deletion_count'] == 0 and not report['default_changes_touching_body']
    assert len(report['review_suggestions_touching_body']) == 1
    assert 'PRIVATE' not in json.dumps(report, ensure_ascii=False)


def test_default_replacement_is_flagged_without_entering_deletion_precision():
    text = '<b>合成正文</b>'
    plan = make_plan(text, [(0, len(text), 'C09', True, '合成正文')])
    report = score_case('ACC-001', plan, [Annotation('review_only', 0, len(text))])
    assert report['default_replacement_count'] == 1 and report['default_deletion_count'] == 0
    assert len(report['default_changes_touching_review_only']) == 1


@pytest.mark.parametrize('numerator,denominator,target,percent,met', [
    (0, 0, 95, None, False),
    (19, 20, 95, 95.0, True),
    (99, 100, 99, 99.0, True),
    (989999, 1000000, 99, 99.0, False),
])
def test_thresholds_use_exact_counts_and_fail_on_empty_denominators(numerator, denominator, target, percent, met):
    metric = SCORE['_metric'](numerator, denominator, target)
    assert metric['percent'] == percent and metric['meets_target'] is met


def test_corpus_evaluation_scores_the_actual_engine_with_encoding_and_no_body_in_report():
    fixture = {
        'schema_version': 1, 'corpus_id': 'scoring-check', 'cases': [{
            'id': 'ACC-001', 'encoding': 'gb18030', 'segments': [
                ['keep', '私有合成前文𠀀\r\n\r\n'],
                ['clear_ad', '小说广告链接：https://fiction.invalid/seed\r\n'],
                ['keep', '\r\n私有合成尾文。'],
            ],
        }],
    }
    raw = json.dumps(fixture, ensure_ascii=False).encode('utf-8')
    report = SCORE['evaluate_corpus'](raw, load_rules())
    assert report['corpus_sha256'] == sha256(raw).hexdigest()
    assert report['clear_ad_recall']['numerator'] == report['clear_ad_recall']['denominator'] == 1
    assert report['default_deletion_precision']['percent'] == 100.0
    assert report['pilot_thresholds_met'] is True
    encoded = json.dumps(report, ensure_ascii=False)
    assert '私有合成' not in encoded and 'fiction.invalid' not in encoded
