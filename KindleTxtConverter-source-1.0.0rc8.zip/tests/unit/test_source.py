from dataclasses import FrozenInstanceError
from hashlib import sha256

import pytest

from kindle_converter.core.source import SourceReadError, read_source


def test_read_only_snapshot_handles_chinese_and_spaced_path(tmp_path):
    folder = tmp_path / "中文 目录"
    folder.mkdir()
    source = folder / "测试 小说.txt"
    content = "第一章\r\n这是一段测试正文。\r\n".encode("utf-8")
    source.write_bytes(content)
    before = source.stat()
    snapshot = read_source(source)
    assert snapshot.content == content
    assert snapshot.size_bytes == len(content)
    assert snapshot.sha256 == sha256(content).hexdigest()
    assert source.read_bytes() == content
    assert source.stat().st_mtime_ns == before.st_mtime_ns
    with pytest.raises(FrozenInstanceError):
        snapshot.content = b"changed"


def test_diagnostics_repr_does_not_include_content_or_private_path(tmp_path):
    source = tmp_path / "private-book.txt"
    source.write_text("不应出现在日志里的正文", encoding="utf-8")
    text = repr(read_source(source))
    assert "不应出现在日志里的正文" not in text
    assert str(source) not in text


def test_empty_file_has_readable_error(tmp_path):
    source = tmp_path / "empty.txt"
    source.write_bytes(b"")
    with pytest.raises(SourceReadError, match="文件为空"):
        read_source(source)


def test_missing_file_has_readable_error(tmp_path):
    with pytest.raises(SourceReadError, match="文件不存在"):
        read_source(tmp_path / "missing.txt")


def test_directory_is_not_accepted_as_a_txt(tmp_path):
    with pytest.raises(SourceReadError, match="文件夹"):
        read_source(tmp_path)
