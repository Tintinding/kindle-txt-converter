"""验证阅读 APP 推广的手标样例、建议位置、确认和恢复。"""

from dataclasses import replace
from hashlib import sha256
import json
from pathlib import Path

import pytest

from kindle_converter.core.cleaning import CleaningError, analyze_cleaning, load_rules
from kindle_converter.core.cleaning_selection import CleaningSelection
from kindle_converter.core.encoding import decode_source
from kindle_converter.core.source import SourceSnapshot


ROOT = Path(__file__).resolve().parents[2]
CASE_PATH = ROOT / 'tests' / 'fixtures' / 'cleaning_app_cases.json'
CASES = json.loads(CASE_PATH.read_text(encoding='utf-8'))['cases']
OFFER_RULE = 'STD-019'


def make_plan(text, *, codec='utf-8', bom=b'', rules=None):
    raw = bom + text.encode(codec)
    source = SourceSnapshot(Path('合成阅读APP推广.txt'), len(raw), sha256(raw).hexdigest(), raw)
    return source, analyze_cleaning(decode_source(source, codec), rules=rules)


@pytest.mark.parametrize('case', CASES, ids=[case['id'] for case in CASES])
def test_independently_labeled_reading_app_cases(case):
    original = case['text']
    source, plan = make_plan(original)
    assert [change.rule_id for change in plan.changes if change.default_selected] == case['expected_default_rule_ids']
    assert [change.rule_id for change in plan.changes if change.risk == 'review'] == case['expected_review_rule_ids']
    assert len(plan.changes) == len(case['expected_default_rule_ids']) + len(case['expected_review_rule_ids'])
    expected = case.get('expected_applied_text', original)
    selected = tuple(change.id for change in plan.changes)
    review = tuple(change.id for change in plan.changes if change.risk == 'review')
    assert plan.render(plan.default_selected_ids) == (original if review else expected)
    if review:
        with pytest.raises(CleaningError, match='确认'):
            plan.render(selected)
    assert plan.render(selected, confirmed_review_ids=review) == expected
    assert plan.render() == original
    for change in plan.changes:
        assert change.category == 'C03'
        assert source.content[change.byte_start:change.byte_end] == change.original.encode('utf-8')
        assert plan.preview(change.id).before == change.original


@pytest.mark.parametrize('codec,bom', [('utf-16-le', b'\xff\xfe'), ('gb18030', b'')])
def test_app_changes_keep_exact_multibyte_offsets_and_allow_independent_restore(codec, bom):
    prefix = '合成桥边😀𠀀。\r\n\r\n'
    linked = '扫码下载阅读软件，开通即可免费领书：https://bridge.invalid/app\r\n'
    gap = '\r\n'
    offer = '下载青湾阅读APP，注册即送七天会员。\r'
    tail = '城门关了。\n'
    original = prefix + linked + gap + offer + tail
    source, plan = make_plan(original, codec=codec, bom=bom)
    linked_change, offer_change = plan.changes
    assert (linked_change.rule_id, offer_change.rule_id) == ('STD-002', OFFER_RULE)
    assert (linked_change.original, offer_change.original) == (linked, offer)
    assert linked_change.byte_start == len(bom) + len(prefix.encode(codec))
    assert offer_change.byte_start == len(bom) + len((prefix + linked + gap).encode(codec))
    for change in plan.changes:
        assert source.content[change.byte_start:change.byte_end] == change.original.encode(codec)
    selection = CleaningSelection(plan)
    assert selection.render() == prefix + gap + offer + tail
    selection.select((offer_change.id,))
    with pytest.raises(CleaningError, match='确认'):
        selection.render()
    selection.confirm_review((offer_change.id,))
    assert selection.render() == prefix + gap + tail
    selection.deselect((linked_change.id,))
    assert selection.render() == prefix + linked + gap + tail
    selection.restore_original()
    assert bom + selection.render().encode(codec) == source.content


@pytest.mark.parametrize('case_id', ['APP-007', 'APP-019', 'APP-021', 'APP-023'])
def test_unlinked_app_protection_with_only_its_rule_enabled(case_id):
    case = next(case for case in CASES if case['id'] == case_id)
    rules = load_rules()
    only_offer = replace(rules, rules=tuple(
        replace(rule, default_enabled=rule.id == OFFER_RULE) for rule in rules.rules
    ))
    _, plan = make_plan(case['text'], rules=only_offer)
    assert [change.rule_id for change in plan.changes] == case['expected_review_rule_ids']
    assert plan.render(plan.default_selected_ids) == case['text']


def test_disabling_unlinked_app_offers_preserves_linked_app_rule():
    linked = CASES[0]
    offer = next(case for case in CASES if case['id'] == 'APP-007')
    original = linked['text'] + '\n' + offer['text']
    rules = load_rules()
    disabled = replace(rules, rules=tuple(
        replace(rule, default_enabled=False) if rule.id == OFFER_RULE else rule for rule in rules.rules
    ))
    _, plan = make_plan(original, rules=disabled)
    change, = plan.changes
    assert change.rule_id == 'STD-002' and change.default_selected
    assert plan.render(plan.default_selected_ids) == linked['expected_applied_text'] + '\n' + offer['text']


def test_programmatic_unlinked_app_rule_cannot_bypass_confirmation():
    original = '下载云杉阅读APP，注册即送三天会员。\n'
    rules = load_rules()
    unsafe = replace(rules, rules=tuple(
        replace(rule, risk='low', default_selected=True) if rule.id == OFFER_RULE else rule
        for rule in rules.rules
    ))
    _, plan = make_plan(original, rules=unsafe)
    change, = plan.changes
    assert change.risk == 'review' and not change.default_selected
    assert plan.render(plan.default_selected_ids) == original
    with pytest.raises(CleaningError, match='确认'):
        plan.render((change.id,))
    assert plan.render((change.id,), confirmed_review_ids=(change.id,)) == ''


@pytest.mark.parametrize(('in_match', 'key', 'value'), [
    (False, 'category', 'C02'),
    (False, 'risk', 'low'),
    (False, 'default_selected', True),
    (True, 'calls_to_action', []),
    (True, 'offers', []),
    (True, 'offers', ['新用户：可免费领书']),
], ids=['category', 'risk', 'default', 'actions', 'offers', 'punctuation'])
def test_unlinked_app_config_requires_confirmation_and_fixed_phrases(tmp_path, in_match, key, value):
    payload = json.loads((ROOT / 'rules' / 'standard.json').read_text(encoding='utf-8'))
    entry = next(rule for rule in payload['rules'] if rule['id'] == OFFER_RULE)
    fields = entry['match'] if in_match else entry
    fields[key] = value
    path = tmp_path / '合成阅读APP规则.json'
    path.write_text(json.dumps(payload, ensure_ascii=False), encoding='utf-8')
    with pytest.raises(CleaningError) as failure:
        load_rules(path)
    assert str(path) not in str(failure.value)
