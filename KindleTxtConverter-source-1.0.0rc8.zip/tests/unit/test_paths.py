from pathlib import Path
import sys

from kindle_converter.services.paths import application_root


def test_development_root_contains_authoritative_requirements():
    assert (application_root() / "docs" / "requirements.md").is_file()


def test_portable_root_is_executable_directory(tmp_path, monkeypatch):
    executable = tmp_path / "便携 软件" / "Kindle电子书转换器.exe"
    monkeypatch.setattr(sys, "frozen", True, raising=False)
    monkeypatch.setattr(sys, "executable", str(executable))
    assert application_root() == Path(executable).resolve().parent
