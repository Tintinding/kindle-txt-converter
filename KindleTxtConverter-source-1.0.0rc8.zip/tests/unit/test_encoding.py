"""TASK-004 编码与字节位置契约检查，仅使用自行编写的合成文本。"""

from hashlib import sha256

import pytest

from kindle_converter.core.encoding import EncodingError, decode_source
from kindle_converter.core.source import SourceSnapshot, read_source


def snapshot(tmp_path, data: bytes):
    path = tmp_path / '中文 合成编码样本.txt'
    path.write_bytes(data)
    return read_source(path)


def test_utf8_preserves_all_line_endings_and_original_source(tmp_path):
    text = '第一章 初见\r\n段落\t带空格  \r第二段\n'
    source = snapshot(tmp_path, text.encode('utf-8'))
    before = source.path.stat().st_mtime_ns
    decoded = decode_source(source)
    assert decoded.text == text
    assert decoded.requires_confirmation is False
    assert decoded.bom_bytes == 0
    assert decoded.source_sha256 == source.sha256 == sha256(source.content).hexdigest()
    assert source.path.read_bytes() == source.content
    assert source.path.stat().st_mtime_ns == before


@pytest.mark.parametrize('codec,bom', [
    ('utf-8', b'\xef\xbb\xbf'),
    ('utf-16-le', b'\xff\xfe'),
    ('utf-16-be', b'\xfe\xff'),
])
def test_bom_is_recognized_and_kept_in_source_position_mapping(tmp_path, codec, bom):
    text = '第一章 初见\r\n中文与😀。\n'
    source = snapshot(tmp_path, bom + text.encode(codec))
    decoded = decode_source(source)
    assert decoded.text == text
    assert decoded.bom_bytes == len(bom)
    assert decoded.requires_confirmation is False
    for index in range(len(text) + 1):
        assert decoded.byte_offset(index) == len(bom) + len(text[:index].encode(codec))
    assert decoded.byte_offset(len(text)) == len(source.content)


@pytest.mark.parametrize('requested,codec', [
    ('utf8', 'utf-8'),
    ('UTF-8', 'utf-8'),
    ('utf8sig', 'utf-8-sig'),
    ('utf_8_sig', 'utf-8-sig'),
    ('gbk', 'gbk'),
    ('GB18030', 'gb18030'),
    ('utf-16', 'utf-16'),
    ('utf16le', 'utf-16-le'),
    ('utf16be', 'utf-16-be'),
    ('UTF-16LE', 'utf-16-le'),
    ('utf_16_be', 'utf-16-be'),
])
def test_manual_codec_and_standard_aliases(tmp_path, requested, codec):
    text = '第一章\r\n中文正文与ASCII 123。\n'
    source = snapshot(tmp_path, text.encode(codec))
    decoded = decode_source(source, encoding=requested)
    assert decoded.text == text
    assert decoded.source_sha256 == source.sha256
    assert decoded.byte_offset(len(text)) == len(source.content)


@pytest.mark.parametrize('codec', ['utf-16-le', 'utf-16-be'])
def test_manual_utf16_emoji_maps_code_points_to_original_bytes(tmp_path, codec):
    text = '中😀A\r\n尾'
    source = snapshot(tmp_path, text.encode(codec))
    decoded = decode_source(source, encoding=codec)
    assert decoded.text == text
    assert decoded.bom_bytes == 0
    assert decoded.byte_offset(1) == 2
    assert decoded.byte_offset(2) == 6  # emoji 为一字符、四字节 UTF-16 代理对。
    for index in range(len(text) + 1):
        assert decoded.byte_offset(index) == len(text[:index].encode(codec))


@pytest.mark.parametrize('encoding', [None, 'gb18030'])
def test_gb18030_four_byte_characters_are_not_truncated(tmp_path, encoding):
    text = '甲𠀀😀乙'
    source = snapshot(tmp_path, text.encode('gb18030'))
    decoded = decode_source(source, encoding=encoding)
    assert decoded.text == text
    assert decoded.byte_offset(1) == 2
    assert decoded.byte_offset(2) == 6
    assert decoded.byte_offset(3) == 10
    assert decoded.byte_offset(4) == len(source.content)


def test_utf8_multibyte_and_emoji_positions(tmp_path):
    text = '中😀A'
    decoded = decode_source(snapshot(tmp_path, text.encode('utf-8')))
    assert [decoded.byte_offset(index) for index in range(4)] == [0, 3, 7, 8]


@pytest.mark.parametrize('codec', ['gbk', 'gb18030', 'utf-16-le', 'utf-16-be'])
def test_auto_non_utf8_without_bom_is_not_marked_certain(tmp_path, codec):
    text = '第一章 初见\r\n正常中文正文，天地玄黄，宇宙洪荒。\r\n第二章 继续\r\n人物对话和段落应完整保留。\r\n'
    decoded = decode_source(snapshot(tmp_path, text.encode(codec)))
    assert decoded.text == text
    assert decoded.requires_confirmation is True
    assert decoded.warnings
    assert decoded.bom_bytes == 0


def test_short_bomless_utf16_cjk_requires_confirmation(tmp_path):
    decoded = decode_source(snapshot(tmp_path, '中文天地'.encode('utf-16-le')))
    # 这组字节也能被 GB18030 严格解码为不同内容，不固定猜测标签。
    assert decoded.requires_confirmation is True
    assert decoded.warnings


def test_ascii_compatible_utf16_ambiguity_requires_confirmation_and_manual_recovery(tmp_path):
    source = snapshot(tmp_path, '你好'.encode('utf-16-le'))
    automatic = decode_source(source)
    # 604f7d59 同时是合法 ASCII，自动结果不能据此声称确定。
    assert automatic.requires_confirmation is True
    assert automatic.warnings
    manual = decode_source(source, encoding='utf16le')
    assert manual.text == '你好'
    assert manual.byte_offset(len(manual.text)) == len(source.content)


@pytest.mark.parametrize('codec', ['utf-16-le', 'utf-16-be'])
def test_bomless_utf16_ascii_is_not_silently_accepted_as_utf8(tmp_path, codec):
    text = 'Chapter 1\r\nThis is synthetic text.\r\nChapter 2\r\nMore text.\r\n'
    decoded = decode_source(snapshot(tmp_path, text.encode(codec)))
    assert decoded.text == text
    assert decoded.requires_confirmation is True
    assert decoded.warnings


def test_undecidable_bytes_fail_without_replacement(tmp_path):
    with pytest.raises(EncodingError) as failure:
        decode_source(snapshot(tmp_path, b'\x81'))
    assert str(failure.value)
    assert '�' not in str(failure.value)


@pytest.mark.parametrize('data,codec', [
    (b'\xef\xbb\xbf' + '正文'.encode('utf-8'), 'gbk'),
    (b'\xff\xfe' + '正文'.encode('utf-16-le'), 'utf-16-be'),
    (b'\xfe\xff' + '正文'.encode('utf-16-be'), 'utf-8'),
])
def test_manual_codec_conflicting_with_bom_is_rejected(tmp_path, data, codec):
    with pytest.raises(EncodingError, match='BOM'):
        decode_source(snapshot(tmp_path, data), encoding=codec)


@pytest.mark.parametrize('data', [b'\xef\xbb\xbf', b'\xff\xfe', b'\xfe\xff'])
def test_bom_only_without_body_is_rejected(tmp_path, data):
    with pytest.raises(EncodingError):
        decode_source(snapshot(tmp_path, data))


def test_empty_snapshot_has_readable_error(tmp_path):
    source = SourceSnapshot(tmp_path / 'empty.txt', 0, sha256(b'').hexdigest(), b'')
    with pytest.raises(EncodingError) as failure:
        decode_source(source)
    assert str(failure.value)


@pytest.mark.parametrize('codec', ['utf-32-le', 'utf-32-be'])
def test_utf32_bom_is_explicitly_rejected_before_utf16_detection(tmp_path, codec):
    bom = b'\xff\xfe\x00\x00' if codec.endswith('le') else b'\x00\x00\xfe\xff'
    source = snapshot(tmp_path, bom + '合成正文'.encode(codec))
    with pytest.raises(EncodingError, match='UTF-32'):
        decode_source(source)


def test_manual_utf16_without_bom_requires_explicit_byte_order(tmp_path):
    source = snapshot(tmp_path, '合成正文'.encode('utf-16-le'))
    with pytest.raises(EncodingError, match='LE.*BE'):
        decode_source(source, encoding='utf16')


def test_whitespace_is_preserved_but_needs_confirmation(tmp_path):
    text = ' \t\r\n\r\n'
    decoded = decode_source(snapshot(tmp_path, text.encode('utf-8')))
    assert decoded.text == text
    assert decoded.requires_confirmation is True
    assert decoded.warnings


@pytest.mark.parametrize('character', ['\ufffd', '\x01'])
def test_existing_replacement_or_control_character_is_preserved(tmp_path, character):
    text = f'正文前{character}正文后'
    decoded = decode_source(snapshot(tmp_path, text.encode('utf-8')))
    assert decoded.text == text
    assert decoded.requires_confirmation is True
    assert decoded.warnings


@pytest.mark.parametrize('codec,data', [
    ('utf-8', b'\xff'),
    ('utf-16-le', b'\x00'),
    ('utf-16-be', b'\x00'),
    ('gbk', b'\x81'),
    ('gb18030', b'\x81\x30'),
    ('not-a-valid-codec', b'abc'),
    ('utf-16-le', b'\xff\xfe\x00'),
])
def test_manual_decoding_errors_are_strict_and_readable(tmp_path, codec, data):
    with pytest.raises(EncodingError) as failure:
        decode_source(snapshot(tmp_path, data), encoding=codec)
    assert str(failure.value)
    assert '�' not in str(failure.value)


def test_invalid_utf8_error_does_not_leak_source_or_path(tmp_path):
    private = 'VERY_PRIVATE_ORIGINAL_TEXT_非常私密'
    source = snapshot(tmp_path, private.encode('utf-8') + b'\xff')
    with pytest.raises(EncodingError) as failure:
        decode_source(source, encoding='utf-8')
    assert private not in str(failure.value)
    assert str(source.path) not in str(failure.value)


def test_decoded_repr_is_metadata_only(tmp_path):
    text = 'VERY_PRIVATE_ORIGINAL_TEXT_非常私密'
    source = snapshot(tmp_path, text.encode('utf-8'))
    decoded = decode_source(source)
    assert text not in repr(decoded)
    assert str(source.path) not in repr(decoded)


def test_preview_is_bounded_without_modifying_decoded_text(tmp_path):
    text = ''.join(f'第{i}行 😀 合成正文\r\n' for i in range(1, 21))
    decoded = decode_source(snapshot(tmp_path, text.encode('utf-8')))
    preview = decoded.preview(max_lines=3, max_characters=2000)
    assert len(preview.splitlines()) <= 3
    assert '第1行' in preview
    assert '第4行' not in preview
    short = decoded.preview(max_lines=12, max_characters=17)
    assert len(short) <= 17
    assert decoded.text == text


@pytest.mark.parametrize('max_lines,max_characters', [(0, 2000), (-1, 2000), (12, 0), (12, -1)])
def test_preview_rejects_nonpositive_limits(tmp_path, max_lines, max_characters):
    decoded = decode_source(snapshot(tmp_path, '合成正文'.encode('utf-8')))
    with pytest.raises(ValueError):
        decoded.preview(max_lines=max_lines, max_characters=max_characters)


@pytest.mark.parametrize('offset', [-1, 4])
def test_byte_offset_rejects_positions_outside_text(tmp_path, offset):
    decoded = decode_source(snapshot(tmp_path, '中😀A'.encode('utf-8')))
    with pytest.raises(ValueError):
        decoded.byte_offset(offset)
