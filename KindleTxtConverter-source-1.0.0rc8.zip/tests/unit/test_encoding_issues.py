"""TASK-005-11 的原文定位、提示预览及只读行为检查。"""

from dataclasses import FrozenInstanceError
import json

import pytest

from kindle_converter.core.cleaning import CleaningError, analyze_cleaning
from kindle_converter.core.encoding import EncodingIssue, decode_source
from kindle_converter.core.source import read_source
from kindle_converter.main import main


def snapshot(tmp_path, data: bytes):
    path = tmp_path / '专用测试文本.txt'
    path.write_bytes(data)
    return read_source(path)


@pytest.mark.parametrize('codec,bom', [
    ('utf-8', b'\xef\xbb\xbf'),
    ('utf-16-le', b'\xff\xfe'),
    ('utf-16-be', b'\xfe\xff'),
    ('gb18030', b''),
])
def test_issue_spans_in_mixed_physical_lines_and_original_bytes(tmp_path, codec, bom):
    prefix = '甲𠀀😀\r\n\r'
    third_row = '乙\x01中\ufffd\x7f\f\u2028尾'
    fourth_row = '丙\ufffd'
    text = prefix + third_row + '\n' + fourth_row
    source = snapshot(tmp_path, bom + text.encode(codec))
    before_mtime = source.path.stat().st_mtime_ns

    decoded = decode_source(source, codec)
    assert decoded.text == text
    assert decoded.issues == (
        EncodingIssue(
            line_number=3,
            start=len(prefix),
            end=len(prefix + third_row),
            byte_start=len(bom) + len(prefix.encode(codec)),
            byte_end=len(bom) + len((prefix + third_row).encode(codec)),
            first_marker=len(prefix) + 1,
            replacement_count=1,
            control_count=2,
        ),
        EncodingIssue(
            line_number=4,
            start=len(prefix + third_row + '\n'),
            end=len(text),
            byte_start=len(bom) + len((prefix + third_row + '\n').encode(codec)),
            byte_end=len(source.content),
            first_marker=len(text) - 1,
            replacement_count=1,
            control_count=0,
        ),
    )
    assert decoded.issue_line_count == 2
    for issue, row in zip(decoded.issues, (third_row, fourth_row)):
        assert decoded.text[issue.start:issue.end] == row
        assert source.content[issue.byte_start:issue.byte_end] == row.encode(codec)
    assert source.path.read_bytes() == source.content
    assert source.path.stat().st_mtime_ns == before_mtime


def test_multiple_signals_share_a_line_and_keep_existing_warnings(tmp_path):
    row = '正文\x00\x08\x0b\x0e\x1f\x7f\t\f\ufffd\ufffd'
    decoded = decode_source(snapshot(tmp_path, row.encode('utf-8')), 'utf-8')
    issue, = decoded.issues
    assert decoded.issue_line_count == 1
    assert issue.line_number == 1
    assert issue.first_marker == len('正文')
    assert issue.replacement_count == 2
    assert issue.control_count == 6
    assert decoded.requires_confirmation is True
    assert any('替代字符' in warning for warning in decoded.warnings)
    assert any('异常控制字符' in warning for warning in decoded.warnings)
    assert decoded.preview_issue(1) == row


def test_rare_characters_layout_and_written_marker_names_are_not_issues(tmp_path):
    text = '罕见字𠀀与表情😀\t\f\x85\x9f\u2028\u2029\u200d\r\n' + r'字面写法 \ufffd \x01 U+FFFD'
    decoded = decode_source(snapshot(tmp_path, text.encode('utf-8')))
    assert decoded.text == text
    assert decoded.issues == ()
    assert decoded.issue_line_count == 0
    assert decoded.warnings == ()
    assert decoded.requires_confirmation is False


def test_uncertain_codec_confirmation_stays_separate_from_issue_locations(tmp_path):
    source = snapshot(tmp_path, b'Plain ASCII text.\r\nAnother line.')
    automatic = decode_source(source)
    assert automatic.confidence == 'tentative'
    assert automatic.requires_confirmation is True
    assert automatic.warnings
    assert automatic.issues == ()
    assert automatic.issue_line_count == 0
    manual = decode_source(source, 'utf-8')
    assert manual.confidence == 'manual'
    assert manual.requires_confirmation is False
    assert manual.issue_line_count == 0


@pytest.mark.parametrize('before_marker', [0, 1500, 3000])
def test_issue_preview_keeps_marker_at_either_end_or_middle_of_long_line(tmp_path, before_marker):
    row = '前' * before_marker + '\ufffd' + '尾' * (3000 - before_marker)
    text = '首行内容\r\n\r\n' + row + '\r下一行内容'
    decoded = decode_source(snapshot(tmp_path, text.encode('utf-8')))
    issue, = decoded.issues
    assert issue.line_number == 3
    assert decoded.text[issue.first_marker] == '\ufffd'

    default_preview = decoded.preview_issue(3)
    assert '\ufffd' in default_preview and len(default_preview) <= 200
    for limit in (1, 17, 2000):
        preview = decoded.preview_issue(3, max_characters=limit)
        assert '\ufffd' in preview and len(preview) <= limit
        assert preview in row
    assert decoded.text == text


@pytest.mark.parametrize('line_number,max_characters', [
    (0, 200), (2, 200), ('1', 200), (1, 0), (1, 2001), (1, 1.5),
])
def test_issue_preview_rejects_unknown_line_or_invalid_limit(tmp_path, line_number, max_characters):
    text = '合成\ufffd首行\n普通第二行'
    decoded = decode_source(snapshot(tmp_path, text.encode('utf-8')))
    with pytest.raises(ValueError):
        decoded.preview_issue(line_number, max_characters=max_characters)


def test_location_limit_retains_first_hundred_but_counts_later_issue_rows(tmp_path):
    text = '甲\ufffd\ufffd乙\r\n正常行\r' * 124 + '末\ufffd行'
    decoded = decode_source(snapshot(tmp_path, text.encode('utf-8')))
    assert decoded.issue_line_count == 125
    assert tuple(issue.line_number for issue in decoded.issues) == tuple(range(1, 200, 2))
    assert all(issue.replacement_count == 2 for issue in decoded.issues)
    assert decoded.preview_issue(199) == '甲\ufffd\ufffd乙'
    with pytest.raises(ValueError):
        decoded.preview_issue(201)


def test_issue_record_is_immutable_and_default_repr_hides_source(tmp_path):
    private = 'ENCODING_ISSUE_PRIVATE_合成正文'
    source = snapshot(tmp_path, (private + '\ufffd').encode('utf-8'))
    decoded = decode_source(source)
    issue, = decoded.issues
    with pytest.raises(FrozenInstanceError):
        issue.line_number = 2
    assert private in decoded.preview_issue(1)
    for output in (repr(decoded), repr(issue)):
        assert private not in output
        assert str(source.path) not in output


def test_encoding_issue_stays_out_of_cleanup_and_control_confirmation_remains(tmp_path):
    text = '正\ufffd文\r\n补\x01充'
    decoded = decode_source(snapshot(tmp_path, text.encode('utf-8')))
    assert decoded.issue_line_count == 2
    with pytest.raises(CleaningError):
        analyze_cleaning(decoded)

    plan = analyze_cleaning(decoded, encoding_confirmed=True)
    change, = plan.changes
    assert change.rule_id == 'STD-012' and change.original == '\x01'
    assert plan.default_selected_ids == ()
    assert plan.render(plan.default_selected_ids) == text
    with pytest.raises(CleaningError):
        plan.render((change.id,))
    assert plan.render((change.id,), confirmed_review_ids=(change.id,)) == '正\ufffd文\r\n补充'
    assert plan.render() == text


def test_cli_reports_only_issue_positions_counts_and_existing_metadata(tmp_path, capsys):
    prefix = 'ENCODING_ISSUE_PRIVATE_首行\r\n'
    row = 'PRIVATE_疑似乱码\ufffd正文'
    text = prefix + row + '\r\n'
    source = snapshot(tmp_path, text.encode('utf-8-sig'))
    assert main(['--detect-encoding', str(source.path)]) == 0
    output = capsys.readouterr().out
    report = json.loads(output)
    assert report['encoding'] == 'utf-8' and report['bom_bytes'] == 3
    assert report['source_sha256'] == source.sha256
    assert report['character_count'] == len(text)
    assert report['requires_confirmation'] is True and report['warnings']
    assert report['issue_line_count'] == 1
    assert report['issues'] == [{
        'line_number': 2,
        'start': len(prefix),
        'end': len(prefix + row),
        'byte_start': len(prefix.encode('utf-8-sig')),
        'byte_end': len((prefix + row).encode('utf-8-sig')),
        'first_marker': len(prefix) + row.index('\ufffd'),
        'replacement_count': 1,
        'control_count': 0,
    }]
    assert 'ENCODING_ISSUE_PRIVATE' not in output and 'PRIVATE_疑似乱码' not in output
    assert str(source.path) not in output and source.path.name not in output
