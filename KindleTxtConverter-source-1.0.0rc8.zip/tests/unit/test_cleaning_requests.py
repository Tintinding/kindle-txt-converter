"""求收藏/推荐语的独立手标、正文保护、确认及可恢复边界。"""

from collections import Counter
from dataclasses import replace
import json
from pathlib import Path

import pytest

from kindle_converter.core.cleaning import CleaningError, analyze_cleaning, load_rules
from kindle_converter.core.encoding import decode_source
from kindle_converter.core.source import read_source


ROOT = Path(__file__).resolve().parents[2]
CASES = json.loads((ROOT / 'tests/fixtures/cleaning_request_cases.json').read_text(encoding='utf-8'))['cases']


def make_plan(tmp_path, text, codec='utf-8', bom=b''):
    path = tmp_path / '独立合成求推荐语.txt'
    path.write_bytes(bom + text.encode(codec))
    source = read_source(path)
    before_mtime = path.stat().st_mtime_ns
    decoded = decode_source(source, encoding=codec)
    plan = analyze_cleaning(decoded, encoding_confirmed=True)
    assert path.stat().st_mtime_ns == before_mtime
    assert path.read_bytes() == source.content
    return source, decoded, plan


@pytest.mark.parametrize('case', CASES, ids=[c['id'] for c in CASES])
def test_human_labeled_requests_and_preserved_body_cases(tmp_path, case):
    source, decoded, plan = make_plan(tmp_path, case['text'])
    assert Counter(c.rule_id for c in plan.changes if c.default_selected) == Counter(case['expected_default_rule_ids'])
    assert Counter(c.rule_id for c in plan.changes if c.risk == 'review') == Counter(case['expected_review_rule_ids'])
    assert len(plan.changes) == len(case['expected_default_rule_ids']) + len(case['expected_review_rule_ids'])
    assert plan.render() == case['text']
    assert plan.render(plan.default_selected_ids) == case['text']
    ids = tuple(c.id for c in plan.changes)
    reviews = tuple(c.id for c in plan.changes if c.risk == 'review')
    if reviews:
        with pytest.raises(CleaningError):
            plan.render(ids)
    assert plan.render(ids, confirmed_review_ids=reviews) == case['expected_applied_text']
    assert plan.render() == case['text']
    for change in plan.changes:
        assert decoded.text[change.start:change.end] == change.original
        assert change.byte_start == decoded.byte_offset(change.start)
        assert change.byte_end == decoded.byte_offset(change.end)
        assert source.content[change.byte_start:change.byte_end] == change.original.encode(decoded.encoding)
        if change.rule_id == 'STD-013':
            assert change.category == 'C06' and change.risk == 'review'
            assert not change.default_selected and change.replacement == ''
    assert all(a.end <= b.start for a, b in zip(plan.changes, plan.changes[1:]))
    assert source.path.read_bytes() == source.content


@pytest.mark.parametrize('codec,bom', [('utf-16-le', b'\xff\xfe'), ('utf-16-be', b'\xfe\xff'), ('gb18030', b'')])
def test_request_positions_after_emoji_keep_original_line_endings_and_bytes(tmp_path, codec, bom):
    text = '合成正文😀𠀀。\r\n\r\n　求收藏！\r\n\r\n求推荐票！\r'
    source, _, plan = make_plan(tmp_path, text, codec, bom)
    first, second = plan.changes
    assert first.original == '　求收藏！\r\n' and first.line_number == 3
    assert second.original == '求推荐票！\r' and second.line_number == 5
    for change in plan.changes:
        assert change.byte_start == len(bom) + len(text[:change.start].encode(codec))
        assert change.byte_end == len(bom) + len(text[:change.end].encode(codec))
        assert source.content[change.byte_start:change.byte_end] == change.original.encode(codec)
    ids = tuple(c.id for c in plan.changes)
    assert plan.render(ids, confirmed_review_ids=ids) == '合成正文😀𠀀。\r\n\r\n\r\n'
    assert plan.render() == text


def test_encoding_confirmation_never_authorizes_request_removal(tmp_path):
    _, decoded, _ = make_plan(tmp_path, '求收藏！\n', codec='gb18030')
    uncertain = replace(decoded, requires_confirmation=True, warnings=('请确认编码。',))
    with pytest.raises(CleaningError):
        analyze_cleaning(uncertain)
    plan = analyze_cleaning(uncertain, encoding_confirmed=True)
    change, = plan.changes
    with pytest.raises(CleaningError):
        plan.render((change.id,))
    assert plan.render((change.id,), confirmed_review_ids=(change.id,)) == ''
    assert plan.render() == decoded.text


def test_requests_can_be_confirmed_and_restored_individually(tmp_path):
    text = '求收藏！\n\n求推荐！\n'
    _, _, plan = make_plan(tmp_path, text)
    first, second = plan.changes
    assert plan.render((first.id,), confirmed_review_ids=(first.id,)) == '\n求推荐！\n'
    with pytest.raises(CleaningError):
        plan.render((first.id, second.id), confirmed_review_ids=(first.id,))
    ids = (first.id, second.id)
    assert plan.render(ids, confirmed_review_ids=ids) == '\n'
    assert plan.render((second.id,), confirmed_review_ids=(second.id,)) == '求收藏！\n\n'
    assert plan.render(()) == text


def test_mixed_request_advertisement_and_html_changes_are_independent(tmp_path):
    text = '前文。\n\n求收藏！\n\n更多精彩小说，请访问：https://fiction.invalid/book\n\n<b>合成&amp;文本</b>\n'
    _, _, plan = make_plan(tmp_path, text)
    assert tuple(c.rule_id for c in plan.changes) == ('STD-013', 'STD-001', 'STD-011')
    assert plan.render(plan.default_selected_ids) == '前文。\n\n求收藏！\n\n\n<b>合成&amp;文本</b>\n'
    ids = tuple(c.id for c in plan.changes)
    reviews = tuple(c.id for c in plan.changes if c.risk == 'review')
    assert plan.render(ids, confirmed_review_ids=reviews) == '前文。\n\n\n\n合成&文本\n'
    assert plan.render() == text


def test_request_removal_does_not_implicitly_merge_remaining_blank_lines(tmp_path):
    text = '求收藏！\n\n\n尾文。\n'
    _, _, plan = make_plan(tmp_path, text)
    request, blank = plan.changes
    assert (request.rule_id, blank.rule_id) == ('STD-013', 'STD-009')
    assert plan.render(plan.default_selected_ids) == '求收藏！\n\n尾文。\n'
    assert plan.render((request.id,), confirmed_review_ids=(request.id,)) == '\n\n尾文。\n'
    assert plan.render((request.id, blank.id), confirmed_review_ids=(request.id,)) == '\n尾文。\n'
    assert plan.render() == text


def test_disabled_request_rule_preserves_fixed_requests(tmp_path):
    _, decoded, _ = make_plan(tmp_path, '求收藏！\n')
    rules = load_rules()
    disabled = replace(rules, rules=tuple(replace(r, default_enabled=False) if r.id == 'STD-013' else r for r in rules.rules))
    plan = analyze_cleaning(decoded, rules=disabled)
    assert plan.changes == () and plan.render() == decoded.text


@pytest.mark.parametrize('text', [
    '<pre>\n\n求收藏！\n\n</pre>\n\n求推荐！\n',
    '```text\n\n求收藏！\n\n```\n\n求推荐！\n',
])
def test_literal_examples_remain_protected_when_html_cleaning_is_disabled(tmp_path, text):
    _, decoded, _ = make_plan(tmp_path, text)
    rules = load_rules()
    disabled = replace(rules, rules=tuple(replace(r, default_enabled=False) if r.id == 'STD-011' else r for r in rules.rules))
    plan = analyze_cleaning(decoded, rules=disabled)
    change, = plan.changes
    assert change.rule_id == 'STD-013' and change.original == '求推荐！\n'
    assert plan.render((change.id,), confirmed_review_ids=(change.id,)) == text.removesuffix('求推荐！\n')
    assert plan.render() == text


def test_changed_request_configuration_invalidates_previous_confirmations(tmp_path):
    _, decoded, old = make_plan(tmp_path, '求收藏！\n')
    rules = load_rules()
    reordered = replace(rules, rules=tuple(replace(r, values=tuple(reversed(r.values))) if r.id == 'STD-013' else r for r in rules.rules))
    new = analyze_cleaning(decoded, rules=reordered)
    old_change, = old.changes
    new_change, = new.changes
    assert old_change.original == new_change.original and old_change.id != new_change.id
    with pytest.raises(CleaningError):
        new.render((old_change.id,), confirmed_review_ids=(old_change.id,))


def test_request_preview_is_explicit_and_metadata_hides_body(tmp_path):
    secret = 'PRIVATE_REQUEST_合成正文'
    source, _, plan = make_plan(tmp_path, secret + '\n\n求收藏！\n')
    change, = plan.changes
    preview = plan.preview(change.id)
    assert preview.before == '求收藏！\n' and preview.after == ''
    assert secret in preview.context_before
    for output in (repr((plan, change, preview)), json.dumps(plan.summary(), ensure_ascii=False)):
        assert secret not in output and str(source.path) not in output
        assert change.original not in output


@pytest.mark.parametrize('fault', ['low_risk', 'default_selected', 'nonliteral_match', 'missing_values'])
def test_request_configuration_enforces_fixed_phrases_and_confirmation(tmp_path, fault):
    payload = json.loads((ROOT / 'rules/standard.json').read_text(encoding='utf-8'))
    rule = next(r for r in payload['rules'] if r['id'] == 'STD-013')
    if fault == 'low_risk':
        rule['risk'] = 'low'
    elif fault == 'default_selected':
        rule['default_selected'] = True
    elif fault == 'nonliteral_match':
        rule['match'] = {'kind': 'prefix_url', 'prefixes': ['求收藏']}
    else:
        del rule['match']['values']
    path = tmp_path / '合成求推荐规则.json'
    path.write_text(json.dumps(payload, ensure_ascii=False), encoding='utf-8')
    with pytest.raises(CleaningError) as failure:
        load_rules(path)
    assert str(failure.value) and str(path) not in str(failure.value)


@pytest.mark.parametrize('line_length,expected_count', [(240, 1), (241, 0)])
def test_request_line_length_limit_uses_untrimmed_source_row(tmp_path, line_length, expected_count):
    text = ' ' * (line_length - 4) + '求收藏！\n'
    _, _, plan = make_plan(tmp_path, text)
    assert len(plan.changes) == expected_count
    assert plan.render() == text
