"""独立标注的标题形式、上下文和原文位置检查。"""

from dataclasses import replace
from hashlib import sha256
from pathlib import Path

import pytest

from kindle_converter.core.chapters import ChapterEditor, ChapterError, analyze_chapters
from kindle_converter.core.encoding import decode_source
from kindle_converter.core.source import SourceSnapshot


def decode_text(text, *, codec='utf-8', bom=b''):
    raw = bom + text.encode(codec)
    snapshot = SourceSnapshot(Path('合成章节样例.txt'), len(raw), sha256(raw).hexdigest(), raw)
    return snapshot, decode_source(snapshot, codec)


@pytest.mark.parametrize(('title', 'kind', 'number', 'volume'), [
    ('第一章', 'chapter', 1, None),
    ('第一百二十章', 'chapter', 120, None),
    ('第123章', 'chapter', 123, None),
    ('第001章', 'chapter', 1, None),
    ('第００７回', 'chapter', 7, None),
    ('第〇〇九章', 'chapter', 9, None),
    ('第两百零三节', 'chapter', 203, None),
    ('第一万零五章', 'chapter', 10005, None),
    ('第十二万三千二百章', 'chapter', 123200, None),
    ('第0章', 'chapter', 0, None),
    ('第一卷 远山', 'volume', 1, None),
    ('第０２卷：春潮', 'volume', 2, None),
    ('第二卷 第一章', 'chapter', 1, 2),
    ('第三卷：第一百二十章：归途', 'chapter', 120, 3),
    ('第十章 洞天开启', 'chapter', 10, None),
    ('第一章：初入仙途', 'chapter', 1, None),
    ('序章', 'special', None, None),
    ('楔子', 'special', None, None),
    ('引子', 'special', None, None),
    ('尾声', 'special', None, None),
    ('番外一', 'special', 1, None),
    ('番外００２：寒江', 'special', 2, None),
], ids=[
    'chinese', 'hundreds', 'arabic', 'padded', 'fullwidth', 'chinese_digits', 'internal_zero',
    'ten_thousand', 'grouped', 'zero', 'volume', 'fullwidth_volume', 'inline_volume',
    'inline_subtitle', 'space_subtitle', 'colon_subtitle', 'prologue', 'wedge',
    'introduction', 'epilogue', 'extra', 'numbered_extra',
])
def test_common_heading_shapes_keep_the_display_title(title, kind, number, volume):
    _, decoded = decode_text(title + '\n\n一阵风吹过旧桥。\n')
    analysis = analyze_chapters(decoded)
    heading, = analysis.headings
    assert (heading.title, heading.kind, heading.number, heading.volume_number) == (title, kind, number, volume)
    assert heading.line_number == 1
    assert analysis.warnings == ()


@pytest.mark.parametrize('text', [
    '第1二章', '第十十章', '第一百二章', '第一万五章', '第一卷 第二卷',
    '第一章开头他就走到了桥边', '第一章 讲的是村口的事。', '第一章：',
    '第一章 ' + '山' * 60, '第一章：https://fiction.invalid/read',
    '她把第一章放到书架上', '“第一章”', '前言\u2028第一章',
], ids=[
    'mixed_number', 'repeated_unit', 'ambiguous_number', 'missing_zero', 'double_volume',
    'attached_prose', 'sentence', 'empty_subtitle', 'long_line', 'url',
    'inline_reference', 'quoted_line', 'unicode_separator',
])
def test_invalid_or_prose_lines_leave_an_empty_navigation(text):
    _, decoded = decode_text(text)
    analysis = analyze_chapters(decoded)
    assert analysis.headings == ()
    assert analysis.warnings == ('未识别到章节标题，可继续转换。',)


@pytest.mark.parametrize('text', ['第一章\x0b登岸', '第一章 残缺\ufffd'], ids=['control', 'replacement_character'])
def test_encoding_confirmation_does_not_turn_damaged_lines_into_headings(text):
    _, decoded = decode_text(text)
    assert decoded.requires_confirmation
    with pytest.raises(ChapterError, match='确认编码'):
        analyze_chapters(decoded)
    assert analyze_chapters(decoded, encoding_confirmed=True).headings == ()


def test_recognizes_a_titled_chapter_directly_after_a_volume_and_bare_markers_between_prose():
    text = '第一卷 远山\r\n第一章 灯火\r\n她走了很久。\r\n第002章\r\n正文相连。\r\n第三章 桥口\r\n她没有回头。'
    _, decoded = decode_text(text)
    headings = analyze_chapters(decoded).headings
    assert [(heading.kind, heading.number, heading.line_number) for heading in headings] == [
        ('volume', 1, 1), ('chapter', 1, 2), ('chapter', 2, 4),
    ]


def test_continuous_titled_chapters_with_an_initial_boundary_can_touch_body():
    text = '第一章 雾起\n她上了船。\n第二章 渡口\n风一直没停。\n第三章 回家\n老屋还在。'
    _, decoded = decode_text(text)
    assert [item.line_number for item in analyze_chapters(decoded).headings] == [1, 3, 5]


def test_titled_number_sequence_without_a_boundary_does_not_promote_prose():
    text = '她指着书说\n第一章 发生在家乡\n第二章 写到了渡口\n第三章 是重逢的场景\n她继续讲'
    _, decoded = decode_text(text)
    assert analyze_chapters(decoded).headings == ()


@pytest.mark.parametrize(('opening', 'closing'), [
    ('“', '”'), ('‘', '’'), ('「', '」'), ('『', '』'), ('"', '"'),
], ids=['double', 'single', 'corner', 'nested_corner', 'ascii'])
def test_balanced_cross_line_quotes_exclude_only_quoted_candidates(opening, closing):
    text = (
        '他抄下' + opening + '\n\n第九章 引文\n\n' + closing
        + '然后收好纸条。\n\n第一章 归来\n\n正文继续。'
    )
    _, decoded = decode_text(text)
    headings = analyze_chapters(decoded).headings
    assert [(heading.number, heading.line_number) for heading in headings] == [(1, 7)]


def test_unclosed_quote_does_not_hide_the_remainder_of_the_book():
    text = '门上留了一句未闭合的话：“\n\n第一章 雾起\n\n正文。\n\n第二章 风停\n\n接着是正文。'
    _, decoded = decode_text(text)
    assert [heading.number for heading in analyze_chapters(decoded).headings] == [1, 2]


def test_colon_introduction_and_literal_blocks_are_preserved_as_prose():
    text = (
        '有人在扉页写下：\n\n第八章\n\n'
        '<pre>\n~~~text\n\n第九章 示例\n\n</pre>\n\n'
        '~~~text\n<pre>\n\n第十章 示例\n\n~~~\n\n'
        '第一章 归来\n\n正文。'
    )
    _, decoded = decode_text(text)
    assert [heading.number for heading in analyze_chapters(decoded).headings] == [1]


def test_repeated_titles_have_distinct_original_positions():
    _, decoded = decode_text('第一章\n第一章\n\n正文。')
    analysis = analyze_chapters(decoded)
    repeated, = analysis.duplicates
    assert analysis.headings == (repeated.kept,)
    assert [(heading.line_number, heading.start, heading.end)
            for heading in (repeated.kept, repeated.duplicate)] == [
        (1, 0, 3), (2, 4, 7),
    ]
    assert analysis.number_gaps == () and analysis.warnings == ()


@pytest.mark.parametrize(('codec', 'bom'), [('utf-16-le', b'\xff\xfe'), ('gb18030', b'')])
def test_repeated_titled_run_keeps_first_when_only_last_has_blank_boundary(codec, bom):
    title = '第一章 夜航'
    text = '舟边有一盏灯😀。\r\n　第一章 夜航 \r\n\t第一章 夜航\r第一章 夜航　\n\n船靠岸了。'
    snapshot, decoded = decode_text(text, codec=codec, bom=bom)
    analysis = analyze_chapters(decoded)
    first, = analysis.headings
    assert first.line_number == 2
    assert tuple(item.kept for item in analysis.duplicates) == (first, first)
    assert [item.duplicate.line_number for item in analysis.duplicates] == [3, 4]
    for heading in (first, *(item.duplicate for item in analysis.duplicates)):
        assert decoded.text[heading.start:heading.end] == title
        assert heading.byte_start == decoded.byte_offset(heading.start)
        assert snapshot.content[heading.byte_start:heading.byte_end] == title.encode(codec)
    assert bom + decoded.text.encode(codec) == snapshot.content


def test_complete_blank_lines_can_separate_repeat_copies():
    _, decoded = decode_text('第一章：风起\n \t　\r\n　第一章：风起\r\n\r\n正文。')
    analysis = analyze_chapters(decoded)
    first, = analysis.headings
    repeated, = analysis.duplicates
    assert first.line_number == 1
    assert repeated.kept == first and repeated.duplicate.line_number == 3


@pytest.mark.parametrize('between', [
    '这里是章节正文。\n',
    '\u00a0\n',
    '~~~text\n第一章\n~~~\n',
], ids=['prose', 'nonbreaking_space', 'code_block'])
def test_repeated_title_across_nonblank_content_keeps_both_entries(between):
    _, decoded = decode_text('第一章\n' + between + '第一章\n')
    analysis = analyze_chapters(decoded)
    assert [heading.title for heading in analysis.headings] == ['第一章', '第一章']
    assert analysis.duplicates == () and analysis.number_gaps == ()


@pytest.mark.parametrize('second', ['第001章 雾起', '第一章：雾起', '第一章 雾散'])
def test_matching_ordinal_alone_does_not_merge_different_display_titles(second):
    _, decoded = decode_text('第一章 雾起\n\n' + second + '\n')
    analysis = analyze_chapters(decoded)
    assert [heading.title for heading in analysis.headings] == ['第一章 雾起', second]
    assert analysis.duplicates == () and analysis.number_gaps == ()


def test_repetition_does_not_promote_unbounded_prose_to_a_chapter():
    _, decoded = decode_text('她开始概括。\n第一章 说的是那艘船\n第一章 说的是那艘船\n她继续往下念。')
    analysis = analyze_chapters(decoded)
    assert analysis.headings == () and analysis.duplicates == ()


def test_repeated_headings_inside_a_quote_do_not_affect_outside_heading():
    text = '她抄下：“\n\n第一章 雾起\n第一章 雾起\n\n”然后放下纸笔。\n\n第一章 雾起\n\n正文。'
    _, decoded = decode_text(text)
    analysis = analyze_chapters(decoded)
    heading, = analysis.headings
    assert heading.line_number == 8 and analysis.duplicates == ()


def test_titled_chapter_follows_the_physical_end_of_a_repeated_volume_title():
    _, decoded = decode_text('第一卷 春潮\n第一卷 春潮\n第一章 灯火\n她放下书。')
    analysis = analyze_chapters(decoded)
    assert [(heading.kind, heading.line_number) for heading in analysis.headings] == [('volume', 1), ('chapter', 3)]
    repeated, = analysis.duplicates
    assert repeated.kept == analysis.headings[0] and repeated.duplicate.line_number == 2


def test_number_jump_points_to_real_headings_and_adds_a_warning():
    _, decoded = decode_text('第001章\n这段是正文。\n第００４章\n正文接着走。\n第5章\n')
    analysis = analyze_chapters(decoded)
    first, fourth, fifth = analysis.headings
    assert [heading.number for heading in (first, fourth, fifth)] == [1, 4, 5]
    gap, = analysis.number_gaps
    assert (gap.previous, gap.current, gap.volume_number) == (first, fourth, None)
    assert (gap.previous.line_number, gap.current.line_number) == (1, 3)
    assert analysis.warnings == ('发现 1 处章节编号跳跃，请核对原文。',)


def test_numbering_restarts_with_a_new_explicit_volume():
    text = (
        '第一卷\n第8章\n第10章\n第二卷\n第1章\n第2卷 第3章\n'
        '第三卷 第20章\n第3卷 第21章\n第23章\n第四卷\n第100章\n'
    )
    _, decoded = decode_text(text)
    analysis = analyze_chapters(decoded)
    assert [(gap.volume_number, gap.previous.number, gap.current.number) for gap in analysis.number_gaps] == [
        (1, 8, 10), (2, 1, 3), (3, 21, 23),
    ]
    assert analysis.warnings == ('发现 3 处章节编号跳跃，请核对原文。',)


def test_special_titles_leave_chapter_sequence_intact_and_units_are_compared_separately():
    _, decoded = decode_text('第一章\n\n番外八\n\n第三章\n第8节\n第10节\n第14回\n第15回\n')
    analysis = analyze_chapters(decoded)
    assert [(gap.previous.unit, gap.previous.number, gap.current.number) for gap in analysis.number_gaps] == [
        ('章', 1, 3), ('节', 8, 10),
    ]
    assert [heading.kind for heading in analysis.headings].count('special') == 1


def test_same_and_backward_ordinals_do_not_imply_missing_chapters():
    _, decoded = decode_text('第九章 上\n\n第九章 下\n\n第四章\n第五章\n')
    analysis = analyze_chapters(decoded)
    assert [heading.number for heading in analysis.headings] == [9, 9, 4, 5]
    assert analysis.duplicates == () and analysis.number_gaps == () and analysis.warnings == ()


@pytest.mark.parametrize(('codec', 'bom'), [
    ('utf-8', b'\xef\xbb\xbf'), ('utf-16-be', b'\xfe\xff'), ('gb18030', b''),
])
def test_chapter_positions_map_to_the_original_bytes_without_normalizing_text(codec, bom):
    before = '合成前文😀𠀀。\r\n\r\n'
    indentation = ' \t　'
    title = '第二卷 第００２章：雨后𠀀'
    text = before + indentation + title + '　\r正文不改。'
    snapshot, decoded = decode_text(text, codec=codec, bom=bom)
    analysis = analyze_chapters(decoded)
    heading, = analysis.headings
    assert analysis.source_sha256 == snapshot.sha256 and analysis.encoding == codec
    assert heading.line_number == 3
    assert heading.start == len(before + indentation)
    assert decoded.text[heading.start:heading.end] == title
    assert heading.byte_start == len(bom) + len((before + indentation).encode(codec))
    assert snapshot.content[heading.byte_start:heading.byte_end] == title.encode(codec)
    assert decoded.text == text
    assert title not in repr(analysis)


def test_uncertain_encoding_requires_explicit_confirmation():
    _, decoded = decode_text('第一章 初见\n\n合成正文。')
    uncertain = replace(decoded, requires_confirmation=True)
    with pytest.raises(ChapterError, match='确认编码'):
        analyze_chapters(uncertain)
    assert analyze_chapters(uncertain, encoding_confirmed=True).headings[0].number == 1


@pytest.mark.parametrize(('codec', 'bom'), [
    ('utf-8', b'\xef\xbb\xbf'), ('utf-16-le', b'\xff\xfe'), ('gb18030', b''),
])
def test_manual_headings_use_original_line_order_and_byte_ranges(codec, bom):
    text = '开篇有一盏灯😀。\r\n \t　\r\t　她在桥头停了一会儿。 \t\r\n  最后回头。　'
    snapshot, decoded = decode_text(text, codec=codec, bom=bom)
    editor = ChapterEditor(decoded)
    assert editor.analysis.headings == ()

    last = editor.add(4, '　末尾？🙂  ', kind='special')
    first = editor.add(3, '「过桥。」')

    assert editor.headings == (first, last)
    assert [(heading.line_number, heading.kind, heading.title) for heading in editor.headings] == [
        (3, 'chapter', '「过桥。」'), (4, 'special', '末尾？🙂'),
    ]
    for heading, target in [(first, '她在桥头停了一会儿。'), (last, '最后回头。')]:
        assert heading.manually_added
        assert (heading.number, heading.volume_number, heading.unit) == (None, None, None)
        assert (heading.start, heading.end) == (text.index(target), text.index(target) + len(target))
        assert heading.byte_start == len(bom) + len(text[:heading.start].encode(codec))
        assert snapshot.content[heading.byte_start:heading.byte_end] == target.encode(codec)
    assert decoded.text == text
    assert editor.analysis.headings == ()


def test_edits_keep_automatic_diagnostics_and_original_numbering():
    title = '第二卷 第003章：旧名'
    text = f'第二卷\n{title}\n{title}\n正文。\n第005章\n'
    snapshot, decoded = decode_text(text)
    editor = ChapterEditor(decoded)
    initial = editor.analysis
    volume, third, fifth = initial.headings
    duplicate, = initial.duplicates
    gap, = initial.number_gaps

    renamed = editor.rename(2, '　重返旧城，序幕！ ')
    assert renamed == replace(third, title='重返旧城，序幕！')
    assert (renamed.number, renamed.volume_number, renamed.unit, renamed.manually_added) == (3, 2, '章', False)
    assert editor.headings == (volume, renamed, fifth)
    assert renamed.title not in repr(editor.headings)

    editor.remove(2)
    restored_location = editor.add(3, '使用第二处标题')
    assert restored_location.start == duplicate.duplicate.start
    assert editor.headings == (volume, restored_location, fifth)
    editor.remove(3)
    assert editor.headings == (volume, fifth)
    assert editor.analysis == initial == analyze_chapters(decoded)
    assert gap.previous == third and gap.current == fifth
    assert decoded.text.encode(decoded.encoding) == snapshot.content


def test_editor_can_remove_all_nodes_and_add_one_on_the_same_line():
    _, decoded = decode_text('第一章\r\n正文。')
    editor = ChapterEditor(decoded)
    original, = editor.headings
    editor.remove(1)
    assert editor.headings == ()
    with pytest.raises(ChapterError, match='没有目录节点'):
        editor.remove(1)
    with pytest.raises(ChapterError, match='没有目录节点'):
        editor.rename(1, '已删除')

    added = editor.add(1, '卷首', kind='volume')
    renamed = editor.rename(1, '雾海卷')
    assert added.kind == 'volume'
    assert editor.headings == (replace(added, title='雾海卷'),) == (renamed,)
    assert editor.analysis.headings == (original,)


@pytest.mark.parametrize('line_number', [0, -1, 1.0, True, '1'])
def test_editor_requires_positive_integer_line_numbers(line_number):
    _, decoded = decode_text('第一章\n正文。')
    editor = ChapterEditor(decoded)
    for operation, args in [
        (editor.add, ('新增',)), (editor.remove, ()), (editor.rename, ('改名',)),
    ]:
        with pytest.raises(ChapterError, match='正整数'):
            operation(line_number, *args)
    assert editor.headings == editor.analysis.headings


@pytest.mark.parametrize('line_number', [2, 3, 5])
def test_manual_add_rejects_blank_or_missing_source_line(line_number):
    _, decoded = decode_text('第一章\r\n \t　\r\u00a0\n还有正文。\n')
    editor = ChapterEditor(decoded)
    with pytest.raises(ChapterError, match='有内容'):
        editor.add(line_number, '自定义目录标题')
    assert editor.headings == editor.analysis.headings


@pytest.mark.parametrize('title', [
    None, '', ' \t\u00a0', '\n独立标题', '标题\r', '两行\u2028标题', '控制\x00字符',
    '标题\x85另一行', '标题\ud800',
], ids=['missing', 'empty', 'whitespace', 'leading_lf', 'trailing_cr', 'separator', 'control', 'nel', 'surrogate'])
def test_manual_add_and_rename_require_a_nonempty_single_line_title(title):
    _, decoded = decode_text('第一章\n正文。')
    editor = ChapterEditor(decoded)
    for operation, line_number in [(editor.add, 2), (editor.rename, 1)]:
        with pytest.raises(ChapterError, match='非空的单行'):
            operation(line_number, title)
    assert editor.headings == editor.analysis.headings


def test_failed_additions_do_not_replace_an_existing_node_or_set_an_unknown_type():
    _, decoded = decode_text('第一章\n正文。')
    editor = ChapterEditor(decoded)
    with pytest.raises(ChapterError, match='已有目录节点'):
        editor.add(1, '自定义标题')
    with pytest.raises(ChapterError, match='类型无效'):
        editor.add(2, '自定义标题', kind='part')
    assert editor.headings == editor.analysis.headings


def test_editor_requires_confirmation_when_the_source_does():
    _, decoded = decode_text('第一章\n正文。')
    uncertain = replace(decoded, requires_confirmation=True)
    with pytest.raises(ChapterError, match='确认编码'):
        ChapterEditor(uncertain)
    assert ChapterEditor(uncertain, encoding_confirmed=True).headings[0].number == 1
