import subprocess

import pytest

from kindle_converter.converter.calibre import (
    CalibreEngine, ConversionCancelled, ConversionControl, ConversionError, binary_summary,
)
from kindle_converter.converter.prepare import prepare_book


@pytest.mark.parametrize('encoding', ['utf-8-sig', 'utf-16', 'gb18030'])
def test_structure_preserves_body_and_escapes_markup(encoding):
    text = '第一章 初见\n正常正文与 https://example.com\n保留 <原文> & 角色对话。'
    book = prepare_book(text.encode(encoding), '测试书', '测试作者')
    assert book.text == text
    assert book.chapters == ['第一章 初见']
    assert '&lt;原文&gt; &amp;' in book.html
    assert 'https://example.com' in book.html


def test_decode_failure_is_reported_without_guessing():
    with pytest.raises(ValueError, match='无法可靠解码'):
        prepare_book(b'\xff', '测试', '测试', encoding='utf-8')


def test_existing_output_is_never_overwritten(tmp_path):
    source = tmp_path / 'source.txt'
    source.write_text('正常正文', encoding='utf-8')
    output = tmp_path / 'book.azw3'
    output.write_bytes(b'existing-user-file')
    with pytest.raises(ConversionError, match='已存在'):
        CalibreEngine(tmp_path).convert(source, output, '测试')
    assert output.read_bytes() == b'existing-user-file'


def test_output_cannot_replace_the_source_file(tmp_path):
    source = tmp_path / 'source.txt'
    source.write_text('正常正文', encoding='utf-8')
    with pytest.raises(ConversionError, match='输出不能覆盖原始 TXT 文件'):
        CalibreEngine(tmp_path).convert(source, source, '测试')
    assert source.read_text(encoding='utf-8') == '正常正文'


def test_timeout_never_commits_output_or_exposes_engine_text(tmp_path, monkeypatch):
    executable = tmp_path / 'converter/calibre/Calibre/ebook-convert.exe'
    executable.parent.mkdir(parents=True)
    executable.touch()
    source = tmp_path / 'source.txt'
    source.write_text('正常正文', encoding='utf-8')
    class TimeoutProcess:
        def __init__(self, *args, **kwargs):
            self.killed = False
        def communicate(self, timeout=None):
            if not self.killed:
                raise subprocess.TimeoutExpired('engine', 1, output=b'private-source-fragment')
            return b'', None
        def kill(self):
            self.killed = True
    monkeypatch.setattr(subprocess, 'Popen', TimeoutProcess)
    output = tmp_path / 'book.azw3'
    with pytest.raises(ConversionError, match='超时') as failure:
        CalibreEngine(tmp_path).convert(source, output, '测试')
    assert 'private-source-fragment' not in str(failure.value)
    assert not output.exists()


def test_fake_extension_cannot_pass_binary_validation(tmp_path):
    file = tmp_path / 'not-a-book.azw3'
    file.write_bytes(b'plain text pretending to be an ebook')
    with pytest.raises(ConversionError, match='不是有效'):
        binary_summary(file, 'azw3')


def test_cancelling_active_conversion_kills_process_and_leaves_no_output(tmp_path, monkeypatch):
    executable = tmp_path / 'converter/calibre/Calibre/ebook-convert.exe'
    executable.parent.mkdir(parents=True)
    executable.touch()
    source = tmp_path / 'source.txt'
    source.write_bytes('正常正文。'.encode())
    control = ConversionControl()
    killed = []

    class RunningProcess:
        def __init__(self, *args, **kwargs):
            self.killed = False

        def communicate(self, timeout=None):
            if not self.killed:
                assert control.cancel()
                raise subprocess.TimeoutExpired('engine', timeout)
            return b'', None

        def kill(self):
            self.killed = True
            killed.append(True)

    monkeypatch.setattr(subprocess, 'Popen', RunningProcess)
    output = tmp_path / 'book.azw3'
    with pytest.raises(ConversionCancelled):
        CalibreEngine(tmp_path).convert(source, output, control=control)
    assert killed and not output.exists()
    assert source.read_bytes() == '正常正文。'.encode()
    assert list((tmp_path / 'build/conversion-temp').iterdir()) == []


def test_cancellation_and_output_submission_share_a_single_boundary():
    cancelled = ConversionControl()
    saved = []
    assert cancelled.cancel()
    with pytest.raises(ConversionCancelled):
        cancelled.commit(lambda: saved.append(True))
    assert not saved
    completed = ConversionControl()
    completed.commit(lambda: saved.append(True))
    assert saved and not completed.cancel()
