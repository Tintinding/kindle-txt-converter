"""TASK-005-03 完整物理空行的人工标注、安全上下文与可恢复检查。"""

from collections import Counter
from dataclasses import replace
import json
from pathlib import Path

import pytest

from kindle_converter.core.cleaning import CleaningError, analyze_cleaning, load_rules
from kindle_converter.core.encoding import decode_source
from kindle_converter.core.source import read_source


PROJECT_ROOT = Path(__file__).resolve().parents[2]
CASE_PATH = PROJECT_ROOT / 'tests' / 'fixtures' / 'cleaning_blank_cases.json'
RULE_PATH = PROJECT_ROOT / 'rules' / 'standard.json'
CASES = json.loads(CASE_PATH.read_text(encoding='utf-8'))['cases']


def make_plan(tmp_path, text, *, codec='utf-8', bom=b''):
    path = tmp_path / '独立合成空行样本.txt'
    path.write_bytes(bom + text.encode(codec))
    source = read_source(path)
    decoded = decode_source(source, encoding=codec)
    # 本文件的标注聚焦空行规则；全空白或异常控制字符由单独测试确认编码门槛。
    return source, decoded, analyze_cleaning(decoded, encoding_confirmed=True)


@pytest.mark.parametrize('case', CASES, ids=[case['id'] for case in CASES])
def test_human_labeled_physical_blank_line_cases(tmp_path, case):
    source, decoded, plan = make_plan(tmp_path, case['text'])
    before_mtime = source.path.stat().st_mtime_ns
    assert plan.source_sha256 == source.sha256
    assert Counter(change.rule_id for change in plan.changes if change.default_selected) == Counter(case['expected_default_rule_ids'])
    assert Counter(change.rule_id for change in plan.changes if change.risk == 'review') == Counter(case['expected_review_rule_ids'])
    assert len(plan.changes) == len(case['expected_default_rule_ids']) + len(case['expected_review_rule_ids'])
    for change in plan.changes:
        assert change.original == decoded.text[change.start:change.end]
        assert change.replacement == ''
        assert change.byte_start == decoded.byte_offset(change.start)
        assert change.byte_end == decoded.byte_offset(change.end)
        assert not change.default_selected or change.risk == 'low'
    assert plan.render() == case['text']
    assert plan.render(plan.default_selected_ids) == case['expected_default_text']
    review_ids = tuple(change.id for change in plan.changes if change.risk == 'review')
    if review_ids:
        with pytest.raises(CleaningError):
            plan.render(review_ids)
        assert plan.render(review_ids, confirmed_review_ids=review_ids) == case['expected_review_text']
    assert plan.render() == case['text']
    assert plan.summary()['suggestion_count'] == len(plan.changes)
    assert source.path.read_bytes() == source.content
    assert source.path.stat().st_mtime_ns == before_mtime


def test_blank_runs_and_advertisements_are_ordered_disjoint_and_independently_selectable(tmp_path):
    case = next(case for case in CASES if case['id'] == 'BLK-018')
    _, _, plan = make_plan(tmp_path, case['text'])
    assert tuple(change.rule_id for change in plan.changes) == ('STD-009', 'STD-001', 'STD-009')
    first, advertisement, last = plan.changes
    assert first.end <= advertisement.start < advertisement.end <= last.start
    assert plan.render((first.id,)) == '甲\n\n更多精彩小说，请访问：https://fiction.invalid/book\n\n\n乙\n'
    assert plan.render((advertisement.id,)) == '甲\n\n\n\n\n乙\n'
    assert plan.render((last.id,)) == '甲\n\n\n更多精彩小说，请访问：https://fiction.invalid/book\n\n乙\n'
    # 全选后形成的新连续空行不能在本轮被额外清理。
    assert plan.render(plan.default_selected_ids) == '甲\n\n\n乙\n'
    assert plan.render() == case['text']


def test_utf16_bom_and_emoji_blank_run_byte_positions(tmp_path):
    text = '😀𠀀前文\r\n \t\r\n　\r\n\r\n尾声\r\n'
    source, _, plan = make_plan(tmp_path, text, codec='utf-16-le', bom=b'\xff\xfe')
    change, = plan.changes
    assert change.rule_id == 'STD-009'
    assert change.original == '　\r\n\r\n'
    assert change.byte_start == 2 + len(text[:change.start].encode('utf-16-le'))
    assert change.byte_end == 2 + len(text[:change.end].encode('utf-16-le'))
    assert source.content[change.byte_start:change.byte_end] == change.original.encode('utf-16-le')
    assert plan.render(plan.default_selected_ids) == '😀𠀀前文\r\n \t\r\n尾声\r\n'
    assert plan.render() == text
    assert source.path.read_bytes() == source.content


def test_horizontal_blank_lines_are_not_limited_by_advertisement_length_limit(tmp_path):
    first_blank = ' ' * 300 + '\r\n'
    text = '甲\n' + first_blank + '\t\r\n　\n乙\n'
    _, _, plan = make_plan(tmp_path, text)
    change, = plan.changes
    assert change.rule_id == 'STD-009'
    assert change.original == '\t\r\n　\n'
    assert plan.render(plan.default_selected_ids) == '甲\n' + first_blank + '乙\n'
    assert plan.render() == text


def test_all_blank_input_requires_encoding_confirmation_first(tmp_path):
    case = next(case for case in CASES if case['id'] == 'BLK-009')
    source, decoded, _ = make_plan(tmp_path, case['text'])
    assert decoded.requires_confirmation is True
    with pytest.raises(CleaningError):
        analyze_cleaning(decoded)
    confirmed = analyze_cleaning(decoded, encoding_confirmed=True)
    assert confirmed.render(confirmed.default_selected_ids) == '\t \r\n'
    assert source.path.read_bytes() == source.content


def test_disabled_blank_rule_proposes_no_changes(tmp_path):
    text = '甲\n\n\n乙\n'
    _, decoded, _ = make_plan(tmp_path, text)
    rules = load_rules()
    disabled = replace(rules, rules=tuple(replace(rule, default_enabled=False) if rule.id == 'STD-009' else rule for rule in rules.rules))
    plan = analyze_cleaning(decoded, rules=disabled)
    assert plan.changes == ()
    assert plan.render(plan.default_selected_ids) == text


def test_long_blank_group_preview_is_bounded_without_losing_recovery_text(tmp_path):
    text = '甲\n' + '\n' * 2500 + '乙\n'
    _, _, plan = make_plan(tmp_path, text)
    change, = plan.changes
    assert change.original == '\n' * 2499
    preview = plan.preview(change.id)
    assert len(preview.before) == 2000
    assert preview.before_truncated is True
    assert preview.after == ''
    assert preview.after_truncated is False
    short = plan.preview(change.id, change_characters=7)
    assert short.before == '\n' * 7
    assert short.before_truncated is True
    assert change.original == '\n' * 2499
    assert plan.render(plan.default_selected_ids) == '甲\n\n乙\n'
    assert plan.render() == text


def test_blank_rule_diagnostics_do_not_expose_source_or_path(tmp_path):
    secret = 'PRIVATE_SYNTHETIC_BLANK_正文不要记录'
    source, _, plan = make_plan(tmp_path, secret + '\n\n\n尾声。\n')
    change, = plan.changes
    preview = plan.preview(change.id)
    assert secret in preview.context_before
    for output in (json.dumps(plan.summary(), ensure_ascii=False), repr((plan, change, preview))):
        assert secret not in output
        assert str(source.path) not in output


@pytest.mark.parametrize('keep', [0, 2, '1', True, None], ids=['zero', 'two', 'string', 'bool', 'missing'])
def test_blank_rule_rejects_any_keep_value_other_than_integer_one(tmp_path, keep):
    payload = json.loads(RULE_PATH.read_text(encoding='utf-8'))
    rule = next(rule for rule in payload['rules'] if rule['id'] == 'STD-009')
    if keep is None:
        del rule['match']['keep_blank_lines']
    else:
        rule['match']['keep_blank_lines'] = keep
    path = tmp_path / '合成空行规则.json'
    path.write_text(json.dumps(payload, ensure_ascii=False), encoding='utf-8')
    with pytest.raises(CleaningError) as failure:
        load_rules(path)
    assert str(failure.value)
    assert str(path) not in str(failure.value)
