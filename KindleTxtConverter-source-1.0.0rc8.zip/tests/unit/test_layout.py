from xml.etree import ElementTree as ET
from zipfile import ZIP_STORED, ZipFile

import pytest

from kindle_converter.converter import epub
from kindle_converter.converter.epub import write_epub
from kindle_converter.converter.layout import LayoutOptions
from kindle_converter.converter.prepare import prepare_book


def test_default_layout_uses_relative_indent_spacing_and_chapter_breaks():
    style = LayoutOptions().stylesheet()
    assert "text-indent:2em" in style
    assert "margin:0 0 0.35em" in style
    assert "text-align:center" in style
    assert "page-break-before:always" in style
    assert "font-size" not in style
    assert "px" not in style


@pytest.mark.parametrize(("spacing", "margin"), [("compact", "0"), ("standard", "0.35em"), ("loose", "0.75em")])
def test_custom_layout_controls_xhtml_and_preserves_natural_paragraphs(spacing, margin):
    text = "第一章\r\n\r\n　第一段。\r\n\r\n第二段。"
    layout = LayoutOptions(1, spacing, "left", False)
    book = prepare_book(text.encode(), "版式检查", "测试作者", layout=layout)
    document = ET.fromstring(book.html)
    assert book.text == text
    style = document.find(".//{*}style").text
    assert f"margin:0 0 {margin}" in style
    assert "text-indent:1em" in style and "text-align:left" in style
    assert "page-break-before:always" not in style
    assert [node.text for node in document.iterfind(".//{*}p")] == ["第一段。", "第二段。"]


@pytest.mark.parametrize("settings", [
    {"indent": 3}, {"indent": True}, {"paragraph_spacing": "wide"}, {"heading_alignment": "right"},
    {"chapter_page_break": 1}, {"visible_toc": "true"},
])
def test_invalid_layout_options_are_rejected(settings):
    with pytest.raises(ValueError):
        LayoutOptions(**settings)


def test_visible_epub_contents_are_optional_and_link_to_real_xhtml_anchors(tmp_path):
    text = "第一卷\n第一章\n甲。\n第二章\n乙。".encode()
    for visible in (False, True):
        book = prepare_book(text, "版式检查", "测试作者", layout=LayoutOptions(visible_toc=visible))
        destination = tmp_path / f"visible-{visible}.epub"
        write_epub(destination, book, "版式检查", "测试作者")
        with ZipFile(destination) as archive:
            assert archive.infolist()[0].filename == "mimetype"
            assert archive.getinfo("mimetype").compress_type == ZIP_STORED
            opf = ET.fromstring(archive.read("OEBPS/book.opf"))
            assert (opf.find(".//{*}reference") is not None) == visible
            assert ("OEBPS/contents.xhtml" in archive.namelist()) == visible
            if visible:
                contents = ET.fromstring(archive.read("OEBPS/contents.xhtml"))
                identifiers = {node.get("id") for node in ET.fromstring(book.html).iter()}
                links = [node.get("href") for node in contents.iterfind(".//{*}a")]
                assert len(links) == 3
                assert all(href.split("#", 1)[1] in identifiers for href in links)


def test_epub_spine_splits_long_bodies_and_keeps_all_navigation_links(tmp_path, monkeypatch):
    monkeypatch.setattr(epub, "_SECTION_SIZE", 130)
    content = "第一章\n第一段。\n" + "正常正文留在同一阅读顺序。\n" * 8 + "第二章\n结束。"
    book = prepare_book(content.encode(), "分段验证", "", layout=LayoutOptions(visible_toc=True))
    path = tmp_path / "分段.epub"
    write_epub(path, book, "分段验证", "")
    with ZipFile(path) as archive:
        package = ET.fromstring(archive.read("OEBPS/book.opf"))
        manifest = {item.get("id"): item.get("href") for item in package.iterfind(".//{*}item")}
        texts = []
        for ref in package.iterfind(".//{*}itemref"):
            name = manifest[ref.get("idref")]
            if name.startswith("body"):
                document = ET.fromstring(archive.read("OEBPS/" + name))
                texts.extend(document.find(".//{*}body").itertext())
        assert len([file for file in manifest.values() if file.startswith("body")]) > 1
        assert "".join("".join(texts).split()) == "".join(content.split())
        ncx = ET.fromstring(archive.read("OEBPS/toc.ncx"))
        links = [item.get("src") for item in ncx.iterfind(".//{*}content")]
        assert len({link.split("#", 1)[0] for link in links}) == 2
        for link in links:
            name, anchor = link.split("#")
            document = ET.fromstring(archive.read("OEBPS/" + name))
            assert any(node.get("id") == anchor for node in document.iter())
