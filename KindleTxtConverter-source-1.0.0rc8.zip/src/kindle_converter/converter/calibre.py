"""项目内完整 Calibre 运行时适配器，验证通过后才提交最终文件。"""

from hashlib import file_digest, sha256
import os
from pathlib import Path
import struct
import subprocess
import shutil
import tempfile
from threading import Event, Lock
from time import monotonic
from collections.abc import Callable

from ..core.chapters import ChapterEditor
from ..core.cleaning_selection import CleaningSelection
from ..core.source import read_source
from ..services.paths import application_root, resource_root
from ..services.subprocess_environment import external_environment, external_dll_search
from .epub import write_epub
from .layout import LayoutOptions
from .metadata import book_language, read_cover
from .prepare import prepare_book, prepare_from_editor
from .validation import validate_oeb


class ConversionError(ValueError):
    """只包含阶段和错误类别，不包含小说正文的转换错误。"""


class ConversionCancelled(ConversionError):
    """用户在提交输出前取消了转换。"""


class ConversionControl:
    def __init__(self) -> None:
        self._requested = Event()
        self._lock = Lock()
        self._committed = False

    def cancel(self) -> bool:
        with self._lock:
            if self._committed:
                return False
            self._requested.set()
            return True

    def check(self) -> None:
        if self._requested.is_set():
            raise ConversionCancelled("转换已取消，未保存电子书。")

    def commit(self, save: Callable[[], None]) -> None:
        # 取消与最终发布共用一个提交边界。
        with self._lock:
            self.check()
            save()
            self._committed = True


def binary_summary(path: Path, expected_format: str) -> dict:
    data = path.read_bytes()
    if len(data) < 100 or data[60:68] != b'BOOKMOBI':
        raise ConversionError('输出不是有效的 Kindle PalmDB/MOBI 文件。')
    records = struct.unpack_from('>H', data, 76)[0]
    if records < 1 or 78 + records * 8 > len(data):
        raise ConversionError('电子书记录表不完整。')
    offsets = [struct.unpack_from('>I', data, 78 + i * 8)[0] for i in range(records)]
    if offsets != sorted(offsets) or offsets[0] < 78 + records * 8 or offsets[-1] >= len(data):
        raise ConversionError('电子书记录位置无效。')
    mobi = offsets[0] + 16
    if data[mobi:mobi + 4] != b'MOBI' or mobi + 24 > len(data):
        raise ConversionError('缺少完整 MOBI 头。')
    version = struct.unpack_from('>I', data, mobi + 20)[0]
    if version != (8 if expected_format == 'azw3' else 6):
        raise ConversionError('电子书实际编码格式与要求不一致。')
    return {'bytes': len(data), 'sha256': sha256(data).hexdigest(), 'mobi_version': version, 'records': records}


class CalibreEngine:
    def __init__(self, root: Path | None = None, timeout: int = 180):
        self.root = (root or application_root()).resolve()
        self.runtime_root = resource_root() if self.root == application_root() else self.root
        self.executable = self.runtime_root / 'converter' / 'calibre' / 'Calibre' / 'ebook-convert.exe'
        self.timeout = timeout

    def _communicate(self, process: subprocess.Popen, control: ConversionControl | None) -> bytes:
        if control is None:
            stdout, _ = process.communicate(timeout=self.timeout)
            return stdout
        deadline = monotonic() + self.timeout
        while True:
            control.check()
            remaining = deadline - monotonic()
            if remaining <= 0:
                raise subprocess.TimeoutExpired(process.args, self.timeout)
            try:
                stdout, _ = process.communicate(timeout=min(0.15, remaining))
                return stdout
            except subprocess.TimeoutExpired:
                continue

    def _run(self, args: list[str], work: Path, stage: str, control: ConversionControl | None = None) -> bytes:
        if control is not None:
            control.check()
        if not self.executable.is_file():
            raise ConversionError('项目内缺少完整转换组件，请先初始化转换引擎。')
        env = os.environ.copy()
        for name, folder in (
            ('CALIBRE_CONFIG_DIRECTORY', 'config'), ('CALIBRE_CACHE_DIRECTORY', 'cache'),
            ('CALIBRE_TEMP_DIR', 'temp'), ('TEMP', 'temp'), ('TMP', 'temp')
        ):
            directory = work / folder
            directory.mkdir(parents=True, exist_ok=True)
            env[name] = str(directory)
        env['CALIBRE_WORKER_TEMP_DIR'] = str(work / 'temp')
        try:
            with external_dll_search():
                process = subprocess.Popen(
                    [str(self.executable), *args], cwd=work, env=external_environment(env), shell=False,
                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                    creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0)
                )
            try:
                stdout = self._communicate(process, control)
            except (subprocess.TimeoutExpired, ConversionCancelled):
                process.kill()
                process.communicate()
                raise
        except subprocess.TimeoutExpired as error:
            raise ConversionError(f'{stage}超时，未提交输出文件。') from error
        except OSError as error:
            raise ConversionError(f'{stage}无法启动转换进程。') from error
        if process.returncode:
            # Calibre 的原始输出可能引用正文，不写入普通日志。
            raise ConversionError(f'{stage}失败（退出码 {process.returncode}），未提交输出文件。')
        return stdout

    def convert(
        self, source_path: Path, output: Path, title: str | None = None, author: str = '未知',
        encoding: str | None = None, *, editor: ChapterEditor | None = None, layout: LayoutOptions = LayoutOptions(),
        language: str = 'zh', description: str = '', cover: Path | None = None,
        cleaning: CleaningSelection | None = None,
        control: ConversionControl | None = None, progress: Callable[[int, str], None] | None = None,
    ) -> dict:
        def update(step: int, message: str) -> None:
            if control is not None:
                control.check()
            if progress is not None:
                progress(step, message)

        update(0, "正在检查输入与输出位置…")
        source = read_source(source_path)
        output = output.resolve()
        if output == source.path:
            raise ConversionError('输出不能覆盖原始 TXT 文件。')
        if output.exists():
            raise ConversionError('输出文件已存在，请使用新的文件名。')
        fmt = output.suffix.lower().lstrip('.')
        if fmt not in ('azw3', 'mobi'):
            raise ConversionError('只支持 AZW3 或 MOBI 输出。')
        if title is None:
            title = source.path.stem
        if not title.strip():
            raise ConversionError('书名不能为空。')
        language = book_language(language)
        cover_image = read_cover(cover) if cover is not None else None
        cleaned = cleaning.apply() if cleaning is not None else None
        expected_sha256 = source.sha256
        if cleaning is not None and cleaned is not None:
            cleaning.verify_application(cleaned, source)
            expected_sha256 = cleaned.result_utf8_sha256
            if editor is None:
                editor = ChapterEditor(cleaned.decoded_text())
        if editor is not None and editor.source.source_sha256 != expected_sha256:
            raise ConversionError('原始 TXT 已变化，请重新识别目录。')
        book = (prepare_book(source.content, title, author, encoding, layout=layout) if editor is None
                else prepare_from_editor(editor, title, layout=layout))
        update(1, "正在准备电子书内容…")
        work_root = (self.runtime_root / 'build' / 'conversion-temp').resolve()
        if not work_root.is_relative_to(self.runtime_root):
            raise ConversionError('临时目录超出项目范围。')
        work_root.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(prefix='job-', dir=work_root) as job:
            work = Path(job)
            version = self._run(['--version'], work, '引擎版本检查', control).decode('utf-8', errors='replace').strip()
            if 'calibre 9.18.0' not in version:
                raise ConversionError('引擎版本与当前验证基线不一致。')
            intermediate = work / 'input.epub'
            visible_toc = fmt == 'azw3' and layout.visible_toc
            write_epub(intermediate, book, title, author, visible_toc=visible_toc, language=language,
                       description=description, cover=cover_image)
            candidate = work / f'candidate.{fmt}'
            args = [str(intermediate), str(candidate), '--output-profile', 'kindle_pw3',
                    '--no-chapters-in-toc', '--chapter-mark', 'none', '--disable-font-rescaling']
            if fmt == 'mobi':
                args += ['--mobi-file-type', 'old']
            else:
                args += ['--no-inline-toc']
            update(2, f"正在生成 {fmt.upper()}…")
            self._run(args, work, '电子书转换', control)
            binary = binary_summary(candidate, fmt)
            roundtrip = work / 'roundtrip'
            update(3, "正在回读核对正文、书籍信息和目录…")
            self._run([str(candidate), str(roundtrip)], work, '输出回读', control)
            validation = validate_oeb(
                roundtrip, book.text, book.chapters, title, author, navigation=book.navigation,
                visible_toc=visible_toc, language=language, description=description, cover_expected=cover_image is not None,
            )
            if read_source(source.path).sha256 != source.sha256:
                raise ConversionError('验证期间原始 TXT 发生变化，未提交输出文件。')
            update(4, "正在保存已验证的电子书…")
            try:
                output.parent.mkdir(parents=True, exist_ok=True)
                # 单文件运行组件可能位于另一磁盘。先复制到目标目录再提交，
                # 保证最终改名在同一文件系统内，并在失败或取消时清理暂存文件。
                with tempfile.TemporaryDirectory(prefix='.kindle-', dir=output.parent) as staging:
                    staged = Path(staging) / candidate.name
                    shutil.copyfile(candidate, staged)
                    with staged.open('rb') as stream:
                        if file_digest(stream, 'sha256').hexdigest() != binary['sha256']:
                            raise ConversionError('输出文件复制校验失败，未提交电子书。')

                    def save() -> None:
                        # Windows rename 与硬链接均拒绝覆盖已有目标。
                        if os.name == 'nt':
                            os.rename(staged, output)
                        else:
                            os.link(staged, output)

                    if control is None:
                        save()
                    else:
                        control.commit(save)
            except OSError as error:
                raise ConversionError('无法安全保存输出，请检查位置、空间或同名文件。') from error
        update(5, "电子书已保存。")
        return {
            'format': fmt, 'engine': version, 'output_profile': 'kindle_pw3',
            'encoding': book.encoding, 'source_bytes': source.size_bytes, 'source_sha256': source.sha256,
            'original_unchanged': True, 'chapters': len(book.chapters), 'binary': binary,
            'chapter_warnings': list(book.chapter_warnings),
            'cleaning': cleaned.log_metadata() if cleaned is not None else None,
            'roundtrip': validation, 'physical_kindle_verified': False, 'standalone_verified': False,
        }
