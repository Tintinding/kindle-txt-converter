"""写入 Calibre 可读取的 EPUB 2 正文、包清单和结构化导航。"""

from html import escape
from pathlib import Path
import re
from uuid import uuid4
from xml.etree import ElementTree as ET
from zipfile import ZIP_DEFLATED, ZIP_STORED, ZipFile

from ..core.navigation import NavigationEntry
from .metadata import BookCover, book_language
from .prepare import PreparedBook, require_xml_text


_CONTAINER = """<?xml version="1.0" encoding="utf-8"?>
<container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container">
<rootfiles><rootfile full-path="OEBPS/book.opf" media-type="application/oebps-package+xml"/></rootfiles>
</container>"""
_SECTION_SIZE = 192 * 1024
_ANCHOR = re.compile(r' id="(section-[0-9]+)"')


def _body_documents(html: str) -> dict[str, str]:
    """在段落边界切分大文档，避免 Calibre 对单个大型 XHTML 反复扫描。"""
    head, _, body = html.partition("</head><body>")
    parts: list[str] = []
    documents = {}
    size = 0

    def add_document() -> None:
        number = len(documents) + 1
        name = "body.xhtml" if number == 1 else f"body-{number}.xhtml"
        documents[name] = head + "</head><body>" + "\n".join(parts) + "</body></html>"

    for block in body.removesuffix("</body></html>").split("\n"):
        block_size = len(block.encode("utf-8")) + 1
        if parts and size + block_size > _SECTION_SIZE:
            add_document()
            parts.clear()
            size = 0
        parts.append(block)
        size += block_size
    add_document()
    return documents


def _ncx(entries: tuple[NavigationEntry, ...], identifier: str, title: str, targets: dict[str, str]) -> bytes:
    root = ET.Element("ncx", {"xmlns": "http://www.daisy.org/z3986/2005/ncx/", "version": "2005-1"})
    head = ET.SubElement(root, "head")
    ET.SubElement(head, "meta", {"name": "dtb:uid", "content": identifier})
    ET.SubElement(head, "meta", {"name": "dtb:depth", "content": "2" if any(e.children for e in entries) else "1"})
    ET.SubElement(head, "meta", {"name": "dtb:totalPageCount", "content": "0"})
    ET.SubElement(head, "meta", {"name": "dtb:maxPageNumber", "content": "0"})
    ET.SubElement(ET.SubElement(root, "docTitle"), "text").text = title
    navmap = ET.SubElement(root, "navMap")
    order = 0

    def append(parent: ET.Element, nodes: tuple[NavigationEntry, ...]) -> None:
        nonlocal order
        for entry in nodes:
            order += 1
            point = ET.SubElement(parent, "navPoint", {"id": entry.anchor, "playOrder": str(order)})
            ET.SubElement(ET.SubElement(point, "navLabel"), "text").text = entry.title
            ET.SubElement(point, "content", {"src": f"{targets[entry.anchor]}#{entry.anchor}"})
            append(point, entry.children)

    append(navmap, entries)
    return ET.tostring(root, encoding="utf-8", xml_declaration=True)


def _contents(entries: tuple[NavigationEntry, ...], targets: dict[str, str]) -> str:
    def links(nodes: tuple[NavigationEntry, ...]) -> str:
        parts = []
        for entry in nodes:
            child_list = links(entry.children) if entry.children else ""
            href = f"{targets[entry.anchor]}#{entry.anchor}"
            parts.append(f'<li><a href="{href}">{escape(entry.title)}</a>{child_list}</li>')
        return "<ul>" + "".join(parts) + "</ul>"

    return ('<?xml version="1.0" encoding="utf-8"?>'
            '<html xmlns="http://www.w3.org/1999/xhtml"><head><title>目录</title></head>'
            f'<body><h1>目录</h1>{links(entries)}</body></html>')


def write_epub(
    path: Path, book: PreparedBook, title: str, author: str, *,
    visible_toc: bool | None = None, language: str = "zh", description: str = "", cover: BookCover | None = None,
) -> None:
    require_xml_text(title, "书名")
    require_xml_text(author, "作者")
    require_xml_text(description, "简介")
    language = book_language(language)
    identifier = f"urn:uuid:{uuid4()}"
    creators = "".join(f"<dc:creator>{escape(part.strip())}</dc:creator>" for part in author.split("&") if part.strip())
    summary = ""
    if description.strip():
        description_html = "<p>" + escape(description).replace("\r\n", "\n").replace("\r", "\n").replace("\n", "<br/>") + "</p>"
        summary = f"<dc:description>{escape(description_html)}</dc:description>"
    visible = book.layout.visible_toc if visible_toc is None else visible_toc
    documents = _body_documents(book.html)
    targets = {anchor: name for name, html in documents.items() for anchor in _ANCHOR.findall(html)}
    body_items = "".join(
        f'<item id="body-{index}" href="{name}" media-type="application/xhtml+xml"/>'
        for index, name in enumerate(documents, 1)
    )
    body_spine = "".join(f'<itemref idref="body-{index}"/>' for index in range(1, len(documents) + 1))
    toc_item = '<item id="contents" href="contents.xhtml" media-type="application/xhtml+xml"/>' if visible else ""
    toc_spine = '<itemref idref="contents"/>' if visible else ""
    guide = ['<reference type="toc" title="目录" href="contents.xhtml"/>'] if visible else []
    cover_meta = cover_items = cover_spine = ""
    if cover is not None:
        cover_meta = '<meta name="cover" content="cover-image"/>'
        cover_items = (f'<item id="cover-image" href="cover.{cover.extension}" media-type="{cover.media_type}"/>'
                       '<item id="cover-page" href="cover.xhtml" media-type="application/xhtml+xml"/>')
        cover_spine = '<itemref idref="cover-page" linear="no"/>'
        guide.insert(0, '<reference type="cover" title="封面" href="cover.xhtml"/>')
    guide_xml = "<guide>" + "".join(guide) + "</guide>" if guide else ""
    package = f"""<?xml version="1.0" encoding="utf-8"?>
<package xmlns="http://www.idpf.org/2007/opf" version="2.0" unique-identifier="book-id">
<metadata xmlns:dc="http://purl.org/dc/elements/1.1/">
<dc:identifier id="book-id">{identifier}</dc:identifier><dc:language>{language}</dc:language>
<dc:title>{escape(title)}</dc:title>{creators}{summary}{cover_meta}</metadata>
<manifest>{body_items}{toc_item}{cover_items}
<item id="toc" href="toc.ncx" media-type="application/x-dtbncx+xml"/></manifest>
<spine toc="toc">{cover_spine}{toc_spine}{body_spine}</spine>{guide_xml}
</package>"""
    with ZipFile(path, "x", compression=ZIP_DEFLATED) as archive:
        archive.writestr("mimetype", "application/epub+zip", compress_type=ZIP_STORED)
        archive.writestr("META-INF/container.xml", _CONTAINER)
        archive.writestr("OEBPS/book.opf", package)
        for name, html in documents.items():
            archive.writestr(f"OEBPS/{name}", html)
        archive.writestr("OEBPS/toc.ncx", _ncx(book.navigation, identifier, title, targets))
        if visible:
            archive.writestr("OEBPS/contents.xhtml", _contents(book.navigation, targets))
        if cover is not None:
            archive.writestr(f"OEBPS/cover.{cover.extension}", cover.content)
            archive.writestr(
                "OEBPS/cover.xhtml",
                '<?xml version="1.0" encoding="utf-8"?>'
                '<html xmlns="http://www.w3.org/1999/xhtml"><head><title>封面</title></head>'
                f'<body><div><img src="cover.{cover.extension}" alt="封面" style="max-width:100%"/></div></body></html>',
            )
