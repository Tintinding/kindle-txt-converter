"""按顺序转换多份 TXT，逐本报告结果。"""

from collections.abc import Callable, Iterable
from dataclasses import dataclass
from pathlib import Path

from ..core.cleaning import analyze_cleaning
from ..core.cleaning_selection import CleaningSelection
from ..core.encoding import decode_source
from ..core.source import read_source
from .calibre import CalibreEngine, ConversionCancelled, ConversionControl, ConversionError


@dataclass(frozen=True)
class BatchJob:
    source: Path
    output: Path


def batch_jobs(sources: Iterable[Path], directory: Path, fmt: str) -> tuple[BatchJob, ...]:
    if fmt not in ("azw3", "mobi"):
        raise ConversionError("批量转换只支持 AZW3 或 MOBI。")
    occupied = set()
    jobs = []
    for source in dict.fromkeys(path.resolve() for path in sources if path.suffix.lower() == ".txt"):
        candidate = directory / f"{source.stem}.{fmt}"
        number = 1
        while candidate.exists() or candidate in occupied:
            number += 1
            candidate = directory / f"{source.stem} ({number}).{fmt}"
        occupied.add(candidate)
        jobs.append(BatchJob(source, candidate))
    return tuple(jobs)


def run_batch(
    engine: CalibreEngine,
    jobs: tuple[BatchJob, ...],
    controls: tuple[ConversionControl, ...],
    update: Callable[[int, str, str], None],
    error_message: Callable[[Exception], str],
) -> None:
    for row, (job, control) in enumerate(zip(jobs, controls, strict=True)):
        try:
            control.check()
            update(row, "处理中", "读取 TXT 并分析标准清理")
            decoded = decode_source(read_source(job.source))
            if decoded.requires_confirmation:
                raise ConversionError("编码需要核对，请在单本窗口确认后转换。")
            cleaning = CleaningSelection(analyze_cleaning(decoded))

            def progress(step: int, message: str) -> None:
                update(row, "处理中", message)

            engine.convert(job.source, job.output, cleaning=cleaning, control=control, progress=progress)
        except ConversionCancelled as error:
            update(row, "已取消", str(error))
        except Exception as error:
            update(row, "失败", error_message(error))
        else:
            update(row, "成功", job.output.name)
