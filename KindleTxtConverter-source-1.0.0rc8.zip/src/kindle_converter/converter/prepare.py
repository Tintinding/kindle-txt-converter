"""将已解码正文与编辑后的目录生成可转换的 XHTML。"""

from dataclasses import dataclass, field
from hashlib import sha256
from html import escape
from pathlib import Path
import re

from ..core.chapters import ChapterEditor
from ..core.encoding import EncodingError, decode_source
from ..core.navigation import NavigationEntry, build_navigation, walk_navigation
from ..core.source import SourceSnapshot
from ..core.text_lines import iter_physical_lines
from .layout import LayoutOptions


_HORIZONTAL = " \t\u3000"
_INVALID_XML = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\ud800-\udfff\ufffe\uffff]")


@dataclass(frozen=True)
class PreparedBook:
    text: str = field(repr=False)
    encoding: str
    html: str = field(repr=False)
    chapters: list[str] = field(repr=False)
    navigation: tuple[NavigationEntry, ...]
    chapter_warnings: tuple[str, ...]
    layout: LayoutOptions


def require_xml_text(value: str, label: str) -> None:
    if _INVALID_XML.search(value):
        raise ValueError(f"{label}含电子书无法保存的字符，请核对后再转换。")


def _render_line(text: str, start: int, tag: str, targets: list[NavigationEntry], *, manual: bool) -> str:
    if not targets:
        return f"<{tag}>{escape(text)}</{tag}>"
    if len(targets) == 1:
        style_class = ' class="chapter-start"' if manual else ""
        return f'<{tag}{style_class} id="{targets[0].anchor}">{escape(text)}</{tag}>'
    # MOBI 6 会移动标题内的行内锚点，卷名和章节各使用一个标题块。
    volume, chapter = targets
    split = chapter.start - start
    return (f'<h1 id="{volume.anchor}">{escape(text[:split])}</h1>'
            f'<h2 class="inline-chapter" id="{chapter.anchor}">{escape(text[split:])}</h2>')


def prepare_from_editor(editor: ChapterEditor, title: str, *, layout: LayoutOptions = LayoutOptions()) -> PreparedBook:
    text = editor.source.text
    if not text.strip():
        raise ValueError("TXT 没有可转换的正文。")
    require_xml_text(text, "正文")
    require_xml_text(title, "书名")
    headings = {heading.line_number: heading for heading in editor.headings}
    navigation = build_navigation(editor)
    if not navigation:
        # EPUB 保留一个正文入口，识别到的章节数量仍为零。
        first = next(line for line in iter_physical_lines(text) if line.body.strip())
        start = first.start + len(first.body) - len(first.body.lstrip(_HORIZONTAL))
        navigation = (NavigationEntry("正文", "special", first.number, start),)
    targets: dict[int, list[NavigationEntry]] = {}
    for _, entry in walk_navigation(navigation):
        require_xml_text(entry.title, "目录标题")
        targets.setdefault(entry.line_number, []).append(entry)

    body = []
    for line in iter_physical_lines(text):
        content = line.body.strip(_HORIZONTAL)
        if not content.strip():
            continue
        start = line.start + len(line.body) - len(line.body.lstrip(_HORIZONTAL))
        heading = headings.get(line.number)
        tag = "p"
        if heading is not None and not heading.manually_added:
            tag = "h1" if heading.kind == "volume" else "h2"
        body.append(_render_line(content, start, tag, targets.get(line.number, []),
                                 manual=heading is not None and heading.manually_added))
    html = ('<?xml version="1.0" encoding="utf-8"?>'
            '<html xmlns="http://www.w3.org/1999/xhtml"><head>'
            f'<title>{escape(title)}</title>'
            f'<style type="text/css">{layout.stylesheet()}</style>'
            '</head><body>' + '\n'.join(body) + '</body></html>')
    warnings = editor.analysis.warnings
    if not headings:
        warnings = ("目录没有章节条目，电子书可从正文入口阅读。",)
    elif not editor.analysis.headings:
        warnings = ()
    return PreparedBook(text, editor.source.encoding, html, [heading.title for heading in headings.values()],
                        navigation, warnings, layout)


def prepare_book(
    content: bytes, title: str, author: str, encoding: str | None = None, *,
    layout: LayoutOptions = LayoutOptions(),
) -> PreparedBook:
    """兼容原有转换入口的编码选择，并复用严格解码和章节引擎。"""
    require_xml_text(author, "作者")
    source = SourceSnapshot(Path("input.txt"), len(content), sha256(content).hexdigest(), content)
    try:
        if encoding is not None or content.startswith((b'\xef\xbb\xbf', b'\xff\xfe', b'\xfe\xff')):
            decoded = decode_source(source, encoding)
        else:
            try:
                decoded = decode_source(source, "utf-8")
            except EncodingError:
                decoded = decode_source(source, "gb18030")
    except EncodingError as error:
        raise ValueError(f"无法可靠解码 TXT。{error}") from None
    return prepare_from_editor(ChapterEditor(decoded, encoding_confirmed=True), title, layout=layout)
