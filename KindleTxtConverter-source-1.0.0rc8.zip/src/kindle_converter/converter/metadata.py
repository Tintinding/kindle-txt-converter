"""读取用户选择的封面并检查电子书语言字段。"""

from dataclasses import dataclass, field
from pathlib import Path
import re


_MAX_COVER_BYTES = 24 * 1024 * 1024
_MAX_COVER_PIXELS = 24_000_000
_COVER_FORMATS = {b"jpeg": ("jpg", "image/jpeg"), b"png": ("png", "image/png")}


@dataclass(frozen=True)
class BookCover:
    content: bytes = field(repr=False)
    extension: str
    media_type: str


def book_language(value: str) -> str:
    language = value.strip().lower()
    if re.fullmatch(r"[a-z]{2}", language) is None:
        raise ValueError("请输入两位书籍语言代码，例如 zh、en 或 ja。")
    return language


def read_cover(path: Path) -> BookCover:
    """按文件内容识别 JPG/PNG，完整解码验证并限制解码内存。"""
    from PySide6.QtCore import QBuffer, QIODevice
    from PySide6.QtGui import QImageReader

    try:
        with path.open("rb") as stream:
            content = stream.read(_MAX_COVER_BYTES + 1)
    except OSError:
        raise ValueError("无法读取封面文件，请重新选择。") from None
    if len(content) > _MAX_COVER_BYTES:
        raise ValueError("封面文件大于 24 MiB，请缩小后重试。")
    buffer = QBuffer()
    buffer.setData(content)
    buffer.open(QIODevice.OpenModeFlag.ReadOnly)
    reader = QImageReader(buffer)
    reader.setDecideFormatFromContent(True)
    image_format = _COVER_FORMATS.get(bytes(reader.format()))
    if image_format is None:
        raise ValueError("封面必须是可读取的 JPG 或 PNG 图片。")
    size = reader.size()
    if not size.isValid() or size.isEmpty() or size.width() * size.height() > _MAX_COVER_PIXELS:
        raise ValueError("封面尺寸无效或超过 2400 万像素，请缩小后重试。")
    if reader.read().isNull():
        raise ValueError("封面图片损坏，请重新选择。")
    return BookCover(content, *image_format)
