"""中文小说的相对单位排版和可见目录选项。"""

from dataclasses import dataclass
from typing import Literal


ParagraphSpacing = Literal["compact", "standard", "loose"]
HeadingAlignment = Literal["center", "left"]
_SPACING = {"compact": "0", "standard": "0.35em", "loose": "0.75em"}


@dataclass(frozen=True)
class LayoutOptions:
    indent: Literal[0, 1, 2] = 2
    paragraph_spacing: ParagraphSpacing = "standard"
    heading_alignment: HeadingAlignment = "center"
    chapter_page_break: bool = True
    visible_toc: bool = False

    def __post_init__(self) -> None:
        if type(self.indent) is not int or self.indent not in (0, 1, 2):
            raise ValueError("首行缩进请选择 0、1 或 2 字。")
        if self.paragraph_spacing not in ("compact", "standard", "loose"):
            raise ValueError("段距请选择紧凑、标准或宽松。")
        if self.heading_alignment not in ("center", "left"):
            raise ValueError("标题对齐请选择居中或左对齐。")
        if type(self.chapter_page_break) is not bool or type(self.visible_toc) is not bool:
            raise ValueError("分页和书内目录设置须为开启或关闭。")

    def stylesheet(self) -> str:
        break_before = "always" if self.chapter_page_break else "auto"
        return (
            f"p{{text-indent:{self.indent}em;margin:0 0 {_SPACING[self.paragraph_spacing]}}}"
            f"h1,h2{{text-align:{self.heading_alignment};margin:1em 0 0.65em}}"
            f"h1,h2,.chapter-start{{page-break-before:{break_before}}}"
            ".inline-chapter{page-break-before:auto}"
        )
