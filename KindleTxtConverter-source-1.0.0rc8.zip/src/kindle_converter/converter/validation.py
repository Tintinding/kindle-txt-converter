"""验证真实电子书回读的 OEB 内容，报告不含正文和完整书籍信息。"""

from collections.abc import Iterator
from hashlib import sha256
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import unquote, urlsplit
from xml.etree import ElementTree as ET

from ..core.navigation import NavigationEntry, walk_navigation
from .metadata import read_cover


def _local_name(tag: str) -> str:
    return tag.rsplit("}", 1)[-1].lower()


def _normalized(text: str) -> str:
    return "".join(character for character in text if not character.isspace())


def _inside(root: Path, path: Path) -> Path:
    resolved = path.resolve()
    if not resolved.is_relative_to(root) or not resolved.is_file():
        raise ValueError("回读验证失败：引用文件不存在或路径超出工作目录。")
    return resolved


def _reference(root: Path, base: Path, href: str) -> tuple[Path, str]:
    parts = urlsplit(href)
    if parts.scheme or parts.netloc or parts.query:
        raise ValueError("回读验证失败：引用必须是工作目录内的本地文件。")
    relative = unquote(parts.path)
    if "\x00" in relative:
        raise ValueError("回读验证失败：引用路径无效。")
    return _inside(root, base.parent / relative), unquote(parts.fragment)


def _xml(path: Path) -> ET.Element:
    try:
        return ET.parse(path).getroot()
    except (OSError, ET.ParseError) as error:
        raise ValueError("回读验证失败：结构文件无法解析。") from error


def _child(element: ET.Element, name: str) -> ET.Element | None:
    return next((child for child in element if _local_name(child.tag) == name), None)


def _text(element: ET.Element) -> str:
    """按文档顺序只收集一次文本，避免嵌套 div/p/span 造成重复。"""
    if _local_name(element.tag) in {"script", "style", "head"}:
        return ""
    pieces = [element.text or ""]
    for child in element:
        pieces.append(_text(child))
        pieces.append(child.tail or "")
    return "".join(pieces)


class _DescriptionText(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.parts: list[str] = []

    def handle_data(self, data: str) -> None:
        self.parts.append(data)


def _matches_description(value: str, expected: str) -> bool:
    if _normalized(value) == expected:
        return True
    parser = _DescriptionText()
    parser.feed(value)
    parser.close()
    return _normalized("".join(parser.parts)) == expected


def _target_offsets(body: ET.Element) -> tuple[str, dict[str, int]]:
    """把每个锚点映射到正文字符位置，验证其确实对应当前章节开头。"""
    pieces: list[str] = []
    offsets: dict[str, int] = {}
    size = 0
    def append(text: str) -> None:
        nonlocal size
        normalized = _normalized(text)
        pieces.append(normalized)
        size += len(normalized)
    def walk(node: ET.Element) -> None:
        if _local_name(node.tag) in {'head', 'script', 'style'}:
            return
        for identifier in (node.get('id'), node.get('{http://www.w3.org/XML/1998/namespace}id'), node.get('name')):
            if identifier:
                offsets[identifier] = size
        append(node.text or '')
        for child in node:
            walk(child)
            append(child.tail or '')
    walk(body)
    return ''.join(pieces), offsets


def _nav_points(parent: ET.Element, depth: int = 1) -> Iterator[tuple[int, ET.Element]]:
    for point in parent:
        if _local_name(point.tag) == "navpoint":
            yield depth, point
            yield from _nav_points(point, depth + 1)


def validate_oeb(
    directory: Path,
    source_text: str,
    expected_chapters: list[str],
    title: str,
    author: str,
    *,
    navigation: tuple[NavigationEntry, ...] | None = None,
    visible_toc: bool = False,
    language: str | None = None,
    description: str = "",
    cover_expected: bool = False,
) -> dict[str, bool | int | str]:
    """核对 OPF、spine 全文及 NCX 目标；失败只报告类别，不记录书籍文本。"""
    root = directory.resolve()
    source = _normalized(source_text)
    if not source:
        raise ValueError("回读验证失败：源正文为空。")
    packages = list(root.rglob("*.opf"))
    if len(packages) != 1:
        raise ValueError("回读验证失败：缺少唯一的 OPF 文件。")
    package_path = _inside(root, packages[0])
    package = _xml(package_path)
    metadata = _child(package, "metadata")
    manifest = _child(package, "manifest")
    spine = _child(package, "spine")
    if metadata is None or manifest is None or spine is None:
        raise ValueError("回读验证失败：OPF 元数据、清单或阅读顺序缺失。")

    titles = [_normalized(_text(node)) for node in metadata if _local_name(node.tag) == "title"]
    authors = [_normalized(_text(node)) for node in metadata if _local_name(node.tag) == "creator"]
    expected_authors = [_normalized(part) for part in author.split("&") if part.strip()]
    # Calibre 把其内置的未知作者占位符统一写成 Unknown。
    unknown_author = expected_authors in ([], ["未知"]) and authors == ["Unknown"]
    if titles != [_normalized(title)] or (authors != expected_authors and not unknown_author):
        raise ValueError("回读验证失败：书名或作者元数据不一致。")
    languages = [_text(node).strip().lower() for node in metadata if _local_name(node.tag) == "language"]
    if language is not None and languages != [language]:
        raise ValueError("回读验证失败：书籍语言元数据不一致。")
    if description.strip():
        descriptions = [_text(node) for node in metadata if _local_name(node.tag) == "description"]
        if len(descriptions) != 1 or not _matches_description(descriptions[0], _normalized(description)):
            raise ValueError("回读验证失败：简介元数据不一致。")

    items: dict[str, ET.Element] = {}
    for item in manifest:
        if _local_name(item.tag) != "item":
            continue
        identifier = item.get("id", "")
        if not identifier or identifier in items:
            raise ValueError("回读验证失败：OPF 清单标识无效或重复。")
        items[identifier] = item

    if cover_expected:
        cover_meta = next((node for node in metadata if node.get("name") == "cover"), None)
        cover_item = items.get(cover_meta.get("content", "")) if cover_meta is not None else None
        if cover_item is None or not cover_item.get("media-type", "").startswith("image/"):
            raise ValueError("回读验证失败：缺少封面图片引用。")
        cover_path, fragment = _reference(root, package_path, cover_item.get("href", ""))
        if fragment:
            raise ValueError("回读验证失败：封面图片引用无效。")
        try:
            read_cover(cover_path)
        except ValueError:
            raise ValueError("回读验证失败：无法解码封面图片。") from None

    documents: dict[Path, tuple[int, str, dict[str, int]]] = {}
    ordered_text = []
    character_cursor = 0
    for reference in spine:
        if _local_name(reference.tag) != "itemref":
            continue
        item = items.get(reference.get("idref", ""))
        if item is None or item.get("media-type") not in {"application/xhtml+xml", "text/html"}:
            raise ValueError("回读验证失败：阅读顺序包含无效的正文引用。")
        path, fragment = _reference(root, package_path, item.get("href", ""))
        if fragment or path in documents:
            raise ValueError("回读验证失败：阅读顺序引用无效或重复。")
        document = _xml(path)
        body = next((node for node in document.iter() if _local_name(node.tag) == "body"), None)
        if body is None:
            raise ValueError("回读验证失败：正文文件缺少 body。")
        text, offsets = _target_offsets(body)
        documents[path] = (character_cursor, text, offsets)
        ordered_text.append(text)
        character_cursor += len(text)
    if not documents:
        raise ValueError("回读验证失败：阅读顺序没有正文。")
    body_text = "".join(ordered_text)
    contents_path = None
    body_search_start = 0
    if visible_toc:
        guide = _child(package, "guide")
        toc = next((item for item in guide if item.get("type") == "toc"), None) if guide is not None else None
        if toc is None or not toc.get("href"):
            raise ValueError("回读验证失败：书内目录页缺失。")
        contents_path, fragment = _reference(root, package_path, toc.get("href", ""))
        if contents_path not in documents:
            raise ValueError("回读验证失败：书内目录页不在阅读顺序中。")
        contents_start, contents_text, contents_offsets = documents[contents_path]
        if fragment and fragment not in contents_offsets:
            raise ValueError("回读验证失败：书内目录页入口无效。")
        body_search_start = contents_start + len(contents_text)
    # 连续全文比较可容许前后的默认封面/可见目录，同时防止宽松子序列掩盖缺字。
    body_start = body_text.find(source, body_search_start)
    if body_start < 0:
        raise ValueError("回读验证失败：正文内容缺失、改写或顺序不一致。")

    ncx_item = items.get(spine.get("toc", ""))
    if ncx_item is None:
        candidates = [item for item in items.values() if item.get("media-type") == "application/x-dtbncx+xml"]
        if len(candidates) > 1:
            raise ValueError("回读验证失败：NCX 目录不唯一。")
        ncx_item = candidates[0] if candidates else None
    expected = list(walk_navigation(navigation)) if navigation is not None else []
    titles = [entry.title for _, entry in expected] if navigation is not None else expected_chapters
    points: list[tuple[int, ET.Element]] = []
    positions: list[int] = []
    if ncx_item is None:
        if titles:
            raise ValueError("回读验证失败：章节导航目录缺失。")
    else:
        ncx_path, fragment = _reference(root, package_path, ncx_item.get("href", ""))
        if fragment:
            raise ValueError("回读验证失败：NCX 文件引用无效。")
        ncx = _xml(ncx_path)
        navmap = _child(ncx, "navmap")
        if navmap is None:
            raise ValueError("回读验证失败：NCX 缺少导航条目容器。")
        points = list(_nav_points(navmap))
        labels = []
        for _, point in points:
            label = _child(point, "navlabel")
            labels.append(_normalized(_text(label)) if label is not None else "")
        if labels != [_normalized(chapter) for chapter in titles]:
            raise ValueError("回读验证失败：章节目录数量、标题或顺序不一致。")
        if navigation is not None and [depth for depth, _ in points] != [depth for depth, _ in expected]:
            raise ValueError("回读验证失败：卷章目录层级不一致。")
        previous_position = -1
        expected_position, previous_start = body_start, 0
        for index, (_, point) in enumerate(points):
            content = _child(point, "content")
            if content is None or not content.get("src"):
                raise ValueError("回读验证失败：目录条目缺少跳转目标。")
            target, identifier = _reference(root, ncx_path, content.get("src", ""))
            if target not in documents:
                raise ValueError("回读验证失败：目录跳转目标不是阅读顺序中的正文。")
            document_start, target_text, offsets = documents[target]
            if identifier and identifier not in offsets:
                raise ValueError("回读验证失败：目录跳转片段不存在。")
            offset = offsets[identifier] if identifier else 0
            position = document_start + offset
            if navigation is not None:
                start = expected[index][1].start
                expected_position += len(_normalized(source_text[previous_start:start]))
                previous_start = start
                at_target = position == expected_position
            else:
                at_target = target_text.startswith(_normalized(titles[index]), offset)
            if not at_target:
                raise ValueError('回读验证失败：目录没有跳转到对应章节开头。')
            if position <= previous_position:
                raise ValueError('回读验证失败：目录跳转目标顺序错误或重复。')
            previous_position = position
            positions.append(position)

    if contents_path is not None:
        links = []
        for link in _xml(contents_path).iter():
            if _local_name(link.tag) != "a" or not link.get("href"):
                continue
            target, fragment = _reference(root, contents_path, link.get("href", ""))
            if target not in documents:
                raise ValueError("回读验证失败：书内目录链接未指向正文。")
            document_start, _, offsets = documents[target]
            if fragment and fragment not in offsets:
                raise ValueError("回读验证失败：书内目录链接片段无效。")
            links.append((_normalized(_text(link)), document_start + offsets.get(fragment, 0)))
        if links != list(zip(map(_normalized, titles), positions)):
            raise ValueError("回读验证失败：书内目录标题或跳转位置不一致。")

    return {
        "body_preserved": True,
        "metadata_verified": True,
        "cover_verified": cover_expected,
        "toc_verified": True,
        "source_characters": len(source),
        "source_text_sha256": sha256(source.encode("utf-8")).hexdigest(),
        "spine_documents": len(documents),
        "toc_entries": len(points),
        "toc_targets_verified": len(points),
        "toc_depth": max((depth for depth, _ in points), default=0),
        "visible_toc_verified": contents_path is not None,
    }
