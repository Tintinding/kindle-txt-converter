"""识别 Kindle 存储卷，将电子书复制到用户选定的 documents。"""

from dataclasses import dataclass
from hashlib import file_digest, sha256
import os
from pathlib import Path
from shutil import disk_usage
from tempfile import NamedTemporaryFile


class TransferError(ValueError):
    pass


@dataclass(frozen=True)
class KindleVolume:
    name: str
    documents: Path
    free_bytes: int


def documents_directory(selected: Path) -> Path:
    try:
        root = selected.resolve(strict=True)
        folder = root if root.name.casefold() == "documents" else (root / "documents").resolve(strict=True)
        if not folder.is_dir() or folder.name.casefold() != "documents" or not folder.is_relative_to(root):
            raise TransferError("请选择 Kindle 的根目录或 documents 文件夹。")
        return folder
    except OSError:
        raise TransferError("找不到 Kindle 的 documents 文件夹，请检查 USB 连接。") from None


def detect_kindles() -> tuple[KindleVolume, ...]:
    from PySide6.QtCore import QStorageInfo

    devices = []
    for volume in QStorageInfo.mountedVolumes():
        if not volume.isReady() or volume.isReadOnly() or "kindle" not in volume.displayName().casefold():
            continue
        try:
            folder = documents_directory(Path(volume.rootPath()))
        except TransferError:
            continue
        devices.append(KindleVolume(volume.displayName(), folder, volume.bytesAvailable()))
    return tuple(devices)


def copy_book(source: Path, selected: Path) -> Path:
    """以独立临时文件复制，核对后发布且保留既有文件。"""
    folder = documents_directory(selected)
    if source.suffix.lower() not in (".azw3", ".mobi"):
        raise TransferError("请选择已转换的 AZW3 或 MOBI 电子书。")
    target = folder / source.name
    temporary: Path | None = None
    try:
        original = source.stat()
        if not source.is_file() or original.st_size == 0:
            raise TransferError("找不到可复制的电子书，请重新转换。")
        if target.exists():
            raise TransferError("Kindle 上已有同名文件，请更改电子书文件名后再发送。")
        if disk_usage(folder).free < original.st_size:
            raise TransferError("Kindle 可用空间不足。")
        checksum = sha256()
        with NamedTemporaryFile(mode="wb", prefix=".kindle-transfer-", suffix=".part",
                                dir=folder, delete=False) as destination:
            temporary = Path(destination.name)
            with source.open("rb") as stream:
                for block in iter(lambda: stream.read(1024 * 1024), b""):
                    checksum.update(block)
                    destination.write(block)
            destination.flush()
            os.fsync(destination.fileno())
        current = source.stat()
        with temporary.open("rb") as received:
            if (current.st_size != original.st_size or current.st_mtime_ns != original.st_mtime_ns
                    or received.seek(0, os.SEEK_END) != original.st_size):
                raise TransferError("传输期间文件大小或时间发生变化，请重试。")
            received.seek(0)
            if checksum.digest() != file_digest(received, "sha256").digest():
                raise TransferError("复制内容核对失败，请重新连接 Kindle 后重试。")
        if os.name == "nt":
            os.rename(temporary, target)
        else:
            os.link(temporary, target)
        return target
    except FileExistsError:
        raise TransferError("Kindle 上出现同名文件，请更改文件名后再发送。") from None
    except OSError:
        raise TransferError("传输失败，请检查文件、Kindle 连接和剩余空间。") from None
    finally:
        if temporary is not None:
            try:
                temporary.unlink(missing_ok=True)
            except OSError:
                # 设备拔出后无法清理 .part，保留唯一名称供重新连接时核对。
                pass
