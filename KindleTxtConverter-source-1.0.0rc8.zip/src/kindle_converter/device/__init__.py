"""后续 Kindle USB 设备功能的模块边界。"""
