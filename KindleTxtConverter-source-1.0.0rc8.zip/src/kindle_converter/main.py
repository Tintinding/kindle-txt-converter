"""桌面入口及阶段 0 可记录的打包验证命令。"""

import argparse
import json
import sys
from pathlib import Path

from . import __version__
from .core.source import SourceReadError, read_source
from .services.diagnostics import environment_report
from .services.paths import application_root


def emit_report(report: dict, destination: Path | None) -> None:
    text = json.dumps(report, ensure_ascii=False, indent=2)
    if destination is not None:
        target = destination.resolve()
        if not target.is_relative_to(application_root()):
            raise ValueError('报告必须保存在应用目录内。')
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('x', encoding='utf-8') as stream:
            stream.write(text)
    if sys.stdout is not None:
        print(text)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Kindle 转换器技术验证版")
    parser.add_argument("--version", action="version", version=__version__)
    parser.add_argument("--environment", action="store_true", help="检查锁定依赖是否可加载")
    parser.add_argument("--inspect", type=Path, metavar="TXT", help="只读检查指定 TXT 的大小及哈希，不输出正文")
    parser.add_argument("--detect-encoding", type=Path, metavar="TXT", help="只读检测编码，仅输出诊断信息，不输出正文预览")
    parser.add_argument("--convert", type=Path, metavar="TXT", help="将 TXT 转换为电子书")
    parser.add_argument("--output", type=Path, help="项目内的新 AZW3/MOBI 输出路径")
    parser.add_argument("--title", help="书名，默认使用 TXT 文件名")
    parser.add_argument("--author", default="未知", help="作者")
    parser.add_argument("--language", default="zh", help="两位书籍语言代码")
    parser.add_argument("--description", default="", help="书籍简介")
    parser.add_argument("--cover", type=Path, help="选择 JPG 或 PNG 封面")
    parser.add_argument("--encoding", help="明确指定 TXT 编码")
    parser.add_argument("--indent", type=int, choices=(0, 1, 2), default=2, help="首行缩进字数")
    parser.add_argument("--paragraph-spacing", choices=("compact", "standard", "loose"), default="standard",
                        help="选择紧凑、标准或宽松段距")
    parser.add_argument("--heading-alignment", choices=("center", "left"), default="center", help="标题居中或左对齐")
    parser.add_argument("--no-chapter-page-break", action="store_true", help="关闭章节分页")
    parser.add_argument("--visible-toc", action="store_true", help="在 AZW3 中添加书内目录页")
    parser.add_argument("--standard-cleaning", action="store_true", help="应用标准清理的默认勾选项")
    parser.add_argument("--report", type=Path, help="在应用目录内保存新的 JSON 验证报告")
    args = parser.parse_args(argv)
    if args.detect_encoding is not None:
        from .core.encoding import EncodingError, decode_source
        try:
            source = read_source(args.detect_encoding)
            decoded = decode_source(source, args.encoding)
        except (SourceReadError, EncodingError) as error:
            emit_report({"error": str(error)}, args.report)
            return 1
        emit_report({
            "size_bytes": source.size_bytes,
            "source_sha256": decoded.source_sha256,
            "encoding": decoded.encoding,
            "confidence": decoded.confidence,
            "requires_confirmation": decoded.requires_confirmation,
            "warnings": list(decoded.warnings),
            "bom_bytes": decoded.bom_bytes,
            "character_count": len(decoded.text),
            "issue_line_count": decoded.issue_line_count,
            "issues": [
                {
                    "line_number": issue.line_number,
                    "start": issue.start,
                    "end": issue.end,
                    "byte_start": issue.byte_start,
                    "byte_end": issue.byte_end,
                    "first_marker": issue.first_marker,
                    "replacement_count": issue.replacement_count,
                    "control_count": issue.control_count,
                }
                for issue in decoded.issues
            ],
        }, args.report)
        return 0
    if args.convert is not None:
        if args.output is None:
            parser.error("转换需要 --output")
        from .converter.calibre import CalibreEngine
        from .converter.layout import LayoutOptions
        try:
            layout = LayoutOptions(args.indent, args.paragraph_spacing, args.heading_alignment,
                                   not args.no_chapter_page_break, args.visible_toc)
            cleaning = None
            if args.standard_cleaning:
                from .core.cleaning import analyze_cleaning
                from .core.cleaning_selection import CleaningSelection
                from .core.encoding import decode_source
                decoded = decode_source(read_source(args.convert), args.encoding)
                cleaning = CleaningSelection(analyze_cleaning(decoded))
            report = CalibreEngine().convert(args.convert, args.output, args.title, args.author, args.encoding,
                                            layout=layout, language=args.language, description=args.description,
                                            cover=args.cover, cleaning=cleaning)
        except (ValueError, OSError) as error:
            # 不输出异常链，避免间接泄露输入内容。
            emit_report({"error": str(error)}, args.report)
            return 1
        emit_report(report, args.report)
        return 0
    if args.inspect is not None:
        try:
            source = read_source(args.inspect)
        except SourceReadError as error:
            print(json.dumps({"error": str(error)}, ensure_ascii=False))
            return 1
        print(json.dumps({"size_bytes": source.size_bytes, "sha256": source.sha256}, ensure_ascii=False))
        return 0
    if args.environment:
        emit_report(environment_report(), args.report)
        return 0
    if args.report is not None:
        parser.error('--report 必须与 --environment、--convert 或 --detect-encoding 一起使用')
    from .gui import run_gui
    return run_gui()
