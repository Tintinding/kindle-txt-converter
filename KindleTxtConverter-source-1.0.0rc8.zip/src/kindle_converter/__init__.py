"""Kindle 电子书转换器。"""

__version__ = "1.0.0rc8"
