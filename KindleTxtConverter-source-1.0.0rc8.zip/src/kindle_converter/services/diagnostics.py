"""只收集环境版本；不读取小说、浏览记录或个人路径。"""

from importlib.metadata import version, PackageNotFoundError
import platform
import struct
from pathlib import Path
import sys

from .paths import resource_root


def optional_version(name: str) -> str | None:
    try:
        return version(name)
    except PackageNotFoundError:
        return None


def environment_report() -> dict[str, object]:
    # 实际加载核心 DLL 和 Widgets，避免仅凭包元数据声称依赖可用。
    from PySide6 import QtCore, QtWidgets, __version__ as pyside_version
    import charset_normalizer
    root = resource_root()
    frozen = bool(getattr(sys, 'frozen', False))
    runtime_inside = False
    if frozen and sys.platform == 'win32':
        import ctypes
        kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        kernel.GetModuleFileNameW.argtypes = [ctypes.c_void_p, ctypes.c_wchar_p, ctypes.c_uint32]
        buffer = ctypes.create_unicode_buffer(32768)
        if kernel.GetModuleFileNameW(ctypes.pythonapi._handle, buffer, len(buffer)):
            runtime_inside = Path(buffer.value).resolve().is_relative_to(root)

    return {
        "python": platform.python_version(),
        "architecture_bits": struct.calcsize("P") * 8,
        "pyside6_essentials": pyside_version,
        "qt": QtCore.qVersion(),
        "qt_widgets_available": QtWidgets.QWidget is not None,
        "charset_normalizer": charset_normalizer.__version__,
        "pytest": optional_version("pytest"),
        "pyinstaller": optional_version("pyinstaller"),
        "frozen": frozen,
        "application_runtime_inside_bundle": runtime_inside,
        "calibre_runtime_inside_bundle": (root / 'converter/calibre/Calibre/ebook-convert.exe').is_file(),
        "stage": "TASK-003",
        "conversion_verified": False,
        "standalone_verified": False,
    }
