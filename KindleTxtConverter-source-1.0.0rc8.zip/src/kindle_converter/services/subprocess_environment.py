"""避免冻结应用的 DLL 搜索设置污染独立转换运行时。"""

from contextlib import contextmanager
import os
from pathlib import Path
import sys
from threading import RLock


_dll_lock = RLock()


def external_environment(environment: dict[str, str]) -> dict[str, str]:
    result = environment.copy()
    for name in ('PYTHONHOME', 'PYTHONPATH', 'VIRTUAL_ENV', 'QT_PLUGIN_PATH', 'QT_QPA_PLATFORM_PLUGIN_PATH'):
        result.pop(name, None)
    for name in list(result):
        if name.startswith(('_PYI_', 'PYINSTALLER_')):
            result.pop(name, None)
    if getattr(sys, 'frozen', False):
        bundle = Path(sys._MEIPASS).resolve()
        paths = []
        for part in result.get('PATH', '').split(os.pathsep):
            if part and not Path(part).resolve().is_relative_to(bundle):
                paths.append(part)
        result['PATH'] = os.pathsep.join(paths)
    return result


@contextmanager
def external_dll_search():
    """转换发生在后台线程；进程创建后恢复应用原本的 DLL 目录。"""
    if sys.platform != 'win32' or not getattr(sys, 'frozen', False):
        yield
        return
    import ctypes
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.SetDllDirectoryW.argtypes = [ctypes.c_wchar_p]
    kernel.SetDllDirectoryW.restype = ctypes.c_int
    kernel.GetDllDirectoryW.argtypes = [ctypes.c_uint32, ctypes.c_wchar_p]
    kernel.GetDllDirectoryW.restype = ctypes.c_uint32
    with _dll_lock:
        buffer = ctypes.create_unicode_buffer(32768)
        kernel.GetDllDirectoryW(len(buffer), buffer)
        previous = buffer.value
        if not kernel.SetDllDirectoryW(None):
            raise OSError('无法隔离转换组件的 DLL 搜索目录。')
        try:
            yield
        finally:
            if not kernel.SetDllDirectoryW(previous or None):
                raise OSError('无法恢复应用 DLL 搜索目录。')
