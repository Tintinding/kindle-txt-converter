"""开发目录与未来便携版目录的共同定位约定。"""

from pathlib import Path
import sys


def application_root() -> Path:
    """便携版以 EXE 所在目录为根；开发版以项目目录为根。"""
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parents[3]


def resource_root() -> Path:
    """单文件包从临时释放目录加载内置资源。"""
    if getattr(sys, "frozen", False):
        bundle = Path(sys._MEIPASS)
        if (bundle / "rules").is_dir():
            return bundle
    return application_root()
