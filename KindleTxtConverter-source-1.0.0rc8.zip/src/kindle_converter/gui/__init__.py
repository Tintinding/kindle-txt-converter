"""阶段 0 的最小 Windows 转换界面。"""

from .window import MainWindow, run_gui

__all__ = ["MainWindow", "run_gui"]
