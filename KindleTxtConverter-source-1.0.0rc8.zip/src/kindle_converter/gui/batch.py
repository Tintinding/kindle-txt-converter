"""多文件导入、批量队列和结果操作。"""

from pathlib import Path
from typing import Callable

from PySide6.QtCore import QThread, QUrl, Signal, Slot
from PySide6.QtGui import QCloseEvent, QDesktopServices
from PySide6.QtWidgets import (
    QAbstractItemView, QComboBox, QDialog, QFileDialog, QHeaderView, QHBoxLayout,
    QLabel, QPushButton, QTableWidget, QTableWidgetItem, QVBoxLayout,
)

from ..converter.batch import BatchJob, batch_jobs, run_batch
from ..converter.calibre import CalibreEngine, ConversionControl


class BatchThread(QThread):
    job_changed = Signal(int, str, str)

    def __init__(self, engine: CalibreEngine, jobs: tuple[BatchJob, ...], error_message, parent) -> None:
        super().__init__(parent)
        self.engine, self.jobs, self.error_message = engine, jobs, error_message
        self.controls = tuple(ConversionControl() for _ in jobs)

    def run(self) -> None:
        run_batch(self.engine, self.jobs, self.controls, self.job_changed.emit, self.error_message)


class BatchDialog(QDialog):
    def __init__(self, root: Path, engine_factory: Callable[[], CalibreEngine], error_message, parent=None) -> None:
        super().__init__(parent)
        self.root = root
        self.engine_factory = engine_factory
        self.error_message = error_message
        self.sources: list[Path] = []
        self.jobs: tuple[BatchJob, ...] = ()
        self.thread: BatchThread | None = None
        self.setWindowTitle("批量转换 TXT")
        self.resize(760, 440)
        layout = QVBoxLayout(self)
        toolbar = QHBoxLayout()
        self.add_files = QPushButton("添加 TXT…")
        self.add_files.clicked.connect(self.choose_files)
        self.add_directory = QPushButton("添加文件夹…")
        self.add_directory.clicked.connect(self.choose_directory)
        self.clear_queue = QPushButton("清空列表")
        self.clear_queue.clicked.connect(self.clear_sources)
        self.format = QComboBox()
        self.format.addItem("AZW3", "azw3")
        self.format.addItem("MOBI", "mobi")
        for widget in (self.add_files, self.add_directory, self.clear_queue, self.format):
            toolbar.addWidget(widget)
        toolbar.addStretch(1)
        layout.addLayout(toolbar)
        self.table = QTableWidget(0, 3)
        self.table.setHorizontalHeaderLabels(("TXT", "状态", "阶段或结果"))
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.itemSelectionChanged.connect(self.refresh_actions)
        self.table.setColumnWidth(0, 200)
        layout.addWidget(self.table)
        self.summary = QLabel("批量应用标准清理的默认勾选项。需确认编码的文件会提示单独转换。")
        self.summary.setWordWrap(True)
        layout.addWidget(self.summary)
        actions = QHBoxLayout()
        self.start_button = QPushButton("开始批量转换")
        self.start_button.clicked.connect(self.start_jobs)
        self.cancel_button = QPushButton("取消选中任务")
        self.cancel_button.clicked.connect(self.cancel_selected)
        self.open_button = QPushButton("打开选中结果的位置")
        self.open_button.clicked.connect(self.open_result)
        for button in (self.open_button, self.cancel_button, self.start_button):
            actions.addWidget(button)
        layout.addLayout(actions)
        self.refresh_actions()

    def add_sources(self, paths: list[Path]) -> None:
        existing = set(self.sources)
        for path in paths:
            path = path.resolve()
            if path in existing or path.suffix.lower() != ".txt" or not path.is_file():
                continue
            existing.add(path)
            self.sources.append(path)
            row = self.table.rowCount()
            self.table.insertRow(row)
            self.table.setItem(row, 0, QTableWidgetItem(path.name))
            self.table.item(row, 0).setToolTip(str(path))
            self.table.setItem(row, 1, QTableWidgetItem("等待"))
            self.table.setItem(row, 2, QTableWidgetItem(""))
        self.refresh_actions()

    def choose_files(self) -> None:
        files, _ = QFileDialog.getOpenFileNames(self, "添加 TXT", str(self.root), "TXT 文件 (*.txt)")
        self.add_sources([Path(file) for file in files])

    def choose_directory(self) -> None:
        chosen = QFileDialog.getExistingDirectory(self, "选择包含 TXT 的文件夹", str(self.root))
        if chosen:
            try:
                self.add_sources(sorted(Path(chosen).iterdir(), key=lambda path: path.name.casefold()))
            except OSError:
                self.summary.setText("无法读取此文件夹。")

    def clear_sources(self) -> None:
        self.sources.clear()
        self.jobs = ()
        self.table.setRowCount(0)
        self.refresh_actions()

    def start_jobs(self) -> None:
        if self.thread is not None or not self.sources:
            return
        self.jobs = batch_jobs(self.sources, self.root / "outputs", self.format.currentData())
        for row in range(self.table.rowCount()):
            self.job_changed(row, "等待", "")
        self.thread = BatchThread(self.engine_factory(), self.jobs, self.error_message, self)
        self.thread.job_changed.connect(self.job_changed)
        self.thread.finished.connect(self.finish_jobs)
        self.refresh_actions()
        self.thread.start()

    @Slot(int, str, str)
    def job_changed(self, row: int, status: str, detail: str) -> None:
        self.table.item(row, 1).setText(status)
        self.table.item(row, 2).setText(detail)
        self.table.item(row, 2).setToolTip(detail)
        self.refresh_actions()

    def cancel_selected(self) -> None:
        if self.thread is not None:
            for index in self.table.selectionModel().selectedRows():
                row = index.row()
                if self.table.item(row, 1).text() in ("等待", "处理中"):
                    if self.thread.controls[row].cancel():
                        self.job_changed(row, "正在取消", "")

    @Slot()
    def finish_jobs(self) -> None:
        if self.thread is not None:
            self.thread.wait()
            self.thread.deleteLater()
            self.thread = None
        statuses = [self.table.item(row, 1).text() for row in range(self.table.rowCount())]
        self.summary.setText(
            f"完成 {statuses.count('成功')} 本，失败 {statuses.count('失败')} 本，取消 {statuses.count('已取消')} 本。"
        )
        self.refresh_actions()

    def refresh_actions(self) -> None:
        rows = [index.row() for index in self.table.selectionModel().selectedRows()]
        running = self.thread is not None
        for control in (self.add_files, self.add_directory, self.clear_queue, self.format):
            control.setEnabled(not running)
        self.start_button.setEnabled(not running and bool(self.sources))
        self.cancel_button.setEnabled(running and any(
            self.table.item(row, 1).text() in ("等待", "处理中") for row in rows
        ))
        self.open_button.setEnabled(len(rows) == 1 and self.table.item(rows[0], 1).text() == "成功")

    def open_result(self) -> None:
        row = self.table.currentRow()
        if 0 <= row < len(self.jobs) and self.table.item(row, 1).text() == "成功":
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(self.jobs[row].output.parent)))

    def reject(self) -> None:
        if self.thread is None:
            super().reject()
        else:
            self.summary.setText("请等待队列完成，或选择任务并取消。")

    def closeEvent(self, event: QCloseEvent) -> None:
        if self.thread is not None:
            self.reject()
            event.ignore()
        else:
            super().closeEvent(event)
