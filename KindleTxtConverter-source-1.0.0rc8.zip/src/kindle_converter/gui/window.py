"""Windows 单书导入、设置和转换主窗口。"""

from dataclasses import dataclass
from functools import partial
import json
from ntpath import isreserved
from pathlib import Path
import re
import sys
from typing import Callable

from PySide6.QtCore import QThread, Qt, QUrl, Signal, Slot
from PySide6.QtGui import QCloseEvent, QDesktopServices, QDragEnterEvent, QDropEvent
from PySide6.QtWidgets import (
    QApplication, QCheckBox, QComboBox, QFileDialog, QFormLayout, QHBoxLayout,
    QLabel, QLineEdit, QMainWindow, QPlainTextEdit, QProgressBar, QPushButton,
    QTabWidget, QVBoxLayout, QWidget,
)

from ..converter.calibre import CalibreEngine, ConversionControl, ConversionError
from ..core.chapters import ChapterEditor, ChapterError
from ..core.cleaning import CleaningError, CleaningPlan, analyze_cleaning
from ..core.cleaning_selection import CleaningSelection
from ..core.encoding import DecodedText, EncodingError, decode_source
from ..core.source import SourceReadError, read_source
from ..core.user_rules import UserRuleError, load_user_rules
from ..services.paths import application_root, resource_root
from .batch import BatchDialog
from .cleaning_preview import CleaningPreview
from .navigation_preview import NavigationPreview
from .user_rules import RulesDialog


@dataclass(frozen=True)
class ConversionRequest:
    source: Path
    output: Path
    title: str
    author: str
    description: str
    cover: Path | None
    cleaning: CleaningSelection
    editor: ChapterEditor | None


def _safe_error(error: Exception) -> str:
    if isinstance(error, (ConversionError, SourceReadError, EncodingError, ChapterError, CleaningError, UserRuleError)):
        return str(error)
    if isinstance(error, ValueError) and str(error).startswith(
        ("回读验证失败：", "无法可靠解码 TXT", "TXT ", "封面", "无法读取封面", "请输入两位", "正文含", "简介含")
    ):
        return str(error)
    return "转换未完成，请检查转换组件、输入文件和输出位置后重试。"


class ImportWorker(QThread):
    loaded = Signal(object, int)
    failed = Signal(str)

    def __init__(self, source: Path, encoding: str | None):
        super().__init__()
        self.source = source
        self.encoding = encoding

    @Slot()
    def run(self) -> None:
        try:
            source = read_source(self.source)
            decoded = decode_source(source, self.encoding)
        except Exception as error:
            self.failed.emit(_safe_error(error))
        else:
            self.loaded.emit(decoded, source.size_bytes)


class CleaningWorker(QThread):
    loaded = Signal(object)
    failed = Signal(str)

    def __init__(self, decoded: DecodedText, user_rules_path: Path):
        super().__init__()
        self.decoded = decoded
        self.user_rules_path = user_rules_path

    @Slot()
    def run(self) -> None:
        try:
            plan = analyze_cleaning(self.decoded, encoding_confirmed=True, user_rules=load_user_rules(self.user_rules_path))
        except Exception as error:
            self.failed.emit(_safe_error(error))
        else:
            self.loaded.emit(plan)


class NavigationWorker(QThread):
    loaded = Signal(object)
    failed = Signal(str)

    def __init__(self, selection: CleaningSelection):
        super().__init__()
        self.selection = selection

    @Slot()
    def run(self) -> None:
        try:
            editor = ChapterEditor(self.selection.apply().decoded_text())
        except Exception as error:
            self.failed.emit(_safe_error(error))
        else:
            self.loaded.emit(editor)


class ConversionWorker(QThread):
    succeeded = Signal(dict)
    failed = Signal(str)
    progress_changed = Signal(int, str)

    def __init__(self, request: ConversionRequest, engine_factory: Callable[[], CalibreEngine]):
        super().__init__()
        self.request = request
        self.engine_factory = engine_factory
        self.control = ConversionControl()

    @Slot()
    def run(self) -> None:
        try:
            request = self.request
            result = self.engine_factory().convert(
                request.source, request.output, request.title, request.author,
                description=request.description,
                cover=request.cover, cleaning=request.cleaning, editor=request.editor,
                control=self.control, progress=self.progress_changed.emit,
            )
        except Exception as error:
            # 不把原始异常链或外部进程输出显示在界面上。
            self.failed.emit(_safe_error(error))
        else:
            self.succeeded.emit(result)


class MainWindow(QMainWindow):
    def __init__(
        self,
        *,
        root: Path | None = None,
        engine_factory: Callable[[], CalibreEngine] | None = None,
    ):
        super().__init__()
        self.root = (root or application_root()).resolve()
        self._user_rules_path = self.root / "settings" / "user-rules.json"
        self.engine_factory = engine_factory or partial(CalibreEngine, self.root)
        self._thread: QThread | None = None
        self._busy = False
        self._completion_message = ""
        self._decoded: DecodedText | None = None
        self._completed_output: Path | None = None
        self._conversion_steps: list[str] = []
        self.last_report: dict | None = None
        self.setWindowTitle("Kindle 电子书转换器")
        self.setMinimumSize(610, 510)
        self.resize(850, 655)
        self.setAcceptDrops(True)
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        self._build_layout()
        batch_action = self.menuBar().addAction("批量转换…")
        batch_action.triggered.connect(self._open_batch)
        self.batch_action = batch_action
        self.rules_action = self.menuBar().addAction("自定义清理规则…")
        self.rules_action.triggered.connect(self._open_rules)
        materials = resource_root() / "materials"
        if materials.is_dir():
            materials_action = self.menuBar().addAction("许可与源码…")
            materials_action.triggered.connect(
                lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(str(materials)))
            )

    @property
    def busy(self) -> bool:
        return self._busy

    def _build_layout(self) -> None:
        central = QWidget(self)
        layout = QVBoxLayout(central)
        layout.setContentsMargins(26, 24, 26, 24)
        layout.setSpacing(16)
        import_form = QFormLayout()
        self.source_edit = QLineEdit()
        self.source_edit.setObjectName("sourcePath")
        self.source_edit.setReadOnly(True)
        self.source_edit.setPlaceholderText("拖放一个 TXT 文件，或点击选择")
        self.source_button = QPushButton("选择 TXT…")
        self.source_button.setObjectName("chooseSourceButton")
        self.source_button.clicked.connect(self._choose_source)
        source_row = QHBoxLayout()
        source_row.addWidget(self.source_edit, 1)
        source_row.addWidget(self.source_button)
        import_form.addRow("原始文件", source_row)
        self.encoding_combo = QComboBox()
        self.encoding_combo.addItem("自动识别", None)
        for label in ("UTF-8", "GBK", "GB18030", "UTF-16 LE", "UTF-16 BE"):
            self.encoding_combo.addItem(label, label.lower().replace(" ", "-"))
        self.encoding_combo.activated.connect(self._load_source)
        self.encoding_label = QLabel()
        self.encoding_confirmation = QCheckBox("使用当前编码")
        self.encoding_confirmation.hide()
        encoding_row = QHBoxLayout()
        encoding_row.addWidget(self.encoding_combo)
        encoding_row.addWidget(self.encoding_label, 1)
        encoding_row.addWidget(self.encoding_confirmation)
        import_form.addRow("编码", encoding_row)
        layout.addLayout(import_form)

        self.tabs = QTabWidget()
        book = QWidget()
        form = QFormLayout(book)

        self.title_edit = QLineEdit()
        self.title_edit.setObjectName("titleEdit")
        form.addRow("书名", self.title_edit)
        self.author_edit = QLineEdit()
        self.author_edit.setObjectName("authorEdit")
        self.author_edit.setPlaceholderText("未知（可留空）")
        form.addRow("作者", self.author_edit)
        self.description_edit = QPlainTextEdit()
        self.description_edit.setPlaceholderText("可留空")
        self.description_edit.setMaximumHeight(84)
        form.addRow("简介", self.description_edit)
        self.cover_edit = QLineEdit()
        self.cover_edit.setReadOnly(True)
        self.cover_edit.setPlaceholderText("JPG 或 PNG，可留空")
        cover_row = QHBoxLayout()
        cover_row.addWidget(self.cover_edit, 1)
        cover_button = QPushButton("选择封面…")
        cover_button.clicked.connect(self._choose_cover)
        clear_cover = QPushButton("清除")
        clear_cover.clicked.connect(self.cover_edit.clear)
        cover_row.addWidget(cover_button)
        cover_row.addWidget(clear_cover)
        form.addRow("封面", cover_row)
        self.tabs.addTab(book, "书籍信息")

        self.cleaning_preview = CleaningPreview()
        self.cleaning_preview.analyze_requested.connect(self._analyze_cleaning)
        self.tabs.addTab(self.cleaning_preview, "清理预览")
        self.navigation_preview = NavigationPreview()
        self.navigation_preview.analyze_requested.connect(self._analyze_navigation)
        self.cleaning_preview.content_changed.connect(self._refresh_navigation)
        self.tabs.addTab(self.navigation_preview, "章节目录")
        layout.addWidget(self.tabs, 1)

        output_form = QFormLayout()
        self.format_combo = QComboBox()
        self.format_combo.setObjectName("formatCombo")
        self.format_combo.addItem("AZW3（推荐）", "azw3")
        self.format_combo.addItem("MOBI（备用）", "mobi")
        output_form.addRow("输出格式", self.format_combo)

        self.output_edit = QLineEdit()
        self.output_edit.setObjectName("outputPath")
        self.output_edit.setReadOnly(True)
        self.output_edit.setText(str(self.root / "outputs"))
        self.output_button = QPushButton("选择文件夹…")
        self.output_button.setObjectName("chooseOutputButton")
        self.output_button.clicked.connect(self._choose_output)
        output_row = QHBoxLayout()
        output_row.addWidget(self.output_edit, 1)
        output_row.addWidget(self.output_button)
        output_form.addRow("输出文件夹", output_row)
        layout.addLayout(output_form)
        self.progress = QProgressBar()
        self.progress.setObjectName("conversionProgress")
        self.progress.setRange(0, 0)
        self.progress.setTextVisible(False)
        self.progress.hide()
        layout.addWidget(self.progress)
        self.status_label = QLabel("准备就绪，请选择 TXT。")
        self.status_label.setObjectName("statusLabel")
        self.status_label.setWordWrap(True)
        layout.addWidget(self.status_label)
        self.convert_button = QPushButton("生成电子书")
        self.convert_button.setObjectName("convertButton")
        self.convert_button.setMinimumHeight(40)
        self.convert_button.clicked.connect(self.start_conversion)
        actions = QHBoxLayout()
        self.cancel_button = QPushButton("取消转换")
        self.cancel_button.setEnabled(False)
        self.cancel_button.clicked.connect(self.cancel_conversion)
        self.open_output_button = QPushButton("打开输出目录")
        self.open_output_button.setEnabled(False)
        self.open_output_button.clicked.connect(self.open_output_folder)
        self.export_log_button = QPushButton("导出诊断日志")
        self.export_log_button.setEnabled(False)
        self.export_log_button.clicked.connect(self._choose_log_path)
        actions.addWidget(self.open_output_button)
        actions.addWidget(self.export_log_button)
        actions.addStretch(1)
        actions.addWidget(self.cancel_button)
        actions.addWidget(self.convert_button)
        layout.addLayout(actions)
        self.setCentralWidget(central)

    def select_source(self, path: Path) -> None:
        if self._busy:
            return
        if path.suffix.lower() != ".txt" or not path.is_file():
            self.status_label.setText("请选择一个可读取的 TXT 文件。")
            return
        self.source_edit.setText(str(path))
        self.title_edit.setText(path.stem)
        self.author_edit.clear()
        self.cover_edit.clear()
        self.description_edit.clear()
        self.encoding_combo.setCurrentIndex(0)
        self._load_source()

    @Slot()
    def _load_source(self) -> None:
        if self._busy or not self.source_edit.text():
            return
        self._decoded = None
        self.cleaning_preview.set_plan(None)
        self.encoding_confirmation.setChecked(False)
        self.encoding_confirmation.hide()
        self.encoding_label.clear()
        self._completion_message = "导入未完成，请检查文件或选择其他编码。"
        self.status_label.setText("正在读取 TXT 并检查编码…")
        worker = ImportWorker(Path(self.source_edit.text()), self.encoding_combo.currentData())
        worker.loaded.connect(self._on_imported)
        worker.failed.connect(self._on_failure)
        self._start_worker(worker)

    @Slot(object, int)
    def _on_imported(self, decoded: DecodedText, size: int) -> None:
        self._decoded = decoded
        self.encoding_confirmation.setVisible(decoded.requires_confirmation)
        self.encoding_label.setText(f"{decoded.encoding.upper()} · {size:,} 字节")
        self._completion_message = " ".join(decoded.warnings) or "TXT 已导入，可设置书籍信息并生成电子书。"

    @Slot()
    def _analyze_cleaning(self) -> None:
        if self._busy:
            return
        if not self._encoding_ready():
            self.status_label.setText("请先导入 TXT。若编码不确定，请手动选择或勾选「使用当前编码」。")
            return
        assert self._decoded is not None
        self.cleaning_preview.set_plan(None)
        self.tabs.setCurrentWidget(self.cleaning_preview)
        self._completion_message = "清理分析未完成，请重试。"
        self.status_label.setText("正在分析标准清理建议…")
        worker = CleaningWorker(self._decoded, self._user_rules_path)
        worker.loaded.connect(self._on_cleaning_plan)
        worker.failed.connect(self._on_failure)
        self._start_worker(worker)

    @Slot(object)
    def _on_cleaning_plan(self, plan: CleaningPlan) -> None:
        self.cleaning_preview.set_plan(plan)
        self._completion_message = (
            "勾选要移除的内容后点击「删除所选」，也可直接生成电子书。"
            if plan.changes else "没有清理建议，可以生成电子书。"
        )

    def _encoding_ready(self) -> bool:
        return self._decoded is not None and (
            not self._decoded.requires_confirmation or self.encoding_confirmation.isChecked()
        )

    @Slot()
    def _refresh_navigation(self) -> None:
        self.navigation_preview.set_editor(None, ready=self.cleaning_preview.selection is not None)

    @Slot()
    def _analyze_navigation(self) -> None:
        selection = self.cleaning_preview.selection
        if self._busy or selection is None or not self._encoding_ready():
            return
        if self.navigation_preview.editor is not None:
            return
        self._completion_message = "目录识别未完成，请重试。"
        self.status_label.setText("正在识别清理后的章节目录…")
        worker = NavigationWorker(selection)
        worker.loaded.connect(self._on_navigation)
        worker.failed.connect(self._on_failure)
        self._start_worker(worker)

    @Slot(object)
    def _on_navigation(self, editor: ChapterEditor) -> None:
        self.navigation_preview.set_editor(editor)
        self._completion_message = "章节目录已生成，可检查或编辑节点。"

    def _dropped_source(self, event: QDragEnterEvent | QDropEvent) -> Path | None:
        urls = event.mimeData().urls()
        if self._busy or len(urls) != 1 or not urls[0].isLocalFile():
            return None
        source = Path(urls[0].toLocalFile())
        return source if source.suffix.lower() == ".txt" else None

    def dragEnterEvent(self, event: QDragEnterEvent) -> None:
        if self._dropped_source(event) is not None:
            event.acceptProposedAction()
        else:
            event.ignore()

    def dropEvent(self, event: QDropEvent) -> None:
        source = self._dropped_source(event)
        if source is not None:
            self.select_source(source)
            event.acceptProposedAction()
        else:
            event.ignore()

    @Slot()
    def _choose_source(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "选择 TXT 小说", str(self.root), "TXT 文本 (*.txt)")
        if path:
            self.select_source(Path(path))

    @Slot()
    def _choose_cover(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "选择封面", str(self.root), "封面图片 (*.jpg *.jpeg *.png)")
        if path:
            self.cover_edit.setText(path)

    @Slot()
    def _choose_output(self) -> None:
        current = Path(self.output_edit.text())
        start = current if current.is_dir() else self.root
        path = QFileDialog.getExistingDirectory(self, "选择输出文件夹", str(start))
        if path:
            self.output_edit.setText(path)

    def _set_busy(self, busy: bool) -> None:
        self._busy = busy
        for widget in (
            self.source_button, self.encoding_combo, self.encoding_confirmation, self.tabs, self.format_combo,
            self.output_button, self.convert_button,
        ):
            widget.setEnabled(not busy)
        self.progress.setVisible(busy)
        self.batch_action.setEnabled(not busy)
        self.rules_action.setEnabled(not busy)
        self.open_output_button.setEnabled(not busy and self._completed_output is not None)
        self.export_log_button.setEnabled(not busy and bool(self._conversion_steps))
        if not busy:
            self.cancel_button.setEnabled(False)

    @Slot()
    def _open_batch(self) -> None:
        if not self._busy:
            dialog = BatchDialog(self.root, self.engine_factory, _safe_error, self)
            dialog.exec()
            dialog.deleteLater()

    @Slot()
    def _open_rules(self) -> None:
        if not self._busy:
            dialog = RulesDialog(self._user_rules_path, self)
            if dialog.exec():
                self.cleaning_preview.set_plan(None)
                self.status_label.setText("规则已保存，请重新分析清理建议。")
            dialog.deleteLater()

    def _start_worker(self, worker: ConversionWorker | ImportWorker | CleaningWorker | NavigationWorker) -> None:
        self._set_busy(True)
        self._thread = worker
        worker.setParent(self)
        converting = isinstance(worker, ConversionWorker)
        self.progress.setRange(0, 5 if converting else 0)
        self.progress.setValue(0)
        self.cancel_button.setEnabled(converting)
        worker.finished.connect(self._finish_thread)
        worker.start()

    @Slot()
    def start_conversion(self) -> None:
        if self._busy:
            return
        source_text = self.source_edit.text().strip()
        if not source_text:
            self.status_label.setText("请先选择 TXT 文件。")
            return
        source = Path(source_text)
        if not source.is_file():
            self.status_label.setText("TXT 文件不存在或无法读取，请重新选择。")
            return
        if not self._encoding_ready():
            self.status_label.setText("请手动选择编码，或勾选「使用当前编码」。")
            return
        title = self.title_edit.text().strip()
        if not title:
            self.status_label.setText("书名不能为空。")
            return
        name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', title).rstrip('. ') or "Kindle电子书"
        filename = f'{name}.{self.format_combo.currentData()}'
        if isreserved(filename):
            filename = '_' + filename
        output = (Path(self.output_edit.text()) / filename).resolve()
        if output == source.resolve():
            self.status_label.setText("输出不能覆盖原始 TXT 文件。")
            return
        if output.exists():
            self.status_label.setText("同名电子书已存在，请修改书名或选择其他输出文件夹。")
            return
        selection = self.cleaning_preview.selection
        if selection is None:
            self._analyze_cleaning()
            return
        if self.cleaning_preview.has_pending:
            self.tabs.setCurrentWidget(self.cleaning_preview)
            self.status_label.setText("请点击「删除所选」，或取消勾选待删除的内容。")
            return
        cover = Path(self.cover_edit.text()) if self.cover_edit.text() else None
        request = ConversionRequest(source, output, title, self.author_edit.text().strip(),
                                    self.description_edit.toPlainText(), cover,
                                    selection, self.navigation_preview.editor)
        self._completion_message = "转换未完成，请重试。"
        self.last_report = None
        self._completed_output = None
        self._conversion_steps = ["已启动转换。"]
        self.status_label.setText("正在转换并回读检查，请等待完成后关闭窗口…")
        worker = ConversionWorker(request, self.engine_factory)
        worker.succeeded.connect(self._on_success)
        worker.failed.connect(self._on_failure)
        worker.progress_changed.connect(self._on_conversion_progress)
        self._start_worker(worker)

    @Slot(int, str)
    def _on_conversion_progress(self, step: int, message: str) -> None:
        self.progress.setValue(step)
        self._conversion_steps.append(message)
        if self.cancel_button.isEnabled():
            self.status_label.setText(message)

    @Slot()
    def cancel_conversion(self) -> None:
        if isinstance(self._thread, ConversionWorker) and self._thread.control.cancel():
            self.cancel_button.setEnabled(False)
            self.status_label.setText("正在取消转换…")

    @Slot()
    def open_output_folder(self) -> None:
        if self._completed_output is None:
            return
        if not QDesktopServices.openUrl(QUrl.fromLocalFile(str(self._completed_output.parent))):
            self.status_label.setText("无法打开输出目录。")

    def export_diagnostic(self, path: Path) -> None:
        destination = path.resolve()
        if not self._conversion_steps or not destination.is_relative_to(self.root):
            raise ValueError("请选择应用目录内的诊断日志位置。")
        with destination.open("x", encoding="utf-8") as stream:
            json.dump({"stages": self._conversion_steps, "report": self.last_report}, stream,
                      ensure_ascii=False, indent=2)

    @Slot()
    def _choose_log_path(self) -> None:
        path, _ = QFileDialog.getSaveFileName(self, "导出诊断日志", str(self.root / "转换日志.json"),
                                              "JSON 文件 (*.json)")
        if path:
            try:
                self.export_diagnostic(Path(path))
            except (OSError, ValueError):
                self.status_label.setText("无法导出日志，请选择应用目录内可写的新文件。")
            else:
                self.status_label.setText("诊断日志已保存。")

    @Slot(dict)
    def _on_success(self, report: dict) -> None:
        self.last_report = report
        if isinstance(self._thread, ConversionWorker):
            self._completed_output = self._thread.request.output
        fmt = str(report.get('format', '')).upper()
        chapters = report.get('roundtrip', {}).get('toc_targets_verified', report.get('chapters', 0))
        self._completion_message = f"转换成功：已生成 {fmt}，并通过正文、元数据和 {chapters} 个章节目录目标检查。文件保存在上方输出位置。"
        if report.get("chapter_warnings"):
            self._completion_message += " " + " ".join(report["chapter_warnings"])
        self._conversion_steps.append("转换成功。")

    @Slot(str)
    def _on_failure(self, message: str) -> None:
        self._completion_message = message
        if isinstance(self._thread, ConversionWorker):
            self._conversion_steps.append(message)

    @Slot()
    def _finish_thread(self) -> None:
        thread = self._thread
        if thread is not None:
            thread.wait()
            thread.deleteLater()
        self._thread = None
        self._set_busy(False)
        self.status_label.setText(self._completion_message)

    def closeEvent(self, event: QCloseEvent) -> None:
        if self._busy:
            event.ignore()
            self.status_label.setText("当前操作仍在运行，请等待完成后再关闭窗口。")
            return
        event.accept()


def run_gui() -> int:
    app = QApplication.instance() or QApplication(sys.argv)
    app.setApplicationName("Kindle电子书转换器")
    app.setOrganizationName("KindleTXTConverter")
    window = MainWindow()
    window.show()
    return app.exec()
