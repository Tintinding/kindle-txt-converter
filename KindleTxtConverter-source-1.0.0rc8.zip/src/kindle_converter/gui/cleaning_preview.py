"""预览标准清理建议并从转换文本中删除所选内容。"""

from PySide6.QtCore import QAbstractTableModel, QModelIndex, Qt, Signal
from PySide6.QtWidgets import (
    QAbstractItemView, QCheckBox, QHeaderView, QHBoxLayout, QLabel, QPlainTextEdit, QPushButton,
    QSplitter, QTableView, QVBoxLayout, QWidget,
)

from ..core.cleaning import CleaningPlan
from ..core.cleaning_selection import CleaningSelection


class CleaningTable(QAbstractTableModel):
    decisions_changed = Signal()
    content_changed = Signal()
    columns = ("选择", "行号", "建议", "状态")

    def __init__(self, parent: QWidget) -> None:
        super().__init__(parent)
        self.selection: CleaningSelection | None = None
        self.checked_ids: set[str] = set()

    def set_plan(self, plan: CleaningPlan | None) -> None:
        self.beginResetModel()
        self.selection = CleaningSelection(plan) if plan is not None else None
        if self.selection is not None:
            self.selection.restore_original()
        self.checked_ids.clear()
        self.endResetModel()
        self.decisions_changed.emit()
        self.content_changed.emit()

    @property
    def pending_ids(self) -> set[str]:
        return self.checked_ids - self.selection.selected_ids if self.selection is not None else set()

    def rowCount(self, parent=QModelIndex()) -> int:
        return len(self.selection.plan.changes) if self.selection is not None and not parent.isValid() else 0

    def columnCount(self, parent=QModelIndex()) -> int:
        return len(self.columns) if not parent.isValid() else 0

    def headerData(self, section, orientation, role=Qt.ItemDataRole.DisplayRole):
        if orientation == Qt.Orientation.Horizontal and role == Qt.ItemDataRole.DisplayRole:
            return self.columns[section]
        return None

    def data(self, index, role=Qt.ItemDataRole.DisplayRole):
        if self.selection is None or not index.isValid():
            return None
        change = self.selection.plan.changes[index.row()]
        if role == Qt.ItemDataRole.CheckStateRole and index.column() == 0:
            return Qt.CheckState.Checked if change.id in self.checked_ids else Qt.CheckState.Unchecked
        if role == Qt.ItemDataRole.DisplayRole:
            if change.id in self.selection.selected_ids:
                status = "已删除"
            elif change.risk == "review":
                status = "请核对"
            else:
                status = "建议删除"
            return ("", change.line_number, change.rule_name, status)[index.column()]
        return None

    def flags(self, index):
        flags = super().flags(index)
        return flags | Qt.ItemFlag.ItemIsUserCheckable if index.isValid() and index.column() == 0 else flags

    def setData(self, index, value, role=Qt.ItemDataRole.EditRole) -> bool:
        if self.selection is None or not index.isValid() or index.column() != 0 or role != Qt.ItemDataRole.CheckStateRole:
            return False
        change = self.selection.plan.changes[index.row()]
        if value in (Qt.CheckState.Checked, Qt.CheckState.Checked.value):
            self.checked_ids.add(change.id)
        else:
            self.checked_ids.discard(change.id)
            if change.id in self.selection.selected_ids:
                self.selection.deselect((change.id,))
                self.content_changed.emit()
        self.dataChanged.emit(self.index(index.row(), 0), self.index(index.row(), 3))
        self.decisions_changed.emit()
        return True

    def check_all(self, checked: bool) -> None:
        if self.selection is None:
            return
        if checked:
            self.checked_ids.update(change.id for change in self.selection.plan.changes)
        else:
            self.checked_ids.clear()
            if self.selection.selected_ids:
                self.selection.restore_original()
                self.content_changed.emit()
        self.refresh()

    def delete_checked(self) -> None:
        pending = self.pending_ids
        if self.selection is None or not pending:
            return
        self.selection.select(pending)
        self.selection.confirm_review(self.selection.pending_review_ids)
        self.content_changed.emit()
        self.refresh()

    def refresh(self) -> None:
        if self.rowCount():
            self.dataChanged.emit(self.index(0, 0), self.index(self.rowCount() - 1, 3))
        self.decisions_changed.emit()


class CleaningPreview(QWidget):
    analyze_requested = Signal()
    content_changed = Signal()

    def __init__(self) -> None:
        super().__init__()
        self.model = CleaningTable(self)
        root = QVBoxLayout(self)
        top = QHBoxLayout()
        self.analyze_button = QPushButton("分析标准清理")
        self.analyze_button.clicked.connect(self.analyze_requested)
        self.summary_label = QLabel()
        self.summary_label.setWordWrap(True)
        top.addWidget(self.analyze_button)
        top.addWidget(self.summary_label, 1)
        root.addLayout(top)
        self.select_all = QCheckBox("全选")
        self.select_all.clicked.connect(self.model.check_all)
        root.addWidget(self.select_all)
        split = QSplitter(Qt.Orientation.Vertical)
        self.table = QTableView()
        self.table.setModel(self.model)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.verticalHeader().hide()
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        self.table.setColumnWidth(0, 54)
        self.table.setColumnWidth(1, 64)
        self.table.setColumnWidth(3, 96)
        self.context = QPlainTextEdit()
        self.context.setReadOnly(True)
        self.context.setPlaceholderText("选择一条建议以查看原文、替换内容和上下文")
        split.addWidget(self.table)
        split.addWidget(self.context)
        root.addWidget(split, 1)
        controls = QHBoxLayout()
        hint = QLabel("仅从电子书中移除内容。取消勾选可恢复。")
        hint.setWordWrap(True)
        controls.addWidget(hint, 1)
        self.delete_button = QPushButton("删除所选")
        self.delete_button.clicked.connect(self.model.delete_checked)
        controls.addWidget(self.delete_button)
        root.addLayout(controls)
        self.table.selectionModel().currentChanged.connect(self.show_current)
        self.model.decisions_changed.connect(self._refresh_summary)
        self.model.content_changed.connect(self.content_changed)
        self._refresh_summary()

    @property
    def selection(self) -> CleaningSelection | None:
        return self.model.selection

    @property
    def has_pending(self) -> bool:
        return bool(self.model.pending_ids)

    def set_plan(self, plan: CleaningPlan | None) -> None:
        hits = plan.summary()["rule_hits"] if plan is not None else {}
        self.summary_label.setToolTip("、".join(f"{rule} {count}" for rule, count in hits.items()))
        self.model.set_plan(plan)
        self.show_current()

    def _refresh_summary(self) -> None:
        selection = self.selection
        count = self.model.rowCount()
        self.select_all.setEnabled(count > 0)
        self.select_all.setChecked(count > 0 and len(self.model.checked_ids) == count)
        pending = len(self.model.pending_ids)
        self.delete_button.setEnabled(pending > 0)
        if selection is None:
            self.summary_label.setText("导入 TXT 后可查看标准清理建议。")
            return
        self.summary_label.setText(
            f"{count} 条建议 · 待删除 {pending} · 已删除 {len(selection.selected_ids)}"
        )

    def show_current(self, *_args) -> None:
        index = self.table.currentIndex()
        selection = self.selection
        if selection is None or not index.isValid():
            self.context.clear()
            return
        change = selection.plan.changes[index.row()]
        preview = selection.plan.preview(change.id)
        original = preview.before + ("…" if preview.before_truncated else "")
        after = preview.after + ("…" if preview.after_truncated else "")
        self.context.setPlainText(
            f"第 {change.line_number} 行 · {change.reason}\n\n"
            f"上文\n{preview.context_before}\n原文\n{original}\n"
            f"处理后\n{after or '（删除）'}\n下文\n{preview.context_after}"
        )

