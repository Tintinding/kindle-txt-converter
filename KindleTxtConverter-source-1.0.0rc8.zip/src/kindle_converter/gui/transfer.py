"""明确显示 Kindle 目标并执行后台复制。"""

from pathlib import Path

from PySide6.QtCore import QThread, Signal, Slot
from PySide6.QtWidgets import QComboBox, QDialog, QFileDialog, QHBoxLayout, QLabel, QPushButton, QVBoxLayout

from ..device.transfer import TransferError, copy_book, detect_kindles, documents_directory


class TransferThread(QThread):
    result = Signal(str)

    def __init__(self, source: Path, target: Path, parent) -> None:
        super().__init__(parent)
        self.source, self.target = source, target

    def run(self) -> None:
        try:
            copy_book(self.source, self.target)
        except TransferError as error:
            self.result.emit(str(error))
        else:
            self.result.emit("电子书已发送到 Kindle。请通过 Windows 安全弹出设备。")


class TransferDialog(QDialog):
    def __init__(self, source: Path, parent=None) -> None:
        super().__init__(parent)
        self.source = source
        self.thread: TransferThread | None = None
        self.setWindowTitle("发送到 Kindle")
        self.setMinimumWidth(490)
        layout = QVBoxLayout(self)
        self.devices = QComboBox()
        self.devices.currentIndexChanged.connect(self.refresh_actions)
        layout.addWidget(self.devices)
        self.status = QLabel()
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        actions = QHBoxLayout()
        self.scan = QPushButton("刷新设备")
        self.scan.clicked.connect(self.detect)
        self.choose = QPushButton("手动选择目录…")
        self.choose.clicked.connect(self.choose_folder)
        self.send = QPushButton("复制到选中目录")
        self.send.clicked.connect(self.copy)
        for button in (self.scan, self.choose, self.send):
            actions.addWidget(button)
        layout.addLayout(actions)
        self.detect()

    @Slot()
    def detect(self) -> None:
        self.devices.clear()
        for device in detect_kindles():
            capacity = f" · 可用 {device.free_bytes / 1024 ** 2:.0f} MiB" if device.free_bytes >= 0 else ""
            self.devices.addItem(f"{device.name} · {device.documents}{capacity}", device.documents)
        self.status.setText("请核对目标后复制电子书。" if self.devices.count() else "未自动识别到 Kindle，可手动选择目录。")
        self.refresh_actions()

    @Slot()
    def choose_folder(self) -> None:
        chosen = QFileDialog.getExistingDirectory(self, "选择 Kindle 根目录或 documents")
        if chosen:
            try:
                directory = documents_directory(Path(chosen))
            except TransferError as error:
                self.status.setText(str(error))
            else:
                self.devices.addItem(str(directory), directory)
                self.devices.setCurrentIndex(self.devices.count() - 1)
                self.status.setText("请核对手动选择的 Kindle 目录。")

    @Slot()
    def refresh_actions(self) -> None:
        if not hasattr(self, "send"):
            return
        idle = self.thread is None
        for widget in (self.devices, self.scan, self.choose):
            widget.setEnabled(idle)
        self.send.setEnabled(idle and self.devices.currentData() is not None)

    @Slot()
    def copy(self) -> None:
        target = self.devices.currentData()
        if self.thread is None and isinstance(target, Path):
            self.thread = TransferThread(self.source, target, self)
            self.thread.result.connect(self.status.setText)
            self.thread.finished.connect(self.finish)
            self.status.setText("正在复制并核对文件，请保持 Kindle 连接。")
            self.refresh_actions()
            self.thread.start()

    @Slot()
    def finish(self) -> None:
        if self.thread is not None:
            self.thread.wait()
            self.thread.deleteLater()
            self.thread = None
        self.refresh_actions()

    def reject(self) -> None:
        if self.thread is None:
            super().reject()
