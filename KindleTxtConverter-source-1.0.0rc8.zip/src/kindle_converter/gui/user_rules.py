"""在桌面编辑并保存自定义清理规则。"""

from pathlib import Path
from uuid import uuid4

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QAbstractItemView, QComboBox, QDialog, QHeaderView, QHBoxLayout, QLabel,
    QPushButton, QTableWidget, QTableWidgetItem, QVBoxLayout,
)

from ..core.user_rules import RULE_KINDS, UserRule, UserRuleError, load_user_rules, save_user_rules


class RulesDialog(QDialog):
    def __init__(self, path: Path, parent=None) -> None:
        super().__init__(parent)
        self.path = path
        self.setWindowTitle("自定义清理规则")
        self.resize(710, 400)
        layout = QVBoxLayout(self)
        self.status = QLabel("自定义规则匹配到的独立行须逐条确认。")
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        self.table = QTableWidget(0, 3)
        self.table.setHorizontalHeaderLabels(("启用", "类型", "匹配内容"))
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setColumnWidth(0, 56)
        self.table.setColumnWidth(1, 145)
        layout.addWidget(self.table)
        actions = QHBoxLayout()
        self.add_button = QPushButton("新增规则")
        self.add_button.clicked.connect(self.add_rule)
        delete = QPushButton("删除选中")
        delete.clicked.connect(self.delete_rules)
        save = QPushButton("保存")
        save.clicked.connect(self.save)
        cancel = QPushButton("取消")
        cancel.clicked.connect(self.reject)
        for button in (self.add_button, delete, save, cancel):
            actions.addWidget(button)
        layout.addLayout(actions)
        try:
            rules = load_user_rules(path)
        except UserRuleError as error:
            self.status.setText(str(error))
        else:
            for rule in rules:
                self.add_rule(rule)

    def add_rule(self, rule: UserRule | bool = False) -> None:
        if not isinstance(rule, UserRule):
            if self.table.rowCount() >= 50:
                self.status.setText("最多保存 50 条自定义规则。")
                return
            rule = UserRule(uuid4().hex, "keyword", "")
        row = self.table.rowCount()
        self.table.insertRow(row)
        check = QTableWidgetItem()
        check.setFlags(Qt.ItemFlag.ItemIsSelectable | Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsUserCheckable)
        check.setCheckState(Qt.CheckState.Checked if rule.enabled else Qt.CheckState.Unchecked)
        check.setData(Qt.ItemDataRole.UserRole, rule.id)
        self.table.setItem(row, 0, check)
        kind = QComboBox()
        for value, label in RULE_KINDS.items():
            kind.addItem(label, value)
        kind.setCurrentIndex(kind.findData(rule.kind))
        self.table.setCellWidget(row, 1, kind)
        self.table.setItem(row, 2, QTableWidgetItem(rule.value))

    def delete_rules(self) -> None:
        for row in sorted({index.row() for index in self.table.selectionModel().selectedRows()}, reverse=True):
            self.table.removeRow(row)

    def save(self) -> None:
        rules = []
        for row in range(self.table.rowCount()):
            enabled = self.table.item(row, 0)
            rules.append(UserRule(enabled.data(Qt.ItemDataRole.UserRole),
                                  self.table.cellWidget(row, 1).currentData(), self.table.item(row, 2).text(),
                                  enabled.checkState() == Qt.CheckState.Checked))
        try:
            save_user_rules(self.path, tuple(rules))
        except UserRuleError as error:
            self.status.setText(str(error))
        else:
            self.accept()
