"""只读输入快照，不在原始文件上应用修改。"""

from dataclasses import dataclass, field
from hashlib import sha256
from pathlib import Path


class SourceReadError(ValueError):
    """可直接展示给用户的输入文件错误。"""


@dataclass(frozen=True)
class SourceSnapshot:
    path: Path = field(repr=False)
    size_bytes: int
    sha256: str
    content: bytes = field(repr=False)


def read_source(path: Path) -> SourceSnapshot:
    """保持字节内容和文件路径映射，摘要及异常均不包含正文。"""
    try:
        resolved = path.resolve(strict=True)
        if not resolved.is_file():
            raise SourceReadError("请选择一个 TXT 文件，不能选择文件夹。")
        content = resolved.read_bytes()
    except FileNotFoundError as error:
        raise SourceReadError("TXT 文件不存在，请重新选择。") from error
    except PermissionError as error:
        raise SourceReadError("没有读取该 TXT 的权限。") from error
    except OSError as error:
        raise SourceReadError("无法读取 TXT，请检查文件是否可用。") from error
    if not content:
        raise SourceReadError("TXT 文件为空，请选择包含正文的文件。")
    return SourceSnapshot(resolved, len(content), sha256(content).hexdigest(), content)
