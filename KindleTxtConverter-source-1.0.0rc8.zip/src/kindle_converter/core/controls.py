"""仅标记有限的非排版控制字符，保留布局及Unicode格式信息。"""

from collections.abc import Iterator
import re


# 保留TAB、LF、VT、FF、CR、NEL；Unicode格式/连接/方向字符不在此范围。
_RUN = re.compile(r"[\x00-\x08\x0e-\x1f\x7f-\x84\x86-\x9f]+")


def control_runs(text: str) -> Iterator[tuple[int, int]]:
    """每段相邻候选只返回一个原文区间，不解释退格或终端转义序列。"""
    for match in _RUN.finditer(text):
        yield match.start(), match.end()


def control_codepoints(text: str) -> str:
    """给确认理由提供有界、可见的码位标记，不插入原始控制字符。"""
    points = sorted({ord(character) for character in text})
    labels = [f"U+{point:04X}" for point in points[:8]]
    if len(points) > 8:
        labels.append(f"等{len(points)}种码位")
    return "、".join(labels)
