"""一次应用清理的结果与可供诊断使用的元数据。"""

from collections import Counter
from dataclasses import dataclass, field

from .cleaning import CleaningChange
from .encoding import DecodedText


@dataclass(frozen=True)
class AppliedChange:
    change: CleaningChange = field(repr=False)
    review_confirmed: bool


@dataclass(frozen=True)
class CleaningResult:
    text: str = field(repr=False)
    source_sha256: str
    source_encoding: str
    source_character_count: int
    rules_version: str
    plan_fingerprint: str
    result_utf8_sha256: str
    applied_changes: tuple[AppliedChange, ...] = field(repr=False)

    def decoded_text(self) -> DecodedText:
        """为后续章节识别提供清理结果的坐标与内容标识。"""
        return DecodedText(self.text, "utf-8", "derived", (), False, 0, self.result_utf8_sha256)

    def log_metadata(self) -> dict:
        """仅导出用于核对的位置、编号和统计。"""
        changes = []
        for applied in self.applied_changes:
            change = applied.change
            changes.append({
                "change_id": change.id,
                "rule_id": change.rule_id,
                "category": change.category,
                "risk": change.risk,
                "line_number": change.line_number,
                "start": change.start,
                "end": change.end,
                "byte_start": change.byte_start,
                "byte_end": change.byte_end,
                "replacement_character_count": len(change.replacement),
                "review_confirmed": applied.review_confirmed,
            })
        return {
            "schema_version": 1,
            "event": "cleaning_applied",
            "source_sha256": self.source_sha256,
            "source_encoding": self.source_encoding,
            "source_character_count": self.source_character_count,
            "rules_version": self.rules_version,
            "plan_fingerprint": self.plan_fingerprint,
            "result_utf8_sha256": self.result_utf8_sha256,
            "result_character_count": len(self.text),
            "applied_count": len(changes),
            "confirmed_review_count": sum(applied.review_confirmed for applied in self.applied_changes),
            "applied_rule_counts": dict(Counter(item["rule_id"] for item in changes)),
            "changes": changes,
        }
