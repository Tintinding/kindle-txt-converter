"""对有限、完整的单行网页片段提出明文替换，不解析外部资源。"""

import re
import unicodedata


_TOKEN = re.compile(r"<[^<>]*>|&(?:[A-Za-z][A-Za-z0-9]{1,31}|#[0-9]{1,7}|#[xX][0-9A-Fa-f]{1,6});")
_TAG = re.compile(r"<(/?)(p|div|br|b|strong|i|em|u|span)[ \t\u3000]*(/?)>", re.IGNORECASE)
_ENTITIES = {
    "amp": "&", "lt": "<", "gt": ">", "quot": '"', "apos": "'",
    "nbsp": "\u00a0", "ensp": "\u2002", "emsp": "\u2003",
    "hellip": "…", "mdash": "—", "ndash": "–",
    "lsquo": "‘", "rsquo": "’", "ldquo": "“", "rdquo": "”",
}
_HORIZONTAL = " \t\u3000"
_PROTECTED_TAG = re.compile(r"<(/?)(script|style|pre|code|textarea)(?=[ \t\u3000/>])[^<>]*>", re.IGNORECASE)


class HtmlTextGuard:
    """识别跨行字面块，并提供块外文字供上下文检查。"""

    def __init__(self) -> None:
        self._stack: list[str] = []
        self._uncertain = False

    @property
    def in_block(self) -> bool:
        return bool(self._stack) or self._uncertain

    def scan_line(self, text: str) -> tuple[bool, str]:
        blocked = self.in_block
        outside = []
        cursor = 0
        for token in _PROTECTED_TAG.finditer(text):
            if not self.in_block:
                outside.append(text[cursor:token.start()])
            blocked = True
            closing, name = token.group(1), token.group(2).lower()
            if closing:
                if self._stack and self._stack[-1] == name:
                    self._stack.pop()
                else:
                    self._uncertain = True
            elif not token.group().rstrip().endswith("/>"):
                self._stack.append(name)
            cursor = token.end()
        if not self.in_block:
            outside.append(text[cursor:])
        return blocked, "".join(outside)

    def blocks_line(self, text: str) -> bool:
        return self.scan_line(text)[0]


def _entity_value(token: str) -> str | None:
    name = token[1:-1]
    if not name.startswith("#"):
        return _ENTITIES.get(name)
    number = int(name[2:], 16) if name[1:2].lower() == "x" else int(name[1:], 10)
    if not 0 < number <= 0x10FFFF:
        return None
    value = chr(number)
    # 控制、代理、私用、未分配及方向控制字符不能靠解实体被引入。
    if unicodedata.category(value).startswith("C") or value in "\u2028\u2029\ufffd":
        return None
    return value


def clean_html_fragment(text: str, newline: str, max_characters: int) -> str | None:
    """返回一次替换的结果；未知/属性/不配对标签和过长片段原样保留。"""
    if not text or len(text) > max_characters:
        return None
    if any((ord(character) < 32 and character != "\t") or character in "\u2028\u2029" for character in text):
        return None
    tokens = list(_TOKEN.finditer(text))
    if not tokens:
        return None
    stack, tags, cursor = [], {}, 0
    for token in tokens:
        if "<" in text[cursor:token.start()] or ">" in text[cursor:token.start()]:
            return None
        raw = token.group()
        if raw.startswith("<"):
            tag_match = _TAG.fullmatch(raw)
            if tag_match is None:
                return None
            closing, name, self_closing = tag_match.groups()
            name = name.lower()
            if name == "br":
                if closing:
                    return None
            else:
                if self_closing:
                    return None
                if closing:
                    if not stack or stack.pop() != name:
                        return None
                else:
                    stack.append(name)
            tags[token.start()] = (name, bool(closing))
        cursor = token.end()
    if stack or "<" in text[cursor:] or ">" in text[cursor:]:
        return None

    pieces, cursor = [], 0
    line_has_text, pending_block_break = False, False

    def emit_break() -> None:
        nonlocal line_has_text, pending_block_break
        pieces.append(newline)
        line_has_text, pending_block_break = False, False

    def emit_text(value: str) -> None:
        nonlocal line_has_text, pending_block_break
        has_text = bool(value.strip(_HORIZONTAL))
        if pending_block_break and has_text:
            emit_break()
        pieces.append(value)
        line_has_text = line_has_text or has_text

    for token in tokens:
        emit_text(text[cursor:token.start()])
        raw = token.group()
        if token.start() in tags:
            name, closing = tags[token.start()]
            if name == "br":
                emit_break()
            elif name in {"p", "div"}:
                if closing:
                    pending_block_break = pending_block_break or line_has_text
                else:
                    if line_has_text:
                        emit_break()
                    pending_block_break = False
        else:
            # 只解原始输入的实体一次；新出现的尖括号不再次作为标签处理。
            emit_text(_entity_value(raw) or raw)
        cursor = token.end()
    emit_text(text[cursor:])
    result = "".join(pieces)
    return result if result != text else None
