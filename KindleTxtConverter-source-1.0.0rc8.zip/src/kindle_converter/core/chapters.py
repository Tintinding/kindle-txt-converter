"""识别原文标题、提示章节跳号并支持人工修正目录。"""

from collections.abc import Iterator
from dataclasses import dataclass, field, replace
import re
from typing import Literal

from .encoding import DecodedText
from .headings import short_heading_text
from .text_lines import LiteralTextGuard, is_complete_blank, iter_physical_lines


HeadingKind = Literal["chapter", "volume", "special"]
_HORIZONTAL = " \t\u3000"
_NUMERAL = r"(?:[0-9０-９]{1,16}|[零〇一二两三四五六七八九十百千万]{1,16})"
_SEPARATOR = r"[ \t\u3000:：]+"
_NUMBERED = re.compile(
    rf"(?:第(?P<volume>{_NUMERAL})卷{_SEPARATOR})?"
    rf"第(?P<number>{_NUMERAL})(?P<unit>[章节回卷])(?:{_SEPARATOR}(?P<subtitle>.+))?"
)
_SPECIAL = re.compile(
    rf"(?:序章|楔子|引子|前言|后记|尾声|终章|番外(?P<number>{_NUMERAL})?)(?:{_SEPARATOR}.+)?"
)
_DIGITS = {character: number for number, character in enumerate("零一二三四五六七八九")}
_DIGITS.update({"〇": 0, "两": 2})
_UNITS = {"千": 1000, "百": 100, "十": 10, "": 1}
_CHINESE_TERM = re.compile(r"([零〇]?)([一二两三四五六七八九])([千百十]?)")
_QUOTE_PAIRS = {"“": "”", "‘": "’", "「": "」", "『": "』", '"': '"'}
_QUOTE_MARKS = re.compile(r'[“”‘’「」『』"]')
_TITLE_GAP = re.compile(r"[ \t\u3000\r\n]*")
_INVALID_TITLE_CHARACTERS = re.compile(r"[\x00-\x08\x0a-\x1f\x7f-\x9f\u2028\u2029\ud800-\udfff]")


class ChapterError(ValueError):
    """可向用户展示的章节分析错误。"""


@dataclass(frozen=True)
class ChapterHeading:
    """目录显示标题及定位所用的原文区间，区间不含行尾。"""

    kind: HeadingKind
    title: str = field(repr=False)
    number: int | None
    volume_number: int | None
    line_number: int
    start: int
    end: int
    byte_start: int
    byte_end: int
    unit: str | None = None
    manually_added: bool = False
    inline_chapter_start: int | None = None


@dataclass(frozen=True)
class DuplicateHeading:
    kept: ChapterHeading
    duplicate: ChapterHeading


@dataclass(frozen=True)
class ChapterNumberGap:
    previous: ChapterHeading
    current: ChapterHeading
    volume_number: int | None


@dataclass(frozen=True)
class ChapterAnalysis:
    source_sha256: str
    encoding: str
    headings: tuple[ChapterHeading, ...]
    warnings: tuple[str, ...]
    duplicates: tuple[DuplicateHeading, ...] = ()
    number_gaps: tuple[ChapterNumberGap, ...] = ()


@dataclass(frozen=True)
class _ParsedTitle:
    kind: HeadingKind
    number: int | None
    volume_number: int | None = None
    requires_boundary: bool = True
    unit: str | None = None
    inline_chapter_offset: int | None = None


@dataclass(frozen=True)
class _HeadingCandidate:
    heading: ChapterHeading
    eligible: bool
    titled_chapter: bool


def _chinese_section(text: str) -> int | None:
    """解析万以下的正式数词，缺位须用零补明。"""
    if text.startswith("十"):
        text = "一" + text
    total, previous_unit, cursor = 0, 10000, 0
    for term in _CHINESE_TERM.finditer(text):
        if term.start() != cursor:
            return None
        zero, digit, unit_text = term.groups()
        unit = _UNITS[unit_text]
        if unit >= previous_unit or bool(zero) != (total > 0 and previous_unit > unit * 10):
            return None
        total += _DIGITS[digit] * unit
        previous_unit, cursor = unit, term.end()
    return total if cursor == len(text) and total else None


def _parse_number(text: str) -> int | None:
    if text.isdecimal():
        return int(text)
    if all(character in _DIGITS for character in text):
        return int("".join(str(_DIGITS[character]) for character in text))
    before, ten_thousand, after = text.partition("万")
    high = _chinese_section(before)
    if high is None or not ten_thousand:
        return high
    if not after:
        return high * 10000
    leading_zero = after[0] in "零〇"
    low = _chinese_section(after[1:] if leading_zero else after)
    if low is None or leading_zero != (low < 1000):
        return None
    return high * 10000 + low


def _parse_title(title: str) -> _ParsedTitle | None:
    numbered = _NUMBERED.fullmatch(title)
    if numbered is not None:
        number = _parse_number(numbered["number"])
        volume_text = numbered["volume"]
        volume_number = _parse_number(volume_text) if volume_text is not None else None
        is_volume = numbered["unit"] == "卷"
        if number is None or (volume_text is not None and (is_volume or volume_number is None)):
            return None
        return _ParsedTitle(
            "volume" if is_volume else "chapter", number, volume_number,
            requires_boundary=numbered["subtitle"] is not None and volume_text is None,
            unit=numbered["unit"],
            inline_chapter_offset=numbered.start("number") - 1 if volume_text is not None else None,
        )
    special = _SPECIAL.fullmatch(title)
    if special is None:
        return None
    number_text = special["number"]
    number = _parse_number(number_text) if number_text is not None else None
    return _ParsedTitle("special", number) if number_text is None or number is not None else None


def _heading_groups(
    text: str, candidates: list[_HeadingCandidate], quoted_until: dict[int, int],
) -> Iterator[list[_HeadingCandidate]]:
    group: list[_HeadingCandidate] = []
    blocked_until = 0
    for index, candidate in enumerate(candidates):
        blocked_until = max(blocked_until, quoted_until.get(index, 0))
        if index < blocked_until:
            continue
        heading = candidate.heading
        if group:
            previous = group[-1].heading
            if previous.title != heading.title or _TITLE_GAP.fullmatch(text, previous.end, heading.start) is None:
                yield group
                group = []
        group.append(candidate)
    if group:
        yield group


def _number_gaps(headings: list[ChapterHeading]) -> tuple[ChapterNumberGap, ...]:
    gaps = []
    volume_number = None
    previous = None
    for heading in headings:
        if heading.kind == "volume":
            volume_number, previous = heading.number, None
            continue
        if heading.kind != "chapter" or heading.number is None:
            continue
        if heading.volume_number is not None and heading.volume_number != volume_number:
            volume_number, previous = heading.volume_number, None
        if (previous is not None and previous.number is not None and previous.unit == heading.unit
                and heading.number > previous.number + 1):
            gaps.append(ChapterNumberGap(previous, heading, volume_number))
        previous = heading
    return tuple(gaps)


def _sequence_lines(groups: list[list[_HeadingCandidate]]) -> set[int]:
    """相邻带副标题章节的编号连续，且序列内有一个独立识别依据。"""
    supported: set[int] = set()
    run: list[ChapterHeading] = []
    has_boundary = False
    for group in groups:
        candidate = group[0]
        heading = candidate.heading
        previous = run[-1] if run else None
        if previous is not None and (
            not candidate.titled_chapter or previous.unit != heading.unit
            or previous.number is None or heading.number != previous.number + 1
        ):
            if len(run) >= 2 and has_boundary:
                supported.update(item.line_number for item in run)
            run.clear()
            has_boundary = False
        if candidate.titled_chapter:
            run.append(heading)
            has_boundary |= any(item.eligible for item in group)
    if len(run) >= 2 and has_boundary:
        supported.update(item.line_number for item in run)
    return supported


def analyze_chapters(source: DecodedText, *, encoding_confirmed: bool = False) -> ChapterAnalysis:
    """返回按原文排列的目录候选及重复、跳号记录，位置均指向原文。"""
    if source.requires_confirmation and encoding_confirmed is not True:
        raise ChapterError("请先检查解码预览并确认编码，再识别章节。")

    lines = iter_physical_lines(source.text)
    previous, current = None, next(lines, None)
    byte_cursor = source.bom_bytes
    literal_guard = LiteralTextGuard()
    candidates: list[_HeadingCandidate] = []
    quote_starts: dict[str, int] = {}
    quoted_until: dict[int, int] = {}
    after_colon = False

    while current is not None:
        following = next(lines, None)
        literal_blocked, context = literal_guard.scan_line(current.body)
        title = None if literal_blocked or after_colon else short_heading_text(current.body)
        if title is not None and "\ufffd" not in title and (parsed := _parse_title(title)) is not None:
            boundary = (previous is None or is_complete_blank(previous)
                        or following is None or is_complete_blank(following))
            indentation = len(current.body) - len(current.body.lstrip(_HORIZONTAL))
            start = current.start + indentation
            byte_start = byte_cursor + len(current.body[:indentation].encode(source.encoding))
            heading = ChapterHeading(
                parsed.kind, title, parsed.number, parsed.volume_number, current.number,
                start, start + len(title), byte_start, byte_start + len(title.encode(source.encoding)), parsed.unit,
                inline_chapter_start=(
                    start + parsed.inline_chapter_offset if parsed.inline_chapter_offset is not None else None
                ),
            )
            candidates.append(_HeadingCandidate(
                heading, boundary or not parsed.requires_boundary, parsed.kind == "chapter" and parsed.requires_boundary,
            ))

        # 仅在闭合时标记引用区间，缺失右引号不会屏蔽后续章节。
        for mark in _QUOTE_MARKS.finditer(context):
            character = mark.group()
            if character in quote_starts:
                start_index = quote_starts.pop(character)
                if start_index < len(candidates):
                    quoted_until[start_index] = len(candidates)
            elif character in _QUOTE_PAIRS:
                quote_starts[_QUOTE_PAIRS[character]] = len(candidates)
        if content := current.body.rstrip(_HORIZONTAL):
            after_colon = content.endswith((":", "："))
        byte_cursor += len(current.raw.encode(source.encoding))
        previous, current = current, following

    headings, duplicates = [], []
    previous_volume_end = None
    groups = list(_heading_groups(source.text, candidates, quoted_until))
    sequence_lines = _sequence_lines(groups)
    for group in groups:
        heading = group[0].heading
        follows_volume = heading.kind == "chapter" and heading.line_number - 1 == previous_volume_end
        if (not follows_volume and heading.line_number not in sequence_lines
                and not any(candidate.eligible for candidate in group)):
            continue
        headings.append(heading)
        duplicates.extend(DuplicateHeading(heading, candidate.heading) for candidate in group[1:])
        previous_volume_end = group[-1].heading.line_number if heading.kind == "volume" else None

    gaps = _number_gaps(headings)
    warnings = ()
    if not headings:
        warnings = ("未识别到章节标题，可继续转换。",)
    elif gaps:
        warnings = (f"发现 {len(gaps)} 处章节编号跳跃，请核对原文。",)
    return ChapterAnalysis(source.source_sha256, source.encoding, tuple(headings), warnings, tuple(duplicates), gaps)


def _check_line_number(line_number: int) -> None:
    if type(line_number) is not int or line_number < 1:
        raise ChapterError("原文行号必须为正整数。")


def _manual_title(title: str) -> str:
    if not isinstance(title, str) or _INVALID_TITLE_CHARACTERS.search(title) or not title.strip():
        raise ChapterError("请输入非空的单行目录标题，避免使用控制字符。")
    return title.strip()


class ChapterEditor:
    """从一次章节识别初始化可编辑目录，操作以该原文的物理行号为准。"""

    def __init__(self, source: DecodedText, *, encoding_confirmed: bool = False) -> None:
        self._source = source
        self._analysis = analyze_chapters(source, encoding_confirmed=encoding_confirmed)
        self._headings = {heading.line_number: heading for heading in self._analysis.headings}

    @property
    def source(self) -> DecodedText:
        return self._source

    @property
    def analysis(self) -> ChapterAnalysis:
        """保留初始识别及其诊断，供对照人工修正。"""
        return self._analysis

    @property
    def headings(self) -> tuple[ChapterHeading, ...]:
        """返回按原文位置排序的当前目录。"""
        return tuple(self._headings[number] for number in sorted(self._headings))

    def add(self, line_number: int, title: str, *, kind: HeadingKind = "chapter") -> ChapterHeading:
        """在指定非空原文行添加一个目录节点。"""
        _check_line_number(line_number)
        if line_number in self._headings:
            raise ChapterError("该原文行已有目录节点，可直接改名。")
        if kind not in ("chapter", "volume", "special"):
            raise ChapterError("目录节点类型无效，请选择章、卷或特殊标题。")
        title = _manual_title(title)
        line = next((line for line in iter_physical_lines(self._source.text) if line.number == line_number), None)
        if line is None or not line.body.strip():
            raise ChapterError("请选择一行有内容的原文作为目录跳转位置。")

        # 显示标题可自拟，跳转区间取自实际选中的原文行。
        start = line.start + len(line.body) - len(line.body.lstrip(_HORIZONTAL))
        end = line.start + len(line.body.rstrip(_HORIZONTAL))
        byte_start = self._source.byte_offset(start)
        byte_end = byte_start + len(self._source.text[start:end].encode(self._source.encoding))
        heading = ChapterHeading(
            kind, title, None, None, line_number, start, end, byte_start, byte_end, manually_added=True,
        )
        self._headings[line_number] = heading
        return heading

    def _existing_heading(self, line_number: int) -> ChapterHeading:
        _check_line_number(line_number)
        heading = self._headings.get(line_number)
        if heading is None:
            raise ChapterError("该原文行没有目录节点。")
        return heading

    def remove(self, line_number: int) -> None:
        """删除当前目录中的节点。"""
        self._existing_heading(line_number)
        del self._headings[line_number]

    def rename(self, line_number: int, title: str) -> ChapterHeading:
        """改名时保留节点原文位置、类型和编号。"""
        heading = self._existing_heading(line_number)
        updated = replace(heading, title=_manual_title(title))
        self._headings[line_number] = updated
        return updated
