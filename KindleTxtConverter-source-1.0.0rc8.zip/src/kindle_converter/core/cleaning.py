"""标准清理的首批规则：从不可变原文生成建议，按明确选择重新生成文本。"""

import json
import re
from collections import Counter
from collections.abc import Collection, Iterator
from dataclasses import asdict, dataclass, field
from hashlib import sha256
from heapq import merge
from pathlib import Path
from time import monotonic
from urllib.parse import urlsplit

from ..services.paths import resource_root
from .controls import control_codepoints, control_runs
from .encoding import DecodedText
from .headings import HeadingCandidate, heading_candidate
from .html_residue import clean_html_fragment
from .text_lines import LiteralTextGuard, PhysicalLine, is_complete_blank, iter_physical_lines
from .user_rules import RULE_KINDS, UserRule, compile_user_rules


_WEB_DOMAIN = re.compile(r"(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}")
_READING_APP_TARGET = re.compile(
    r"[A-Za-z0-9\u4e00-\u9fff]{0,12}阅读(?:[ \t\u3000]*APP|软件)", re.IGNORECASE | re.ASCII
)
_WATERMARK_SITE_NAME = r"[A-Za-z0-9\u4e00-\u9fff]{1,12}(?:小说站|小说网|小说阅读网|书库)"
_WATERMARK_ORIGIN = re.compile(
    rf"本书由{_WATERMARK_SITE_NAME}(?:整理制作|整理发布)|{_WATERMARK_SITE_NAME}电子版·本站整理"
)
_SOURCE_CREDIT = re.compile(r"版权|著作权|署名|授权|作者|译者|出版社|©|copyright|isbn", re.IGNORECASE)
_STRICT_LINE_CATEGORIES = {"C01", "C06", "C11", "C13"}
_REVIEW_PROMOTION_KINDS = {"promo_offer", "novel_promotion", "reading_app_offer", "source_watermark"}
_EDITORIAL_HEADINGS = {
    "作者后记", "作者的话", "后记", "作者声明", "作者说明", "版权声明", "下载声明", "免责声明", "引用示例",
}


class CleaningError(ValueError):
    """不含正文或个人路径的可展示错误。"""


@dataclass(frozen=True)
class CleaningRule:
    id: str
    name: str
    category: str
    kind: str
    values: tuple[str, ...]
    risk: str
    default_enabled: bool
    default_selected: bool
    reason: str
    test_case_ids: tuple[str, ...]
    domains: tuple[str, ...] = ()
    required_phrases: tuple[str, ...] = ()
    keep_blank_lines: int | None = None
    max_title_characters: int | None = None
    max_fragment_characters: int | None = None
    author_headers: tuple[str, ...] = ()
    promotion_offers: tuple[str, ...] = ()
    link_actions: tuple[str, ...] = ()


@dataclass(frozen=True)
class RuleSet:
    version: str
    max_line_characters: int
    rules: tuple[CleaningRule, ...]
    mode: str = "standard"


def _strings(value: object) -> tuple[str, ...]:
    if not isinstance(value, list) or not value or len(value) > 32:
        raise CleaningError("清理规则的匹配条件或用例编号无效。")
    if any(not isinstance(item, str) or not item.strip() or len(item) > 160 for item in value):
        raise CleaningError("清理规则的匹配条件或用例编号无效。")
    return tuple(value)


def load_rules(path: Path | None = None) -> RuleSet:
    """加载有限的内置匹配类型；本任务不执行自定义正则表达式。"""
    target = path if path is not None else resource_root() / "rules" / "standard.json"
    try:
        payload = json.loads(target.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        raise CleaningError("无法读取标准清理规则，请检查规则文件是否完整。") from None
    try:
        if payload["schema_version"] != 1 or payload["mode"] != "standard":
            raise CleaningError("不支持此清理规则版本或模式。")
        version, limit, entries = payload["version"], payload["max_line_characters"], payload["rules"]
        if not isinstance(version, str) or not version or len(version) > 64:
            raise CleaningError("清理规则版本无效。")
        if type(limit) is not int or not 1 <= limit <= 1000:
            raise CleaningError("清理规则的行长度上限无效。")
        if not isinstance(entries, list) or not 1 <= len(entries) <= 64:
            raise CleaningError("清理规则列表无效。")
        rules, identifiers = [], set()
        for entry in entries:
            identifier, match = entry["id"], entry["match"]
            if not isinstance(identifier, str) or re.fullmatch(r"STD-\d{3}", identifier) is None:
                raise CleaningError("清理规则编号无效。")
            if identifier in identifiers:
                raise CleaningError("清理规则编号重复。")
            identifiers.add(identifier)
            kind = match["kind"]
            if kind == "excess_blank_lines":
                action, context = "delete_blank_lines", "preserve_first_blank_line"
            elif kind == "consecutive_headings":
                action, context = "delete_duplicate_heading", "preserve_first_exact_heading"
            elif kind == "html_fragment":
                action, context = "replace_line_content", "preserve_text_require_confirmation"
            elif kind == "control_runs":
                action, context = "delete_control_characters", "preserve_layout_require_confirmation"
            else:
                action, context = "delete_line", "isolated_paragraph_without_quote_context"
            if entry["action"] != action or entry["context"] != context:
                raise CleaningError("不支持此清理动作或上下文条件。")
            if entry["risk"] not in {"low", "review"}:
                raise CleaningError("清理规则风险级别无效。")
            if type(entry["default_enabled"]) is not bool or type(entry["default_selected"]) is not bool:
                raise CleaningError("清理规则启用与选择状态必须为布尔值。")
            if entry["risk"] == "review" and entry["default_selected"]:
                raise CleaningError("待确认规则不能默认勾选。")
            for key in ("name", "category", "reason"):
                if not isinstance(entry[key], str) or not entry[key].strip() or len(entry[key]) > 240:
                    raise CleaningError("清理规则说明无效。")
            if kind not in {"prefix_url", "literal_line", "site_notice", "standalone_homepage", "author_note",
                            "promo_offer", "novel_promotion", "reading_app_offer", "source_watermark",
                            "excess_blank_lines", "consecutive_headings", "html_fragment", "control_runs"}:
                raise CleaningError("不支持此匹配类型；本轮不接受自定义正则。")
            if entry["category"] == "C01" and kind not in {"prefix_url", "standalone_homepage"}:
                raise CleaningError("推广链接规则只接受固定前缀加单一网址或已列明主页。")
            if entry["category"] == "C06" and (kind != "literal_line" or entry["risk"] != "review" or entry["default_selected"]):
                raise CleaningError("求收藏/推荐规则只接受固定整句，必须人工确认且不能默认勾选。")
            if entry["category"] == "C11" and kind != "author_note":
                raise CleaningError("作者附言规则必须匹配指定标题和固定整句。")
            if entry["category"] == "C13" and kind != "promo_offer":
                raise CleaningError("疑似推广规则必须匹配操作引导、优惠短句和单一网址。")
            keep, max_title, max_fragment = None, None, None
            if kind == "excess_blank_lines":
                keep = match["keep_blank_lines"]
                if type(keep) is not int or keep != 1 or entry["category"] != "C10":
                    raise CleaningError("空行规则必须保留一条完整空白行，并属于C10类型。")
                if any(rule.kind == "excess_blank_lines" for rule in rules):
                    raise CleaningError("空行合并规则只能定义一条。")
                values = ()
            elif kind == "consecutive_headings":
                max_title = match["max_title_characters"]
                if type(max_title) is not int or not 1 <= max_title <= 60 or entry["category"] != "C08":
                    raise CleaningError("重复标题规则的长度上限必须为1到60的整数，并属于C08类型。")
                if any(rule.kind == "consecutive_headings" for rule in rules):
                    raise CleaningError("重复标题规则只能定义一条。")
                values = ()
            elif kind == "html_fragment":
                max_fragment = match["max_fragment_characters"]
                if type(max_fragment) is not int or not 1 <= max_fragment <= 10000 or entry["category"] != "C09":
                    raise CleaningError("网页片段上限必须为1到10000的整数，并属于C09类型。")
                if entry["risk"] != "review" or entry["default_selected"]:
                    raise CleaningError("网页片段替换必须人工确认，不能默认勾选。")
                if any(rule.kind == "html_fragment" for rule in rules):
                    raise CleaningError("网页片段规则只能定义一条。")
                values = ()
            elif kind == "control_runs":
                if entry["category"] != "C10" or entry["risk"] != "review" or entry["default_selected"]:
                    raise CleaningError("控制字符规则必须属于C10，人工确认且不能默认勾选。")
                if any(rule.kind == "control_runs" for rule in rules):
                    raise CleaningError("控制字符规则只能定义一条。")
                values = ()
            elif kind == "standalone_homepage":
                if entry["category"] != "C01" or entry["risk"] != "review" or entry["default_selected"]:
                    raise CleaningError("独立主页规则必须属于C01，人工确认且不能默认勾选。")
                values = ()
            elif kind in {"promo_offer", "reading_app_offer"}:
                category = "C13" if kind == "promo_offer" else "C03"
                if entry["category"] != category or entry["risk"] != "review" or entry["default_selected"]:
                    raise CleaningError(f"此推广规则必须属于{category}，人工确认且不能默认勾选。")
                values = _strings(match["calls_to_action"])
            elif kind == "novel_promotion":
                if entry["category"] != "C02" or entry["risk"] != "review" or entry["default_selected"]:
                    raise CleaningError("组合小说推广规则必须属于C02，人工确认且不能默认勾选。")
                values = _strings(match["phrases"])
            elif kind == "source_watermark":
                if entry["category"] != "C04" or entry["risk"] != "review" or entry["default_selected"]:
                    raise CleaningError("组合网站水印规则必须属于C04，人工确认且不能默认勾选。")
                values = _strings(match["download_phrases"])
            else:
                values = _strings(match["prefixes"] if kind == "prefix_url" else match["values"])
            domains, phrases, author_headers, promotion_offers, link_actions = (), (), (), (), ()
            if kind in {"site_notice", "standalone_homepage"}:
                raw_domains = _strings(match["domains"])
                domains = tuple(domain.lower() for domain in raw_domains)
                if any(not raw.isascii() or _WEB_DOMAIN.fullmatch(domain) is None
                       for raw, domain in zip(raw_domains, domains)):
                    raise CleaningError("清理规则的域名格式无效。")
                if kind == "standalone_homepage" and any(domain.startswith("www.") for domain in domains):
                    raise CleaningError("独立主页规则的域名请使用不带www.的形式。")
            if kind == "site_notice":
                if entry["risk"] != "review" or entry["default_selected"]:
                    raise CleaningError("网站来源说明必须人工确认，不能默认勾选。")
                phrases = _strings(match["required_phrases"])
            if kind == "author_note":
                if entry["category"] != "C11" or entry["risk"] != "review" or entry["default_selected"]:
                    raise CleaningError("作者附言规则必须属于C11，人工确认且不能默认勾选。")
                author_headers = _strings(match["headers"])
                if any(part != part.strip(" \t\u3000") or re.search(r"[：:\r\n]", part)
                       for part in (*author_headers, *values)):
                    raise CleaningError("作者附言规则的标题和整句必须是单行固定文本，不含分隔冒号。")
            if kind in {"promo_offer", "reading_app_offer"}:
                promotion_offers = _strings(match["offers"])
                if any(part != part.strip(" \t\u3000") or re.search(r"[，,：:\r\n]", part)
                       for part in (*values, *promotion_offers)):
                    raise CleaningError("推广操作和优惠短句必须是单行固定文本，不含分隔标点。")
            if kind in {"novel_promotion", "source_watermark"}:
                link_actions = _strings(match["link_actions"])
                if any(part != part.strip(" \t\u3000") or re.search(r"[，,！!：:\r\n]", part)
                       for part in (*values, *link_actions)):
                    raise CleaningError("组合推广短句和访问提示必须是单行固定文本，不含分隔标点。")
            rules.append(CleaningRule(identifier, entry["name"], entry["category"], kind, values,
                                      entry["risk"], entry["default_enabled"], entry["default_selected"],
                                      entry["reason"], _strings(entry["test_case_ids"]), domains, phrases, keep,
                                      max_title, max_fragment, author_headers, promotion_offers, link_actions))
    except (KeyError, TypeError):
        raise CleaningError("清理规则缺少必填字段或字段格式错误。") from None
    return RuleSet(version, limit, tuple(rules))


@dataclass(frozen=True)
class CleaningChange:
    id: str
    source_sha256: str
    rule_id: str
    rule_name: str
    category: str
    reason: str
    risk: str
    default_selected: bool
    line_number: int
    start: int
    end: int
    byte_start: int
    byte_end: int
    original: str = field(repr=False)
    replacement: str = field(repr=False, default="")


@dataclass(frozen=True)
class ChangePreview:
    before: str = field(repr=False)
    after: str = field(repr=False)
    context_before: str = field(repr=False)
    context_after: str = field(repr=False)
    before_truncated: bool = False
    after_truncated: bool = False


@dataclass(frozen=True)
class CleaningPlan:
    source: DecodedText = field(repr=False)
    rules_version: str
    original_paragraph_count: int
    changes: tuple[CleaningChange, ...] = field(repr=False)
    fingerprint: str

    @property
    def source_sha256(self) -> str:
        return self.source.source_sha256

    @property
    def default_selected_ids(self) -> tuple[str, ...]:
        return tuple(change.id for change in self.changes if change.default_selected)

    def summary(self) -> dict:
        """普通诊断仅使用白名单元数据，不序列化完整计划或修改内容。"""
        return {
            "mode": "standard",
            "rules_version": self.rules_version,
            "source_sha256": self.source_sha256,
            "encoding": self.source.encoding,
            "original_paragraph_count": self.original_paragraph_count,
            "suggestion_count": len(self.changes),
            "default_selected_count": len(self.default_selected_ids),
            "review_required_count": sum(change.risk == "review" for change in self.changes),
            "rule_hits": dict(Counter(change.rule_id for change in self.changes)),
        }

    def preview(self, change_id: str, context_characters: int = 120, change_characters: int = 2000) -> ChangePreview:
        if type(context_characters) is not int or not 0 <= context_characters <= 2000:
            raise CleaningError("上下文预览长度必须在0到2000字符之间。")
        if type(change_characters) is not int or not 1 <= change_characters <= 10000:
            raise CleaningError("修改预览长度必须在1到10000字符之间。")
        change = next((item for item in self.changes if item.id == change_id), None)
        if change is None:
            raise CleaningError("找不到该清理建议，请重新分析。")
        return ChangePreview(change.original[:change_characters], change.replacement[:change_characters],
                             self.source.text[max(0, change.start - context_characters):change.start],
                             self.source.text[change.end:change.end + context_characters],
                             len(change.original) > change_characters, len(change.replacement) > change_characters)

    def render(self, selected_ids: Collection[str] = (), *, confirmed_review_ids: Collection[str] = ()) -> str:
        """仅应用本计划明确选择的建议；待确认项还须单独确认，可随时重新选择恢复。"""
        if isinstance(selected_ids, str) or isinstance(confirmed_review_ids, str):
            raise CleaningError("请选择清理建议编号集合。")
        try:
            selected, confirmed = set(selected_ids), set(confirmed_review_ids)
        except TypeError:
            raise CleaningError("清理选择格式无效。") from None
        known = {change.id for change in self.changes}
        if not selected <= known or not confirmed <= selected:
            raise CleaningError("清理选择包含未知或未选中的建议，请重新分析。")
        pieces, cursor = [], 0
        for change in self.changes:
            if change.id not in selected:
                continue
            if change.risk == "review" and change.id not in confirmed:
                raise CleaningError("待确认的清理建议必须明确确认后才能应用。")
            if (change.source_sha256 != self.source_sha256 or change.start < cursor
                    or not 0 <= change.start < change.end <= len(self.source.text)
                    or self.source.text[change.start:change.end] != change.original):
                raise CleaningError("清理记录与原文不一致，请重新分析。")
            pieces.extend((self.source.text[cursor:change.start], change.replacement))
            cursor = change.end
        pieces.append(self.source.text[cursor:])
        return "".join(pieces)


def _single_web_url(text: str, *, require_port_number: bool = False) -> bool:
    # 宁可保留特殊网址，也不能把链接后的中文叙事或逗号分隔的第二网址吞掉。
    if re.fullmatch(r"(?:https?://|www\.)[A-Za-z0-9][A-Za-z0-9._~:/?#\[\]@!$&()*+;=%-]*", text, flags=re.IGNORECASE) is None:
        return False
    if re.search(r"%(?![A-Fa-f0-9]{2})", text):
        return False
    try:
        parsed = urlsplit(text if text.lower().startswith(("http://", "https://")) else "http://" + text)
        hostname = parsed.hostname or ""
        if parsed.username is not None or parsed.password is not None:
            return False
        if require_port_number and parsed.netloc.endswith(":"):
            return False
        if parsed.port is not None and not 1 <= parsed.port <= 65535:
            return False
        if re.search(r"https?://|www\.", parsed.path + parsed.query + parsed.fragment, flags=re.IGNORECASE):
            return False
    except ValueError:
        return False
    return _WEB_DOMAIN.fullmatch(hostname) is not None


def _standalone_homepage(body: str, domains: tuple[str, ...]) -> bool:
    """仅接受已知站点的根地址，保留原串中多出的任何字符。"""
    if not body.isascii():
        return False
    address = body.lower()
    if address.startswith("https://"):
        address = address.removeprefix("https://")
    elif address.startswith("http://"):
        address = address.removeprefix("http://")
    elif not address.startswith("www."):
        return False
    # 精确匹配原始主机和可选斜杠，端口及空查询/片段也不接受。
    return address.removesuffix("/").removeprefix("www.") in domains


def _matches_promotion(body: str, rule: CleaningRule) -> bool:
    for action in rule.values:
        if not body.startswith(action):
            continue
        rest = body[len(action):].lstrip(" \t\u3000")
        if rest.startswith(("，", ",")):
            rest = rest[1:].lstrip(" \t\u3000")
        rest = rest.removeprefix("即可").lstrip(" \t\u3000")
        parts = re.split(r"[：:]", rest, maxsplit=1)
        if len(parts) != 2 or parts[0].rstrip(" \t\u3000") not in rule.promotion_offers:
            continue
        link = parts[1].strip(" \t\u3000")
        if "@" not in link and _single_web_url(link, require_port_number=True):
            return True
    return False


def _matches_novel_promotion(body: str, rule: CleaningRule) -> bool:
    parts = re.split(r"[：:]", body, maxsplit=1)
    if len(parts) != 2:
        return False
    message, link = parts
    fragments = re.split(r"[，,！!]", message, maxsplit=1)
    if (len(fragments) != 2 or fragments[0].rstrip(" \t\u3000") not in rule.values
            or fragments[1].strip(" \t\u3000") not in rule.link_actions):
        return False
    link = link.strip(" \t\u3000")
    return "@" not in link and _single_web_url(link, require_port_number=True)


def _matches_reading_app_offer(body: str, rule: CleaningRule) -> bool:
    parts = re.split(r"[，,]", body, maxsplit=1)
    if len(parts) != 2:
        return False
    instruction, offer = parts
    offer = offer.strip(" \t\u3000")
    if offer.endswith(("。", ".", "！", "!")):
        offer = offer[:-1]
    if offer not in rule.promotion_offers:
        return False
    for action in rule.values:
        if instruction.startswith(action):
            target = instruction[len(action):].strip(" \t\u3000")
            if _READING_APP_TARGET.fullmatch(target) is not None:
                return True
    return False


def _matches_source_watermark(body: str, rule: CleaningRule) -> bool:
    parts = re.split(r"[，,]", body, maxsplit=1)
    if len(parts) != 2:
        return False
    origin, pitch = (part.strip(" \t\u3000") for part in parts)
    if _WATERMARK_ORIGIN.fullmatch(origin) is None or _SOURCE_CREDIT.search(body):
        return False
    download = pitch[:-1] if pitch.endswith(("。", ".", "！", "!")) else pitch
    if download in rule.values:
        return True
    link_parts = re.split(r"[：:]", pitch, maxsplit=1)
    if len(link_parts) != 2 or link_parts[0].rstrip(" \t\u3000") not in rule.link_actions:
        return False
    url = link_parts[1].strip(" \t\u3000")
    return "@" not in url and _single_web_url(url, require_port_number=True)


def _matches(body: str, rule: CleaningRule, *, after_author_heading: bool) -> bool:
    if rule.kind in {"excess_blank_lines", "consecutive_headings", "html_fragment", "control_runs"}:
        return False
    if rule.kind == "literal_line":
        return body in rule.values
    if rule.kind == "site_notice":
        return _site_notice(body, rule)
    if rule.kind == "standalone_homepage":
        return _standalone_homepage(body, rule.domains)
    if rule.kind == "promo_offer":
        return _matches_promotion(body, rule)
    if rule.kind == "novel_promotion":
        return _matches_novel_promotion(body, rule)
    if rule.kind == "reading_app_offer":
        return _matches_reading_app_offer(body, rule)
    if rule.kind == "source_watermark":
        return _matches_source_watermark(body, rule)
    if rule.kind == "author_note":
        if after_author_heading and body in rule.values:
            return True
        parts = re.split(r"[：:]", body, maxsplit=1)
        return (len(parts) == 2 and parts[0] in rule.author_headers
                and parts[1].strip(" \t\u3000") in rule.values)
    for prefix in rule.values:
        if body.startswith(prefix) and _single_web_url(
                body[len(prefix):].strip(" \t\u3000"), require_port_number=True):
            return True
    return False


@dataclass
class _BlankRun:
    start: int | None = None
    end: int = 0
    byte_start: int = 0
    byte_end: int = 0
    line_number: int = 0
    line_count: int = 0
    contextual_risk: bool = False

    def add(self, line: PhysicalLine, byte_start: int, byte_end: int, contextual_risk: bool) -> None:
        if self.line_count == 0:
            self.contextual_risk = contextual_risk
        elif self.line_count == 1:
            # 首条完整空白行从不进入删除区间。
            self.start, self.byte_start, self.line_number = line.start, byte_start, line.number
        self.end, self.byte_end = line.end, byte_end
        self.line_count += 1

    def change(self, source: DecodedText, rule: CleaningRule, plan_key: str) -> CleaningChange | None:
        if self.start is None:
            return None
        risk = "review" if self.contextual_risk or rule.risk == "review" else "low"
        reason = rule.reason
        if self.contextual_risk:
            reason += "引用、附言或代码示例中的空白可能有意保留，须人工确认。"
        return CleaningChange(
            f"{plan_key}:{rule.id}:{self.start}:{self.end}", source.source_sha256, rule.id,
            rule.name, rule.category, reason, risk, rule.default_selected and risk == "low",
            self.line_number, self.start, self.end, self.byte_start, self.byte_end,
            source.text[self.start:self.end])


@dataclass
class _HeadingRun:
    candidate: HeadingCandidate | None = field(default=None, repr=False)
    boundary_before: bool = False
    contextual_risk: bool = False
    blank_after_last: bool = False
    duplicates: list[tuple[PhysicalLine, int, int]] = field(default_factory=list, repr=False)

    def add(self, line: PhysicalLine, byte_start: int, byte_end: int) -> None:
        self.duplicates.append((line, byte_start, byte_end))
        self.blank_after_last = False

    def finish(self, source: DecodedText, rule: CleaningRule, plan_key: str,
               boundary_after: bool) -> Iterator[CleaningChange]:
        if self.candidate is None:
            return
        uncertain = (self.contextual_risk or self.candidate.requires_review
                     or not self.boundary_before or not boundary_after)
        risk = "review" if uncertain or rule.risk == "review" else "low"
        reason = rule.reason
        if uncertain:
            reason += "标题类型、组外段落边界或所在上下文存在歧义，须人工确认。"
        for line, byte_start, byte_end in self.duplicates:
            yield CleaningChange(
                f"{plan_key}:{rule.id}:{line.start}:{line.end}", source.source_sha256, rule.id,
                rule.name, rule.category, reason, risk, rule.default_selected and risk == "low",
                line.number, line.start, line.end, byte_start, byte_end, line.raw)


def _site_notice(body: str, rule: CleaningRule) -> bool:
    """站名、已列明域名与宣传描述同时满足也只提待确认建议。"""
    for name in rule.values:
        if not body.startswith(name) or len(body) == len(name):
            continue
        remainder = body[len(name):]
        if remainder[0] not in " \t\u3000":
            continue
        parts = re.fullmatch(r"([^\s，,]+)[，,](.+)", remainder.lstrip(" \t\u3000"))
        if parts is None:
            continue
        url, description = parts.groups()
        if not _single_web_url(url):
            continue
        normalized = url if url.lower().startswith(("http://", "https://")) else "http://" + url
        hostname = (urlsplit(normalized).hostname or "").lower().removeprefix("www.")
        if hostname not in rule.domains:
            continue
        if re.search(r"https?://|www\.", description, flags=re.IGNORECASE):
            continue
        if any(mark in description for mark in "\"'“”‘’「」『』"):
            continue
        # 混在来源行中的署名、权利与联系信息应随整行保留。
        if _SOURCE_CREDIT.search(description) or "@" in description:
            continue
        if all(phrase in description for phrase in rule.required_phrases):
            return True
    return False


def analyze_cleaning(source: DecodedText, *, encoding_confirmed: bool = False,
                     rules: RuleSet | None = None, user_rules: tuple[UserRule, ...] = ()) -> CleaningPlan:
    """只在内存生成建议。每行累计编码长度，避免逐条重编码整本书前缀。"""
    if source.requires_confirmation and encoding_confirmed is not True:
        raise CleaningError("请先检查解码预览并确认编码，再分析清理建议。")
    rule_set = rules if rules is not None else load_rules()
    binding = source.source_sha256 + "\0" + source.encoding + "\0" + json.dumps(asdict(rule_set), sort_keys=True)
    custom_rules = compile_user_rules(user_rules)
    if custom_rules:
        binding += "\0" + json.dumps([asdict(rule) for rule, _ in custom_rules], sort_keys=True)
    custom_deadline = monotonic() + 20 if custom_rules else 0
    plan_key = sha256(binding.encode("utf-8")).hexdigest()
    iterator = iter_physical_lines(source.text)
    previous, current = None, next(iterator, None)
    byte_cursor, paragraphs, in_paragraph = source.bom_bytes, 0, False
    last_content, editorial_section, ambiguous_quote = "", False, False
    last_content_can_be_note_header = False
    promotion_editorial_section = False
    promotion_editorial_headings = _EDITORIAL_HEADINGS | {
        header for rule in rule_set.rules for header in rule.author_headers
    }
    quote_stack = []
    quote_pairs = {"“": "”", "「": "」", "『": "』", '"': '"'}
    single_quote_depth = 0
    changes = []
    blank_rule = next((rule for rule in rule_set.rules if rule.kind == "excess_blank_lines" and rule.default_enabled), None)
    blank_run = _BlankRun()
    heading_rule = next((rule for rule in rule_set.rules if rule.kind == "consecutive_headings" and rule.default_enabled), None)
    heading_run = _HeadingRun()
    heading_changes = []
    html_rule = next((rule for rule in rule_set.rules if rule.kind == "html_fragment" and rule.default_enabled), None)
    control_rule = next((rule for rule in rule_set.rules if rule.kind == "control_runs" and rule.default_enabled), None)
    literal_guard = LiteralTextGuard()
    first_newline = re.search(r"\r\n|\r|\n", source.text)
    preferred_newline = first_newline.group() if first_newline is not None else "\n"
    while current is not None:
        following = next(iterator, None)
        body = current.body.strip(" \t\u3000")
        literal_blocked, context_text = literal_guard.scan_line(current.body)
        protected_content = literal_blocked or bool(single_quote_depth)
        byte_end = byte_cursor + len(current.raw.encode(source.encoding, errors="strict"))
        contextual_layout = (protected_content or bool(quote_stack) or ambiguous_quote
                             or editorial_section or last_content.endswith((":", "：")))
        complete_blank = is_complete_blank(current)
        candidate = None
        if blank_rule is not None:
            if complete_blank:
                blank_run.add(current, byte_cursor, byte_end, contextual_layout)
            else:
                # 在读取下一正文行的引号/附言状态前结束空白段。
                change = blank_run.change(source, blank_rule, plan_key)
                if change is not None:
                    changes.append(change)
                blank_run = _BlankRun()
        if heading_rule is not None:
            candidate = heading_candidate(body, heading_rule.max_title_characters)
            if candidate is not None:
                if heading_run.candidate is not None and candidate.text == heading_run.candidate.text:
                    heading_run.add(current, byte_cursor, byte_end)
                else:
                    heading_changes.extend(heading_run.finish(source, heading_rule, plan_key, heading_run.blank_after_last))
                    heading_run = _HeadingRun(candidate, previous is None or is_complete_blank(previous), contextual_layout)
            elif complete_blank:
                if heading_run.candidate is not None:
                    heading_run.blank_after_last = True
            else:
                # 在下一行改变引用/附言状态之前，统一决定整组风险。
                heading_changes.extend(heading_run.finish(source, heading_rule, plan_key, heading_run.blank_after_last))
                heading_run = _HeadingRun()
        if body:
            if not in_paragraph:
                paragraphs += 1
            in_paragraph = True
            if not literal_blocked and body in _EDITORIAL_HEADINGS:
                editorial_section = True
            if not literal_blocked and not promotion_editorial_section:
                heading = body[:-1] if body.endswith((":", "：")) else body
                promotion_editorial_section = heading in promotion_editorial_headings
            # 本任务不推断章节结束位置；进入附言区后只降低建议风险，不自动退出。
            line_claimed = False
            before_boundary = previous is None or is_complete_blank(previous)
            after_boundary = following is None or is_complete_blank(following)
            complete_boundaries = before_boundary and after_boundary
            in_quote = bool(quote_stack) or ambiguous_quote
            after_colon = last_content.endswith((":", "："))
            previous_header = last_content[:-1] if after_colon and last_content_can_be_note_header else last_content
            within_line_limit = len(current.body) <= rule_set.max_line_characters
            if within_line_limit and not protected_content:
                for rule in rule_set.rules:
                    if not rule.default_enabled:
                        continue
                    after_author_heading = (rule.kind == "author_note" and last_content_can_be_note_header
                                            and previous_header in rule.author_headers)
                    if not _matches(body, rule, after_author_heading=after_author_heading):
                        continue
                    isolated = (previous is None or not previous.body.strip()) and (following is None or not following.body.strip())
                    quoted_context = in_quote or (after_colon and not after_author_heading)
                    if rule.category in _STRICT_LINE_CATEGORIES or rule.kind in {"novel_promotion", "source_watermark"}:
                        if not complete_boundaries or quoted_context:
                            continue
                        if editorial_section and rule.kind == "standalone_homepage":
                            continue
                    if promotion_editorial_section and rule.kind in _REVIEW_PROMOTION_KINDS:
                        continue
                    if rule.kind == "reading_app_offer" and (quoted_context or not (before_boundary or after_boundary)):
                        continue
                    contextual_risk = not isolated or quoted_context or editorial_section
                    if rule.category in {"C03", "C05"}:
                        contextual_risk = contextual_risk or not complete_boundaries or promotion_editorial_section
                    requires_review = rule.kind in {"standalone_homepage", "author_note"} or rule.kind in _REVIEW_PROMOTION_KINDS
                    risk = "review" if contextual_risk or rule.risk == "review" or requires_review else "low"
                    reason = rule.reason
                    if contextual_risk and rule.kind != "author_note":
                        reason += "前后段落或引用/附言上下文存在歧义，须人工确认。"
                    changes.append(CleaningChange(
                        f"{plan_key}:{rule.id}:{current.start}:{current.end}", source.source_sha256, rule.id,
                        rule.name, rule.category, reason, risk, rule.default_selected and risk == "low",
                        current.number, current.start, current.end, byte_cursor, byte_end, current.raw))
                    line_claimed = True
                    break
            has_control_changes = False
            if control_rule is not None and not line_claimed:
                character_cursor, run_byte_cursor = 0, byte_cursor
                for start, end in control_runs(current.body):
                    # 每个源片段只累计一次编码长度，避免多次编码整行前缀。
                    run_byte_cursor += len(current.body[character_cursor:start].encode(source.encoding, errors="strict"))
                    original = current.body[start:end]
                    run_byte_end = run_byte_cursor + len(original.encode(source.encoding, errors="strict"))
                    reason = control_rule.reason + "（" + control_codepoints(original) + "）"
                    changes.append(CleaningChange(
                        f"{plan_key}:{control_rule.id}:{current.start + start}:{current.start + end}",
                        source.source_sha256, control_rule.id, control_rule.name, control_rule.category,
                        reason, "review", False, current.number, current.start + start, current.start + end,
                        run_byte_cursor, run_byte_end, original))
                    character_cursor, run_byte_cursor = end, run_byte_end
                    has_control_changes = True
            if html_rule is not None and not line_claimed and not protected_content and not has_control_changes:
                ending = current.raw[len(current.body):]
                replacement = clean_html_fragment(current.body, ending or preferred_newline, html_rule.max_fragment_characters)
                if replacement is not None:
                    changes.append(CleaningChange(
                        f"{plan_key}:{html_rule.id}:{current.start}:{current.end}", source.source_sha256,
                        html_rule.id, html_rule.name, html_rule.category, html_rule.reason, "review", False,
                        current.number, current.start, current.end, byte_cursor, byte_end,
                        current.raw, replacement + ending))
                    line_claimed = True
            if (custom_rules and within_line_limit and complete_boundaries and not contextual_layout
                    and candidate is None and not line_claimed and not has_control_changes):
                if monotonic() > custom_deadline:
                    raise CleaningError("自定义规则分析时间超出上限，请精简规则后重试。")
                for rule, match in custom_rules:
                    if match(body):
                        rule_id = f"USER-{rule.id}"
                        changes.append(CleaningChange(
                            f"{plan_key}:{rule_id}:{current.start}:{current.end}", source.source_sha256, rule_id,
                            RULE_KINDS[rule.kind], "自定义", "自定义规则匹配，须人工确认。", "review", False,
                            current.number, current.start, current.end, byte_cursor, byte_end, current.raw))
                        break
            # 前一条标题也必须有独立边界，普通冒号引出的示例不能开启附言匹配。
            last_content_can_be_note_header = within_line_limit and complete_boundaries and not (
                in_quote or after_colon or protected_content
            )
            # 保留嵌套引用状态；不匹配的引号宁可持续要求确认。
            for character in context_text:
                if character == '"' and quote_stack and quote_stack[-1] == '"':
                    quote_stack.pop()
                elif character in quote_pairs:
                    quote_stack.append(quote_pairs[character])
                elif character in "”」』":
                    if quote_stack and quote_stack[-1] == character:
                        quote_stack.pop()
                    else:
                        ambiguous_quote = True
                # 跟踪中文单引号。孤立的右单引号也可能是撇号。
                elif character == "‘":
                    single_quote_depth += 1
                elif character == "’" and single_quote_depth:
                    single_quote_depth -= 1
            last_content = body
        else:
            in_paragraph = False
        byte_cursor = byte_end
        previous, current = current, following
    if blank_rule is not None:
        change = blank_run.change(source, blank_rule, plan_key)
        if change is not None:
            changes.append(change)
    if heading_rule is not None:
        heading_changes.extend(heading_run.finish(source, heading_rule, plan_key, True))
    # 标题组须等组尾边界才定风险；与已按顺序生成的空行/内容建议线性合并。
    ordered = tuple(merge(changes, heading_changes, key=lambda change: change.start))
    if any(left.end > right.start for left, right in zip(ordered, ordered[1:])):
        raise CleaningError("清理建议区间发生冲突，请检查规则后重新分析。")
    return CleaningPlan(source, rule_set.version, paragraphs, ordered, plan_key)
