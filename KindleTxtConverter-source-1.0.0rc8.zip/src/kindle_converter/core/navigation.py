"""从当前目录节点建立卷章层级和原文跳转位置。"""

from __future__ import annotations

from collections.abc import Iterator
from dataclasses import dataclass, field, replace

from .chapters import ChapterEditor, HeadingKind


@dataclass(frozen=True)
class NavigationEntry:
    title: str = field(repr=False)
    kind: HeadingKind
    line_number: int
    start: int
    children: tuple[NavigationEntry, ...] = ()

    @property
    def anchor(self) -> str:
        return f"section-{self.start}"


def build_navigation(editor: ChapterEditor) -> tuple[NavigationEntry, ...]:
    """按原文顺序建树。同一行首次声明的卷与章各有一个目标。"""
    roots: list[NavigationEntry] = []
    volume: NavigationEntry | None = None
    volume_number: int | None = None
    children: list[NavigationEntry] = []
    for heading in editor.headings:
        start = heading.start
        inline_start = heading.inline_chapter_start
        starts_inline_volume = inline_start is not None and heading.volume_number != volume_number
        if heading.kind == "volume" or starts_inline_volume:
            if volume is not None:
                roots.append(replace(volume, children=tuple(children)))
                children.clear()
            if heading.kind == "volume":
                volume = NavigationEntry(heading.title, "volume", heading.line_number, start)
                volume_number = heading.number
                continue
            assert inline_start is not None
            label = editor.source.text[start:inline_start].rstrip(" \t\u3000:：")
            volume = NavigationEntry(label, "volume", heading.line_number, start)
            volume_number = heading.volume_number
            start = inline_start
        entry = NavigationEntry(heading.title, heading.kind, heading.line_number, start)
        (children if volume is not None else roots).append(entry)
    if volume is not None:
        roots.append(replace(volume, children=tuple(children)))
    return tuple(roots)


def walk_navigation(entries: tuple[NavigationEntry, ...], depth: int = 1) -> Iterator[tuple[int, NavigationEntry]]:
    """按阅读顺序遍历目录，提供从 1 开始的层级。"""
    for entry in entries:
        yield depth, entry
        yield from walk_navigation(entry.children, depth + 1)
