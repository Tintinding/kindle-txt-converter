"""严格解码、保留原文与字节位置；推测结果不能替用户确认。"""

import codecs
from dataclasses import dataclass, field
import re

from charset_normalizer import from_bytes

from .source import SourceSnapshot


class EncodingError(ValueError):
    """可展示的中文解码错误，不包含原文或原始异常片段。"""


@dataclass(frozen=True)
class EncodingIssue:
    """一条需核对的原文行，位置区间不含行尾。"""

    line_number: int
    start: int
    end: int
    byte_start: int
    byte_end: int
    first_marker: int
    replacement_count: int
    control_count: int


@dataclass(frozen=True)
class DecodedText:
    text: str = field(repr=False)
    encoding: str
    confidence: str
    warnings: tuple[str, ...]
    requires_confirmation: bool
    bom_bytes: int
    source_sha256: str
    issues: tuple[EncodingIssue, ...] = field(default=(), repr=False)
    issue_line_count: int = 0

    def preview(self, max_lines: int = 12, max_characters: int = 2000) -> str:
        """只在显式请求时提供有界原文预览，不修剪或规范化换行。"""
        if max_lines < 1 or max_characters < 1:
            raise ValueError("预览行数和字符数必须大于零。")
        # 先限制字符，再找行边界，避免为整本书构造行列表。
        prefix = self.text[:max_characters]
        return "".join(prefix.splitlines(keepends=True)[:max_lines])

    def preview_issue(self, line_number: int, max_characters: int = 200) -> str:
        """显式预览该行，长行围绕首个异常字符截取。"""
        if type(line_number) is not int or line_number < 1:
            raise ValueError("原文行号必须为正整数。")
        if type(max_characters) is not int or not 1 <= max_characters <= 2000:
            raise ValueError("异常预览长度必须在1到2000字符之间。")
        issue = next((item for item in self.issues if item.line_number == line_number), None)
        if issue is None:
            raise ValueError("没有该行的异常位置记录。")
        start = max(issue.start, min(issue.first_marker - max_characters // 2, issue.end - max_characters))
        return self.text[start:min(issue.end, start + max_characters)]

    def byte_offset(self, character_offset: int) -> int:
        """Python 字符边界对应原文件偏移；位置0在BOM之后。"""
        if not isinstance(character_offset, int) or not 0 <= character_offset <= len(self.text):
            raise ValueError("字符位置超出原文范围。")
        return self.bom_bytes + len(self.text[:character_offset].encode(self.encoding, errors="strict"))


_SUPPORTED = {"utf-8", "utf-8-sig", "utf-16", "utf-16-le", "utf-16-be", "gbk", "gb18030"}
_CANDIDATES = ["utf_16_le", "utf_16_be", "gbk", "gb18030"]
# 维持原有解码警告的字符范围。清理规则对布局和 C1 字符有独立策略。
_UNEXPECTED_CONTROLS = re.compile(r"[\x00-\x08\x0b\x0e-\x1f\x7f]+")
_PHYSICAL_LINES = re.compile(r"([^\r\n]*)(?:\r\n|\r|\n|$)")
_MAX_ISSUE_LINES = 100


def _locate_issues(text: str, encoding: str, bom_bytes: int) -> tuple[tuple[EncodingIssue, ...], int]:
    issues = []
    line_count = 0
    encoded_until, byte_cursor = 0, bom_bytes
    for number, line in enumerate(_PHYSICAL_LINES.finditer(text), 1):
        start, end = line.span(1)
        replacement = text.find("\ufffd", start, end)
        control = _UNEXPECTED_CONTROLS.search(text, start, end)
        if replacement < 0 and control is None:
            continue
        line_count += 1
        if len(issues) >= _MAX_ISSUE_LINES:
            continue
        first_marker = control.start() if control is not None else end
        if replacement >= 0:
            first_marker = min(first_marker, replacement)
        # 每段前缀和命中行只编码一次，计入前面行尾和原文件 BOM。
        byte_start = byte_cursor + len(text[encoded_until:start].encode(encoding, errors="strict"))
        byte_end = byte_start + len(text[start:end].encode(encoding, errors="strict"))
        control_count = sum(run.end() - run.start() for run in _UNEXPECTED_CONTROLS.finditer(text, start, end))
        issues.append(EncodingIssue(number, start, end, byte_start, byte_end, first_marker,
                                    text.count("\ufffd", start, end), control_count))
        encoded_until, byte_cursor = end, byte_end
    return tuple(issues), line_count


def _canonical_encoding(label: str) -> str:
    compact = label.lower().replace("-", "").replace("_", "")
    label = {"utf8sig": "utf-8-sig", "utf16le": "utf-16-le", "utf16be": "utf-16-be"}.get(compact, label)
    try:
        name = codecs.lookup(label).name
    except LookupError:
        raise EncodingError("不支持所选编码，请选择 UTF-8、GBK、GB18030 或 UTF-16 LE/BE。") from None
    if name not in _SUPPORTED:
        raise EncodingError("不支持所选编码，请选择 UTF-8、GBK、GB18030 或 UTF-16 LE/BE。")
    return name


def _bom(content: bytes) -> tuple[str | None, int]:
    # UTF-32 LE 与 UTF-16 LE 共用前两个字节，必须先排除。
    if content.startswith((codecs.BOM_UTF32_LE, codecs.BOM_UTF32_BE)):
        raise EncodingError("当前暂不支持 UTF-32，请先另存为 UTF-8 或 UTF-16 TXT。")
    for signature, encoding in (
        (codecs.BOM_UTF8, "utf-8"),
        (codecs.BOM_UTF16_LE, "utf-16-le"),
        (codecs.BOM_UTF16_BE, "utf-16-be"),
    ):
        if content.startswith(signature):
            return encoding, len(signature)
    return None, 0


def _decode(content: bytes, encoding: str) -> str:
    try:
        text = content.decode(encoding, errors="strict")
    except UnicodeError:
        raise EncodingError(f"无法按 {encoding} 完整解码，请检查文件或重新选择编码；原文未修改。") from None
    if not text:
        raise EncodingError("TXT 只有编码标记，没有正文。")
    # 为后续可恢复修改提供可验证的位置；不接受会改变字节的隐式转码。
    if text.encode(encoding, errors="strict") != content:
        raise EncodingError("当前编码无法建立无损字节位置映射，请检查编码或将副本另存为 UTF-8；原文未修改。")
    return text


def _likely_utf16(content: bytes) -> str | None:
    if len(content) % 2:
        return None
    sample = content[:4096]
    even, odd = sample[::2], sample[1::2]
    if not odd:
        return None
    even_zeros = even.count(0) / len(even)
    odd_zeros = odd.count(0) / len(odd)
    if odd_zeros >= 0.3 and even_zeros <= 0.05:
        return "utf-16-le"
    if even_zeros >= 0.3 and odd_zeros <= 0.05:
        return "utf-16-be"
    return None


def _automatic_encoding(content: bytes) -> tuple[str, str, tuple[str, ...], bool]:
    likely = _likely_utf16(content)
    if likely is not None:
        _decode(content, likely)
        return likely, "tentative", ("文件没有 BOM，按字节结构推测为 UTF-16；请查看预览并确认编码。",), True
    try:
        _decode(content, "utf-8")
    except EncodingError:
        pass
    else:
        if content.isascii():
            return "utf-8", "tentative", (
                "文件只含 ASCII 字节，原始编码不能唯一判定；请检查 UTF-8 预览，如有异常可手动选择 UTF-16 LE/BE。",
            ), True
        return "utf-8", "high", (), False

    # 只采纳本应用支持的候选；chaos/coherence 不是正确率，不能当百分比置信度。
    matches = from_bytes(content, cp_isolation=_CANDIDATES, enable_fallback=False,
                         preemptive_behaviour=False, explain=False)
    for match in matches:
        encoding = _canonical_encoding(match.encoding)
        try:
            _decode(content, encoding)
        except EncodingError:
            continue
        warning = "未发现 BOM，自动识别仅为候选；请查看预览，必要时手动选择编码。"
        if encoding in {"gbk", "gb18030"}:
            warning += "GBK 与 GB18030 的常用字节范围重叠，无法仅凭该结果可靠区分。"
        return encoding, "tentative", (warning,), True
    raise EncodingError("无法可靠识别 TXT 编码，请手动选择编码并检查预览；可能存在损坏字节或混合编码。")


def decode_source(source: SourceSnapshot, encoding: str | None = None) -> DecodedText:
    """严格读取快照，不写文件，不规范化换行，不删除任何正文字符。"""
    if not source.content:
        raise EncodingError("TXT 文件为空，请选择包含正文的文件。")
    marked_encoding, bom_bytes = _bom(source.content)
    selected = _canonical_encoding(encoding.strip()) if encoding and encoding.strip().lower() != "auto" else None
    if selected is not None:
        if marked_encoding is not None:
            compatible = selected == marked_encoding or (selected == "utf-8-sig" and marked_encoding == "utf-8")
            compatible = compatible or (selected == "utf-16" and marked_encoding.startswith("utf-16-"))
            if not compatible:
                raise EncodingError("所选编码与文件 BOM 不一致，请选择匹配的编码或使用自动识别。")
            selected = marked_encoding
        elif selected == "utf-16":
            raise EncodingError("文件没有 UTF-16 BOM，请明确选择 UTF-16 LE 或 UTF-16 BE。")
        elif selected == "utf-8-sig":
            selected = "utf-8"
        confidence, warnings, requires_confirmation = "manual", (), False
    elif marked_encoding is not None:
        selected = marked_encoding
        confidence, warnings, requires_confirmation = "high", (), False
    else:
        selected, confidence, warnings, requires_confirmation = _automatic_encoding(source.content)

    text = _decode(source.content[bom_bytes:], selected)
    has_control = _UNEXPECTED_CONTROLS.search(text) is not None
    has_replacement = "\ufffd" in text
    if has_control:
        warnings += ("解码结果含异常控制字符；内容已保留，请检查编码与预览。",)
    if has_replacement:
        warnings += ("原文已含替代字符，可能曾发生乱码；本次未替换或修复任何字符。",)
    if not text.strip():
        warnings += ("解码后只有空白字符，请确认文件包含有效正文。",)
    requires_confirmation = requires_confirmation or bool(warnings)
    issues, issue_line_count = _locate_issues(text, selected, bom_bytes) if has_control or has_replacement else ((), 0)
    return DecodedText(text, selected, confidence, warnings, requires_confirmation, bom_bytes, source.sha256,
                       issues, issue_line_count)
