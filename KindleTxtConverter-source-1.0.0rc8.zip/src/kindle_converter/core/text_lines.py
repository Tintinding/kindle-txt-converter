"""物理行、段落边界与跨行字面块保护。"""

from collections.abc import Iterator
from dataclasses import dataclass, field
import re

from .html_residue import HtmlTextGuard


@dataclass(frozen=True)
class PhysicalLine:
    number: int
    start: int
    end: int
    raw: str = field(repr=False)
    body: str = field(repr=False)


def iter_physical_lines(text: str) -> Iterator[PhysicalLine]:
    number = 0
    for match in re.finditer(r"[^\r\n]*(?:\r\n|\r|\n|$)", text):
        if match.start() == match.end():
            continue
        raw = match.group()
        body = raw[:-2] if raw.endswith("\r\n") else raw[:-1] if raw.endswith(("\r", "\n")) else raw
        number += 1
        yield PhysicalLine(number, match.start(), match.end(), raw, body)


def is_complete_blank(line: PhysicalLine | None) -> bool:
    return line is not None and not line.body.strip(" \t\u3000") and line.raw.endswith(("\r", "\n"))


@dataclass
class _FencedTextGuard:
    marker: str = ""
    minimum_length: int = 0

    def blocks_line(self, body: str) -> bool:
        match = re.fullmatch(r"(`{3,}|~{3,})(.*)", body)
        if self.marker:
            if (match is not None and match[1][0] == self.marker
                    and len(match[1]) >= self.minimum_length and not match[2].strip(" \t\u3000")):
                self.marker, self.minimum_length = "", 0
            return True
        if match is not None:
            self.marker, self.minimum_length = match[1][0], len(match[1])
            return True
        return False


class LiteralTextGuard:
    """只由已进入字面块的对应定界符结束保护。"""

    def __init__(self) -> None:
        self._html = HtmlTextGuard()
        self._fence = _FencedTextGuard()

    def scan_line(self, body: str) -> tuple[bool, str]:
        if not self._html.in_block and self._fence.blocks_line(body.strip(" \t\u3000")):
            return True, ""
        return self._html.scan_line(body)
