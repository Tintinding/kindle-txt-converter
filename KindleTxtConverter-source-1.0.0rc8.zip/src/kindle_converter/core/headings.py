"""清理所用的狭窄标题候选，不代替后续完整章节识别引擎。"""

from dataclasses import dataclass, field
import re


_NUMBER = r"[零〇一二三四五六七八九十百千万两0-9]{1,16}"
_SEPARATOR = r"[ \t\u3000:：]+"
_NUMBERED = re.compile(rf"第{_NUMBER}[章节回卷部篇集](?:{_SEPARATOR}.+)?")
_SPECIAL = re.compile(rf"(?:序章|楔子|引子|前言|后记|尾声|番外(?:{_NUMBER})?)(?:{_SEPARATOR}.+)?")


@dataclass(frozen=True)
class HeadingCandidate:
    text: str = field(repr=False)
    requires_review: bool


def short_heading_text(text: str, max_characters: int = 60) -> str | None:
    """去除外部水平空白，并保留标题内部字符原样。"""
    value = text.strip(" \t\u3000")
    if not value or len(value) > max_characters or value.endswith((":", "：")):
        return None
    if any((ord(character) < 32 and character != "\t") or 127 <= ord(character) < 160 for character in value):
        return None
    if any(character in value for character in "。！？!?；;，,.\"'“”‘’「」『』<>@\u2028\u2029"):
        return None
    if "http://" in value.lower() or "https://" in value.lower():
        return None
    return value


def heading_candidate(text: str, max_characters: int = 60) -> HeadingCandidate | None:
    """按清理专用的短行规则判定可比较的标题。"""
    value = short_heading_text(text, max_characters)
    if value is None:
        return None
    if _NUMBERED.fullmatch(value):
        return HeadingCandidate(value, False)
    if _SPECIAL.fullmatch(value):
        return HeadingCandidate(value, True)
    return None
