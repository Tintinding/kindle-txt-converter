"""管理一次清理分析的选择和人工确认。"""

from collections.abc import Collection
from hashlib import sha256

from .cleaning import CleaningError, CleaningPlan
from .cleaning_result import AppliedChange, CleaningResult
from .source import SourceSnapshot


class CleaningSelection:
    """绑定一份不可变计划，按当前选择从原文生成结果。"""

    def __init__(self, plan: CleaningPlan) -> None:
        self._plan = plan
        self._known_ids = frozenset(change.id for change in plan.changes)
        if len(self._known_ids) != len(plan.changes):
            raise CleaningError("清理建议编号重复，请重新分析。")
        self._review_ids = frozenset(change.id for change in plan.changes if change.risk == "review")
        self._default_ids = frozenset(
            change.id for change in plan.changes if change.risk == "low" and change.default_selected
        )
        # 将选择和确认一起保存，生成结果时使用同一份状态。
        self._decisions: tuple[frozenset[str], frozenset[str]] = (self._default_ids, frozenset())

    @property
    def plan(self) -> CleaningPlan:
        return self._plan

    @property
    def selected_ids(self) -> frozenset[str]:
        return self._decisions[0]

    @property
    def confirmed_review_ids(self) -> frozenset[str]:
        return self._decisions[1]

    @property
    def pending_review_ids(self) -> frozenset[str]:
        selected, confirmed = self._decisions
        return (selected & self._review_ids) - confirmed

    def _checked_ids(self, change_ids: Collection[str]) -> frozenset[str]:
        if isinstance(change_ids, (str, bytes, bytearray)):
            raise CleaningError("请选择清理建议编号集合。")
        try:
            ids = frozenset(change_ids)
        except TypeError:
            raise CleaningError("清理选择格式无效。") from None
        if not ids <= self._known_ids:
            raise CleaningError("清理选择包含未知的建议，请重新分析。")
        return ids

    def select(self, change_ids: Collection[str]) -> None:
        """勾选一项或多项。待确认项仍须另行确认。"""
        ids = self._checked_ids(change_ids)
        selected, confirmed = self._decisions
        self._decisions = (selected | ids, confirmed)

    def confirm_review(self, change_ids: Collection[str]) -> None:
        """记录对已勾选待确认项的明确同意。"""
        ids = self._checked_ids(change_ids)
        selected, confirmed = self._decisions
        if not ids <= selected or not ids <= self._review_ids:
            raise CleaningError("只能确认已勾选且需要人工确认的建议。")
        self._decisions = (selected, confirmed | ids)

    def deselect(self, change_ids: Collection[str]) -> None:
        """取消一项或多项并清除相应的人工确认。"""
        ids = self._checked_ids(change_ids)
        selected, confirmed = self._decisions
        self._decisions = (selected - ids, confirmed - ids)

    def restore_original(self) -> None:
        """清空所有选择和确认，恢复完整原文。"""
        self._decisions = (frozenset(), frozenset())

    def restore_defaults(self) -> None:
        """恢复本计划的低风险默认建议，清除人工确认。"""
        self._decisions = (self._default_ids, frozenset())

    def summary(self) -> dict[str, int]:
        """供普通诊断使用的选择统计。"""
        selected, confirmed = self._decisions
        return {
            "selected_count": len(selected),
            "confirmed_review_count": len(confirmed),
            "pending_review_count": len((selected & self._review_ids) - confirmed),
        }

    def render(self) -> str:
        """应用当前选择。任一待确认项尚未确认时，计划拒绝生成结果。"""
        selected, confirmed = self._decisions
        return self._plan.render(selected, confirmed_review_ids=confirmed)

    def _applied_changes(self, selected: frozenset[str], confirmed: frozenset[str]) -> tuple[AppliedChange, ...]:
        return tuple(AppliedChange(change, change.id in confirmed)
                     for change in self._plan.changes if change.id in selected)

    def apply(self) -> CleaningResult:
        """按同一份选择和确认生成文本及应用记录。"""
        selected, confirmed = self._decisions
        text = self._plan.render(selected, confirmed_review_ids=confirmed)
        return CleaningResult(
            text=text,
            source_sha256=self._plan.source_sha256,
            source_encoding=self._plan.source.encoding,
            source_character_count=len(self._plan.source.text),
            rules_version=self._plan.rules_version,
            plan_fingerprint=self._plan.fingerprint,
            result_utf8_sha256=sha256(text.encode("utf-8")).hexdigest(),
            applied_changes=self._applied_changes(selected, confirmed),
        )

    def verify_application(self, result: CleaningResult, source: SourceSnapshot) -> None:
        """用调用者重新读取的源快照和当前选择核对待转换结果。"""
        plan = self._plan
        selected, confirmed = self._decisions
        if source.sha256 != plan.source_sha256 or result.source_sha256 != plan.source_sha256:
            raise CleaningError("清理结果与当前原文不一致，请重新导入并确认。")
        if (result.plan_fingerprint != plan.fingerprint or result.rules_version != plan.rules_version
                or result.source_encoding != plan.source.encoding):
            raise CleaningError("清理结果与当前规则或编码不一致，请重新应用清理。")
        if result.applied_changes != self._applied_changes(selected, confirmed):
            raise CleaningError("清理结果与当前选择不一致，请重新应用清理。")
        expected = plan.render(selected, confirmed_review_ids=confirmed)
        if (result.source_character_count != len(plan.source.text) or result.text != expected
                or result.result_utf8_sha256 != sha256(result.text.encode("utf-8")).hexdigest()):
            raise CleaningError("清理结果内容与应用记录不一致，请重新应用清理。")
