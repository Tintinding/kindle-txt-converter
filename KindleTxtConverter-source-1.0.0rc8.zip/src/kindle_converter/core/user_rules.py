"""用户自定义的待确认清理规则及本地设置。"""

from collections.abc import Callable
from contextlib import suppress
from dataclasses import asdict, dataclass, field
import json
from pathlib import Path
import re
from tempfile import NamedTemporaryFile


class UserRuleError(ValueError):
    pass


@dataclass(frozen=True)
class UserRule:
    id: str
    kind: str
    value: str = field(repr=False)
    enabled: bool = True


RULE_KINDS = {"keyword": "关键词", "line": "完整广告语", "domain": "网站域名", "regex": "正则表达式"}
_DOMAIN = re.compile(r"(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}")


def _matcher(rule: UserRule) -> Callable[[str], bool]:
    value = rule.value.strip()
    if not re.fullmatch(r"[a-f0-9]{32}", rule.id) or type(rule.enabled) is not bool:
        raise UserRuleError("自定义规则标识或启用状态无效。")
    if not value or len(rule.value) > 256 or any(ord(character) < 32 for character in rule.value):
        raise UserRuleError("规则内容须为不超过 256 字符的非空单行。")
    if rule.kind == "keyword":
        return lambda line: value in line
    if rule.kind == "line":
        return lambda line: line == value
    if rule.kind == "domain":
        if _DOMAIN.fullmatch(value.lower()) is None:
            raise UserRuleError("域名规则请填写域名，例如 example.com。")
        domain = re.compile(r"(?<![a-z0-9.-])(?:[a-z0-9-]+\.)*" + re.escape(value) + r"(?![a-z0-9.-])",
                            re.IGNORECASE)
        return lambda line: domain.search(line) is not None
    if rule.kind != "regex":
        raise UserRuleError("自定义规则类型无效。")
    from PySide6.QtCore import QRegularExpression

    if "(*" in value:
        raise UserRuleError("正则规则请使用匹配表达式，去除引擎控制指令。")
    expression = QRegularExpression("(*NO_JIT)(*LIMIT_MATCH=5000)(*LIMIT_DEPTH=256)" + value)
    if not expression.isValid() or expression.match("").hasMatch():
        raise UserRuleError("正则表达式无效或可以匹配空文本。")

    def matches(line: str) -> bool:
        match = expression.match(line)
        return match.hasMatch() and match.capturedLength() > 0

    return matches


def compile_user_rules(rules: tuple[UserRule, ...]) -> tuple[tuple[UserRule, Callable[[str], bool]], ...]:
    if len(rules) > 50 or len({rule.id for rule in rules}) != len(rules):
        raise UserRuleError("最多保存 50 条自定义规则，每条规则必须有独立标识。")
    compiled = tuple((rule, _matcher(rule)) for rule in rules)
    return tuple((rule, match) for rule, match in compiled if rule.enabled)


def load_user_rules(path: Path) -> tuple[UserRule, ...]:
    try:
        with path.open("r", encoding="utf-8") as stream:
            payload = json.loads(stream.read(64 * 1024 + 1))
        if not isinstance(payload, dict) or payload.get("version") != 1 or not isinstance(payload.get("rules"), list):
            raise UserRuleError("自定义规则文件格式无效。")
        rules = tuple(UserRule(**rule) for rule in payload["rules"])
        compile_user_rules(rules)
        return rules
    except FileNotFoundError:
        return ()
    except (OSError, AttributeError, TypeError, UnicodeError, json.JSONDecodeError):
        raise UserRuleError("无法读取自定义规则文件，请在规则设置中检查。") from None


def save_user_rules(path: Path, rules: tuple[UserRule, ...]) -> None:
    compile_user_rules(rules)
    payload = {"version": 1, "rules": [asdict(rule) for rule in rules]}
    temporary = None
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with NamedTemporaryFile(mode="w", encoding="utf-8", dir=path.parent, suffix=".tmp", delete=False) as stream:
            temporary = Path(stream.name)
            json.dump(payload, stream, ensure_ascii=False, indent=2)
        temporary.replace(path)
    except OSError:
        raise UserRuleError("无法保存自定义规则，请检查设置目录权限。") from None
    finally:
        if temporary is not None:
            with suppress(OSError):
                temporary.unlink(missing_ok=True)
