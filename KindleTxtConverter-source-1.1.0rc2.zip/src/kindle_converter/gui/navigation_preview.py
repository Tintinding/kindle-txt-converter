"""显示并编辑应用清理后的卷章目录。"""

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QIntValidator
from PySide6.QtWidgets import (
    QComboBox, QHBoxLayout, QInputDialog, QLabel, QLineEdit, QPushButton, QTreeWidget, QTreeWidgetItem,
    QVBoxLayout, QWidget,
)

from ..core.chapters import ChapterEditor, ChapterError
from ..core.navigation import build_navigation, walk_navigation


class NavigationPreview(QWidget):
    analyze_requested = Signal()

    def __init__(self) -> None:
        super().__init__()
        self.editor: ChapterEditor | None = None
        self._ready = False
        self._outline = False
        layout = QVBoxLayout(self)
        heading = QHBoxLayout()
        self.analyze_button = QPushButton("识别目录")
        self.analyze_button.clicked.connect(self.analyze_requested)
        self.status = QLabel()
        self.status.setWordWrap(True)
        heading.addWidget(self.analyze_button)
        heading.addWidget(self.status, 1)
        layout.addLayout(heading)
        self.tree = QTreeWidget()
        self.tree.setHeaderLabels(("目录标题", "清理后行号"))
        self.tree.setColumnWidth(0, 400)
        self.tree.currentItemChanged.connect(self._update_controls)
        layout.addWidget(self.tree, 1)
        controls = QHBoxLayout()
        self.line = QLineEdit()
        self.line.setPlaceholderText("行号")
        self.line.setValidator(QIntValidator(1, 2_147_483_647, self.line))
        self.line.setMaximumWidth(70)
        self.title = QLineEdit()
        self.title.setPlaceholderText("新增目录标题")
        self.kind = QComboBox()
        for label, value in (("章", "chapter"), ("卷", "volume"), ("特殊标题", "special")):
            self.kind.addItem(label, value)
        self.add_button = QPushButton("新增")
        self.add_button.clicked.connect(self.add_heading)
        self.rename_button = QPushButton("改名")
        self.rename_button.clicked.connect(self.rename_heading)
        self.remove_button = QPushButton("删除")
        self.remove_button.clicked.connect(self.remove_heading)
        for widget in (self.line, self.title, self.kind, self.add_button, self.rename_button, self.remove_button):
            controls.addWidget(widget)
        layout.addLayout(controls)
        self.set_editor(None, ready=False)

    def set_editor(self, editor: ChapterEditor | None, *, ready: bool = True) -> None:
        self._outline = False
        self.tree.setHeaderLabels(("目录标题", "清理后行号"))
        self.editor = editor
        self._ready = ready
        self._refresh()

    def set_outline(self, entries: tuple[tuple[int, str], ...]) -> None:
        """EPUB 使用原书目录，仅作只读核对，不重建章节结构。"""
        self._outline = True
        self.tree.setHeaderLabels(("目录标题", ""))
        self.editor = None
        self._ready = False
        self.tree.setUpdatesEnabled(False)
        try:
            self.tree.clear()
            # parents[d] 保存下一个深度为 d 的条目应挂到的父节点。
            parents = {0: self.tree}
            for depth, title in entries:
                level = max(0, depth)
                parent = parents.get(level, self.tree)
                item = QTreeWidgetItem(parent, [title, ""])
                parents[level + 1] = item
            self.tree.expandAll()
        finally:
            self.tree.setUpdatesEnabled(True)
        if entries:
            self.status.setText(f"EPUB 自带目录（只读），{len(entries)} 个条目。")
        else:
            self.status.setText("EPUB 没有内嵌目录，转换后可能没有章节导航。")
        self._update_controls()

    def _refresh(self, selected_line: int | None = None) -> None:
        self.tree.setUpdatesEnabled(False)
        try:
            self.tree.clear()
            if self._outline:
                return
            if self.editor is None:
                self.status.setText("分析清理建议后可识别目录。" if not self._ready else "识别当前文本的卷章目录。")
            else:
                headings = {heading.line_number: heading for heading in self.editor.headings}

                parents = {0: self.tree}
                for depth, entry in walk_navigation(build_navigation(self.editor)):
                    item = QTreeWidgetItem(parents[depth - 1], [entry.title, str(entry.line_number)])
                    parents[depth] = item
                    heading = headings[entry.line_number]
                    if entry.kind == heading.kind:
                        item.setData(0, Qt.ItemDataRole.UserRole, entry.line_number)
                        if entry.line_number == selected_line:
                            self.tree.setCurrentItem(item)
                self.tree.expandAll()
                message = f"{len(headings)} 个目录节点"
                if self.editor.analysis.warnings:
                    message += "。自动识别提示：" + " ".join(self.editor.analysis.warnings)
                self.status.setText(message)
        finally:
            self.tree.setUpdatesEnabled(True)
        self._update_controls()

    def _selected_line(self) -> int | None:
        item = self.tree.currentItem()
        return item.data(0, Qt.ItemDataRole.UserRole) if item is not None else None

    def _update_controls(self, *_args) -> None:
        self.analyze_button.setEnabled(self._ready and self.editor is None and not self._outline)
        for control in (self.line, self.title, self.kind, self.add_button):
            control.setEnabled(self.editor is not None)
        editable = self.editor is not None and self._selected_line() is not None
        self.rename_button.setEnabled(editable)
        self.remove_button.setEnabled(editable)

    def add_heading(self) -> None:
        if self.editor is None or not self.line.hasAcceptableInput():
            self.status.setText("请输入清理后文本的有效行号。")
            return
        number = int(self.line.text())
        try:
            self.editor.add(number, self.title.text(), kind=self.kind.currentData())
        except ChapterError as error:
            self.status.setText(str(error))
        else:
            self.title.clear()
            self._refresh(number)

    def rename_heading(self) -> None:
        line = self._selected_line()
        current = self.tree.currentItem()
        if self.editor is not None and line is not None and current is not None:
            title, accepted = QInputDialog.getText(self, "目录节点改名", "目录标题", text=current.text(0))
            if accepted:
                try:
                    self.editor.rename(line, title)
                except ChapterError as error:
                    self.status.setText(str(error))
                else:
                    self._refresh(line)

    def remove_heading(self) -> None:
        line = self._selected_line()
        if self.editor is not None and line is not None:
            self.editor.remove(line)
            self._refresh()
