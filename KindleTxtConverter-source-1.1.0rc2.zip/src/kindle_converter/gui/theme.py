"""书卷风浅色主题：宣纸底色、墨色文字、朱砂点缀。

样式集中在此模块，避免散落在各个界面文件里；桌面入口启动时统一应用。
"""

from PySide6.QtGui import QFont
from PySide6.QtWidgets import QApplication

_THEME_FLAG = "_kindle_converter_bookish_theme"

STYLESHEET = """
QWidget {
    background: #F6F1E6;
    color: #2F2A24;
    font-family: "Microsoft YaHei", "Noto Sans SC", "PingFang SC", sans-serif;
    font-size: 13px;
}

QDialog {
    background: #F6F1E6;
}

/* 顶部题头 */
QLabel#appTitle {
    font-family: "Noto Serif SC", "Source Han Serif SC", "SimSun", serif;
    font-size: 25px;
    font-weight: 600;
    color: #332A20;
}
QLabel#appSubtitle {
    color: #8B7C63;
    font-size: 12px;
}
QLabel#seal {
    background: #9E3B2E;
    color: #FFF7E8;
    border-radius: 5px;
    padding: 7px 9px;
    font-family: "KaiTi", "STKaiti", "Noto Serif SC", serif;
    font-size: 19px;
}
QPushButton#licenseLink {
    background: transparent;
    border: none;
    color: #8A3A2D;
    text-decoration: underline;
    padding: 2px 4px;
}

/* 菜单栏 */
QMenuBar {
    background: #F6F1E6;
    border-bottom: 1px solid #DCCFB6;
    color: #4A4033;
}
QMenuBar::item {
    padding: 5px 12px;
    background: transparent;
}
QMenuBar::item:selected {
    background: #EADFC7;
    color: #8A3A2D;
}
QMenu {
    background: #FFFEFA;
    border: 1px solid #D8CBB2;
}
QMenu::item {
    padding: 6px 22px;
}
QMenu::item:selected {
    background: #F2E8D5;
    color: #8A3A2D;
}

/* 书签式标签页 */
QTabWidget::pane {
    border: 1px solid #DCCFB6;
    border-radius: 6px;
    background: #FFFDF7;
    top: -1px;
}
QTabBar::tab {
    background: #F1E9D9;
    border: 1px solid #DCCFB6;
    border-bottom: none;
    border-top-left-radius: 5px;
    border-top-right-radius: 5px;
    padding: 7px 18px;
    margin-right: 2px;
    color: #6E5C42;
    font-family: "Noto Serif SC", "Source Han Serif SC", "SimSun", serif;
    font-size: 13px;
}
QTabBar::tab:selected {
    background: #FFFDF7;
    border-color: #C9A66B;
    color: #8A3A2D;
    font-weight: 600;
}
QTabBar::tab:hover:!selected {
    background: #F7EFDF;
}

/* 分区卡片（保留给内嵌面板复用） */
QGroupBox#sectionCard {
    background: #FFFDF7;
    border: 1px solid #DCCFB6;
    border-radius: 8px;
    margin-top: 15px;
    padding: 20px 14px 12px 14px;
    font-family: "Noto Serif SC", "Source Han Serif SC", "SimSun", serif;
    font-size: 15px;
    font-weight: 600;
    color: #4A3A2A;
}
QGroupBox#sectionCard::title {
    subcontrol-origin: margin;
    subcontrol-position: top left;
    left: 16px;
    padding: 0 8px;
    background: #FFFDF7;
    color: #8A3A2D;
}
QWidget#pageBody {
    background: transparent;
}

/* 表单控件 */
QLabel {
    background: transparent;
}
QLineEdit, QPlainTextEdit, QComboBox, QSpinBox {
    background: #FFFEFA;
    border: 1px solid #D8CBB2;
    border-radius: 5px;
    padding: 5px 8px;
    color: #2F2A24;
    selection-background-color: #C9A66B;
    selection-color: #2F2A24;
}
QLineEdit:read-only {
    background: #F5F0E3;
    color: #5E5546;
}
QLineEdit:focus, QPlainTextEdit:focus, QComboBox:focus {
    border-color: #A8874C;
}
QComboBox::drop-down {
    border: none;
    width: 22px;
}
QComboBox QAbstractItemView {
    background: #FFFEFA;
    border: 1px solid #D8CBB2;
    selection-background-color: #E7D6B0;
    selection-color: #2F2A24;
}

/* 按钮 */
QPushButton {
    background: #FBF6EA;
    border: 1px solid #D4C4A6;
    border-radius: 5px;
    padding: 6px 14px;
    color: #4A4033;
}
QPushButton:hover {
    background: #F2E8D5;
    border-color: #BCA476;
}
QPushButton:pressed {
    background: #EADFC7;
}
QPushButton:disabled {
    background: #F1ECE1;
    color: #A89D8C;
    border-color: #DED5C4;
}
QPushButton#convertButton {
    background: #9E3B2E;
    border: 1px solid #7E2E24;
    border-radius: 6px;
    color: #FFF8EC;
    font-family: "Noto Serif SC", "Source Han Serif SC", "SimSun", serif;
    font-size: 15px;
    font-weight: 600;
    padding: 9px 24px;
}
QPushButton#convertButton:hover {
    background: #8B3327;
}
QPushButton#convertButton:disabled {
    background: #B99A8D;
    border-color: #A98B7F;
    color: #F7EFE4;
}

/* 勾选框 */
QCheckBox {
    spacing: 6px;
    background: transparent;
}
QCheckBox::indicator {
    width: 16px;
    height: 16px;
    border: 1px solid #C7B792;
    border-radius: 3px;
    background: #FFFEFA;
}
QCheckBox::indicator:checked {
    background: #9E3B2E;
    border-color: #7E2E24;
}

/* 表格与目录树 */
QTableView, QTableWidget, QTreeWidget {
    background: #FFFEFA;
    alternate-background-color: #F9F5EB;
    border: 1px solid #D8CBB2;
    border-radius: 5px;
    gridline-color: #E6DCC8;
    selection-background-color: #E9D8B4;
    selection-color: #2F2A24;
}
QHeaderView::section {
    background: #F2E9D8;
    color: #5B4E3C;
    border: none;
    border-bottom: 1px solid #D8CBB2;
    padding: 5px;
    font-weight: 600;
}
QTreeWidget::item {
    padding: 3px;
}

/* 状态与进度 */
QProgressBar {
    border: 1px solid #D8CBB2;
    border-radius: 5px;
    background: #F4EEDF;
    height: 11px;
    text-align: center;
}
QProgressBar::chunk {
    background: #A8874C;
    border-radius: 4px;
}
QLabel#statusLabel {
    background: #F3EADA;
    border-left: 3px solid #A8874C;
    border-radius: 3px;
    padding: 7px 10px;
    color: #6E5C42;
}

/* 滚动区域 */
QScrollArea {
    background: transparent;
    border: none;
}
QScrollBar:vertical {
    background: #F1E9D9;
    width: 12px;
    margin: 2px;
    border-radius: 6px;
}
QScrollBar::handle:vertical {
    background: #C9B895;
    border-radius: 6px;
    min-height: 24px;
}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
    height: 0;
}
QScrollBar:horizontal {
    background: #F1E9D9;
    height: 12px;
    margin: 2px;
    border-radius: 6px;
}
QScrollBar::handle:horizontal {
    background: #C9B895;
    border-radius: 6px;
    min-width: 24px;
}
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {
    width: 0;
}

QSplitter::handle {
    background: #E8DDC8;
}
QToolTip {
    background: #FFF9E8;
    color: #3A2F23;
    border: 1px solid #C9B78F;
    padding: 4px;
}
"""


def apply_theme(app: QApplication) -> None:
    """为应用设置书卷风主题；重复调用不会覆盖用户的再次定制。"""
    if app is None or app.property(_THEME_FLAG):
        return
    app.setStyle("Fusion")
    app.setStyleSheet(STYLESHEET)

    font = QFont()
    font.setFamilies(("Microsoft YaHei", "Noto Sans SC", "PingFang SC", "sans-serif"))
    font.setPointSize(10)
    app.setFont(font)
    app.setProperty(_THEME_FLAG, True)
