"""Kindle 电子书转换器。"""

__version__ = "1.1.0rc2"
