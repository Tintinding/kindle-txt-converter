"""读取 EPUB 元数据、目录与正文段落，并按清理选择重写工作副本。

EPUB 已是结构化电子书，转换时保留原书排版、插图和样式；清理只允许
按整段删除或整段替换应用，其余字节原样复制。
"""

from dataclasses import dataclass, field
from hashlib import sha256
from html.parser import HTMLParser
from io import BytesIO
from pathlib import Path
import re
from urllib.parse import unquote, urlsplit
from xml.etree import ElementTree as ET
from zipfile import ZIP_STORED, BadZipFile, ZipFile, ZipInfo

from ..core.cleaning_selection import CleaningSelection
from ..core.encoding import DecodedText
from ..core.text_lines import iter_physical_lines


class EpubError(ValueError):
    """可直接提示用户的 EPUB 输入错误，不包含书籍正文。"""


# 单个 ZIP 成员与整本解压上限，防止异常文件耗尽内存。
_MAX_TOTAL_BYTES = 2 * 1024 ** 3
_MAX_MEMBER_BYTES = 256 * 1024 * 1024
_MAX_DESCRIPTION_CHARACTERS = 8000

_BLOCK_TAGS = {
    "p", "div", "section", "article", "aside", "header", "footer", "main", "nav",
    "h1", "h2", "h3", "h4", "h5", "h6", "li", "blockquote", "pre", "td", "th",
    "dd", "dt", "figcaption", "caption",
}
_SKIP_TAGS = {"head", "script", "style", "title", "meta", "link", "svg", "math"}
_FONT_MEDIA_TYPES = {
    "application/vnd.ms-opentype", "application/font-sfnt", "application/x-font-ttf",
    "application/x-font-opentype", "application/font-woff", "font/ttf", "font/otf",
    "font/woff", "font/woff2",
}
_XHTML_TYPES = {"application/xhtml+xml", "text/html"}


@dataclass(frozen=True)
class EpubBlock:
    """一条可参与清理的正文段落；ordinal 为该文件内的段落下标。"""

    document: int
    ordinal: int
    line_number: int
    text: str = field(repr=False)


@dataclass(frozen=True)
class EpubTocEntry:
    depth: int
    title: str = field(repr=False)


@dataclass(frozen=True)
class EpubBook:
    """导入后保持只读的 EPUB 描述，不缓存整本正文副本。"""

    path: Path = field(repr=False)
    size_bytes: int
    sha256: str
    title: str = field(repr=False)
    author: str = field(repr=False)
    description: str = field(repr=False)
    language: str
    epub_version: str
    documents: tuple[str, ...] = field(repr=False)
    blocks: tuple[EpubBlock, ...] = field(repr=False)
    toc: tuple[EpubTocEntry, ...] = field(repr=False)
    has_cover: bool
    font_obfuscated: bool = False
    warnings: tuple[str, ...] = ()

    def blocks_of(self, document: int) -> tuple[EpubBlock, ...]:
        return tuple(block for block in self.blocks if block.document == document)

    def cleaning_text(self) -> DecodedText:
        """用段落文本复用标准清理规则。

        EPUB 每个段落都是独立块，用空行分隔以符合清理规则对段落边界的判断；
        行号记录在 EpubBlock.line_number 上，供清理选择回映射。
        """
        return DecodedText(
            text="\n\n".join(block.text for block in self.blocks),
            encoding="utf-8",
            confidence="epub",
            warnings=(),
            requires_confirmation=False,
            bom_bytes=0,
            source_sha256=self.sha256,
        )

    def summary(self) -> dict:
        """诊断只记录结构统计，不包含书名、作者或正文。"""
        return {
            "epub_version": self.epub_version,
            "documents": len(self.documents),
            "paragraphs": len(self.blocks),
            "toc_entries": len(self.toc),
            "has_cover": self.has_cover,
            "font_obfuscated": self.font_obfuscated,
        }


@dataclass(frozen=True)
class EpubEdit:
    """block_index 为全书段落下标；replacement 为 None 表示删除整段。"""

    block_index: int
    replacement: str | None = field(default=None, repr=False)


def _local(tag: str) -> str:
    return tag.rsplit("}", 1)[-1].lower()


def _normalize(text: str) -> str:
    """折叠排版空白，保持与回读校验一致的比较方式。"""
    return " ".join(text.split())


def _xml(data: bytes, label: str) -> ET.Element:
    try:
        return ET.fromstring(data)
    except ET.ParseError:
        normalized = _normalize_entities(data)
        if normalized != data:
            try:
                return ET.fromstring(normalized)
            except ET.ParseError:
                pass
        raise EpubError(f"EPUB 的{label}无法解析，文件可能已损坏。") from None


def _normalize_entities(data: bytes) -> bytes:
    """XHTML 常引用未内联声明的 HTML 命名实体，转为数字实体再解析。"""
    from html.entities import name2codepoint

    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError:
        return data

    def replace(match: re.Match) -> str:
        name = match.group(1)
        if name in ("amp", "lt", "gt", "quot", "apos"):
            return match.group(0)
        codepoint = name2codepoint.get(name)
        return f"&#{codepoint};" if codepoint is not None else match.group(0)

    return re.sub(r"&([A-Za-z][A-Za-z0-9]*);", replace, text).encode("utf-8")


def _child(element: ET.Element, name: str) -> ET.Element | None:
    return next((child for child in element if _local(child.tag) == name), None)


def _text_of(element: ET.Element) -> str:
    if _local(element.tag) in _SKIP_TAGS:
        return ""
    pieces = [element.text or ""]
    for child in element:
        pieces.append(_text_of(child))
        pieces.append(child.tail or "")
    return "".join(pieces)


def _all_text(element: ET.Element) -> str:
    """元数据可能使用 dc:title 等与 HTML 同名的标签，不做跳过。"""
    pieces = [element.text or ""]
    for child in element:
        pieces.append(_all_text(child))
        pieces.append(child.tail or "")
    return "".join(pieces)


class _PlainText(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.parts: list[str] = []

    def handle_data(self, data: str) -> None:
        self.parts.append(data)


def _plain_text(value: str) -> str:
    parser = _PlainText()
    try:
        parser.feed(value)
        parser.close()
    except Exception:
        return _normalize(value)
    return _normalize("".join(parser.parts))


def _language_code(value: str) -> str:
    match = re.match(r"[A-Za-z]{2}", value.strip())
    return match.group().lower() if match is not None else ""


def _read_archive(content: bytes) -> ZipFile:
    try:
        archive = ZipFile(BytesIO(content))
    except (BadZipFile, ValueError, OSError):
        raise EpubError("不是有效的 EPUB 文件，ZIP 结构无法读取。") from None
    total = 0
    for info in archive.infolist():
        name = info.filename.replace("\\", "/")
        if name.startswith("/") or re.match(r"[A-Za-z]:", name) or ".." in name.split("/"):
            archive.close()
            raise EpubError("EPUB 内含不安全的文件路径，已停止处理。")
        if info.file_size > _MAX_MEMBER_BYTES:
            archive.close()
            raise EpubError("EPUB 内单个文件过大，无法安全处理。")
        total += info.file_size
    if total > _MAX_TOTAL_BYTES:
        archive.close()
        raise EpubError("EPUB 解压后体积过大，无法安全处理。")
    return archive


def _package_path(archive: ZipFile) -> str:
    try:
        container = archive.read("META-INF/container.xml")
    except KeyError:
        raise EpubError("EPUB 缺少 META-INF/container.xml，无法定位书籍信息。") from None
    root = _xml(container, "容器信息")
    for element in root.iter():
        if _local(element.tag) == "rootfile" and element.get("full-path"):
            return element.get("full-path").replace("\\", "/")
    raise EpubError("EPUB 的容器信息没有指定书籍描述文件。")


def _resolve(base: str, href: str) -> str:
    """把 OPF 内的相对引用解析为 ZIP 成员名，拒绝越界路径。"""
    parts = urlsplit(href)
    if parts.scheme or parts.netloc:
        raise EpubError("EPUB 含外部引用，无法离线处理。")
    relative = unquote(parts.path)
    if not relative or "\x00" in relative:
        raise EpubError("EPUB 内含无效的文件引用。")
    base_parts = base.split("/")[:-1]
    for part in relative.split("/"):
        if part in ("", "."):
            continue
        if part == "..":
            if not base_parts:
                raise EpubError("EPUB 内含越界的文件引用。")
            base_parts.pop()
        else:
            base_parts.append(part)
    return "/".join(base_parts)


def _metadata(metadata: ET.Element, fallback_title: str) -> tuple[str, str, str, str]:
    titles, creators, descriptions, languages = [], [], [], []
    for element in metadata:
        name = _local(element.tag)
        if name == "title":
            titles.append(_normalize(_all_text(element)))
        elif name == "creator":
            creators.append(_normalize(_all_text(element)))
        elif name == "description":
            descriptions.append(_plain_text(_all_text(element)))
        elif name == "language":
            languages.append(_normalize(_all_text(element)))
    title = next((value for value in titles if value), "") or fallback_title
    author = " & ".join(value for value in dict.fromkeys(creators) if value)
    description = next((value for value in descriptions if value), "")[:_MAX_DESCRIPTION_CHARACTERS]
    language = next((code for code in map(_language_code, languages) if code), "zh")
    return title, author, description, language


def _cover_present(metadata: ET.Element, items: tuple[ET.Element, ...], by_id: dict[str, ET.Element]) -> bool:
    for item in items:
        if "cover-image" in (item.get("properties") or "").split():
            return True
    for element in metadata:
        if _local(element.tag) == "meta" and (element.get("name") or "").lower() == "cover":
            identifier = element.get("content") or ""
            item = by_id.get(identifier)
            if item is not None and (item.get("media-type") or "").startswith("image/"):
                return True
    return False


def _encrypted_resources(archive: ZipFile) -> set[str]:
    names = set(archive.namelist())
    if "META-INF/encryption.xml" not in names:
        return set()
    root = _xml(archive.read("META-INF/encryption.xml"), "加密信息")
    encrypted = set()
    for element in root.iter():
        if _local(element.tag) == "cipherreference" and element.get("URI"):
            uri = unquote(urlsplit(element.get("URI")).path)
            if uri:
                encrypted.add(uri.lstrip("/"))
    return encrypted


def _toc_depth(element: ET.Element, depth: int = 0) -> list[tuple[int, str]]:
    """按 EPUB3 nav 的 ol/li 结构读取层级，忽略纯标题节点。"""
    entries: list[tuple[int, str]] = []
    for child in element:
        if _local(child.tag) != "li":
            continue
        label = ""
        nested = None
        for part in child:
            name = _local(part.tag)
            if name in ("a", "span") and not label:
                label = _normalize(_text_of(part))
            elif name in ("ol", "ul"):
                nested = part
        if label:
            entries.append((depth, label))
        if nested is not None:
            entries.extend(_toc_depth(nested, depth + 1))
    return entries


def _nav_toc(data: bytes) -> list[tuple[int, str]]:
    root = _xml(data, "导航文件")
    for element in root.iter():
        if _local(element.tag) != "nav":
            continue
        kind = next((value for name, value in element.attrib.items() if _local(name) == "type"), "")
        if "toc" not in kind.split():
            continue
        for child in element:
            if _local(child.tag) in ("ol", "ul"):
                return _toc_depth(child)
    return []


def _ncx_toc(data: bytes) -> list[tuple[int, str]]:
    root = _xml(data, "NCX 目录")
    navmap = next((element for element in root.iter() if _local(element.tag) == "navmap"), None)
    if navmap is None:
        return []

    def points(parent: ET.Element, depth: int) -> list[tuple[int, str]]:
        entries: list[tuple[int, str]] = []
        for child in parent:
            if _local(child.tag) != "navpoint":
                continue
            label = next((node for node in child if _local(node.tag) == "navlabel"), None)
            title = _normalize(_text_of(label)) if label is not None else ""
            if title:
                entries.append((depth, title))
            entries.extend(points(child, depth + 1))
        return entries

    return points(navmap, 0)


def _inline_text(element: ET.Element) -> str:
    name = _local(element.tag)
    if name in _SKIP_TAGS:
        return ""
    if name == "br":
        return " "
    pieces = [element.text or ""]
    for child in element:
        if _local(child.tag) in _BLOCK_TAGS:
            pass
        else:
            pieces.append(_inline_text(child))
        pieces.append(child.tail or "")
    return "".join(pieces)


def _block_text(element: ET.Element) -> str:
    pieces = [element.text or ""]
    for child in element:
        if _local(child.tag) in _BLOCK_TAGS or _local(child.tag) in _SKIP_TAGS:
            pass
        else:
            pieces.append(_inline_text(child))
        pieces.append(child.tail or "")
    return _normalize("".join(pieces))


def _collect_blocks(container: ET.Element) -> list[tuple[ET.Element, ET.Element, str]]:
    """按文档顺序返回（父节点，段落节点，规范化文本）。"""
    blocks: list[tuple[ET.Element, ET.Element, str]] = []
    for child in container:
        name = _local(child.tag)
        if name in _SKIP_TAGS:
            continue
        if name in _BLOCK_TAGS:
            text = _block_text(child)
            if text:
                blocks.append((container, child, text))
            blocks.extend(_collect_blocks(child))
        else:
            blocks.extend(_collect_blocks(child))
    return blocks


def _document_blocks(data: bytes) -> tuple[str, ...]:
    root = _xml(data, "正文文件")
    body = next((element for element in root.iter() if _local(element.tag) == "body"), None)
    if body is None:
        raise EpubError("EPUB 的正文文件缺少 body。")
    return tuple(text for _, _, text in _collect_blocks(body))


def parse_epub(path: Path) -> EpubBook:
    """只读解析一次，返回元数据、目录和正文段落；不修改原文件。"""
    try:
        resolved = path.resolve(strict=True)
        if not resolved.is_file():
            raise EpubError("请选择一个 EPUB 文件，不能选择文件夹。")
        content = resolved.read_bytes()
    except FileNotFoundError:
        raise EpubError("EPUB 文件不存在，请重新选择。") from None
    except PermissionError:
        raise EpubError("没有读取该 EPUB 的权限。") from None
    except OSError:
        raise EpubError("无法读取 EPUB，请检查文件是否可用。") from None
    if not content:
        raise EpubError("EPUB 文件为空，请选择包含正文的文件。")

    with _read_archive(content) as archive:
        package_path = _package_path(archive)
        try:
            package_data = archive.read(package_path)
        except KeyError:
            raise EpubError("EPUB 缺少书籍描述文件（OPF）。") from None
        package = _xml(package_data, "书籍描述文件")
        metadata = _child(package, "metadata")
        manifest = _child(package, "manifest")
        spine = _child(package, "spine")
        if metadata is None or manifest is None or spine is None:
            raise EpubError("EPUB 的元数据、文件清单或阅读顺序不完整。")

        items = tuple(item for item in manifest if _local(item.tag) == "item")
        by_id = {item.get("id", ""): item for item in items if item.get("id")}
        encrypted = _encrypted_resources(archive)
        if encrypted:
            for item in items:
                href = _resolve(package_path, item.get("href", ""))
                if href in encrypted and (item.get("media-type") or "").lower() not in _FONT_MEDIA_TYPES:
                    raise EpubError("此 EPUB 含 DRM 或内容加密，本工具无法转换。")
            if not encrypted <= {_resolve(package_path, item.get("href", "")) for item in items}:
                raise EpubError("此 EPUB 含无法识别的加密内容，本工具无法转换。")
        font_obfuscated = bool(encrypted)

        documents: list[str] = []
        for reference in spine:
            if _local(reference.tag) != "itemref":
                continue
            if (reference.get("linear") or "yes").lower() == "no":
                continue
            item = by_id.get(reference.get("idref", ""))
            if item is None or (item.get("media-type") or "").lower() not in _XHTML_TYPES:
                raise EpubError("EPUB 的阅读顺序包含无效或缺失的正文文件。")
            href = _resolve(package_path, item.get("href", ""))
            if href not in archive.namelist():
                raise EpubError("EPUB 的阅读顺序引用了不存在的正文文件。")
            documents.append(href)
        if not documents:
            raise EpubError("EPUB 的阅读顺序没有正文，无法转换。")

        blocks: list[EpubBlock] = []
        for index, name in enumerate(documents):
            texts = _document_blocks(archive.read(name))
            start = len(blocks)
            blocks.extend(
                EpubBlock(index, ordinal, 2 * (start + ordinal) + 1, text)
                for ordinal, text in enumerate(texts)
            )
        if not blocks:
            raise EpubError("EPUB 没有可转换的正文段落。")

        toc: list[tuple[int, str]] = []
        nav_item = next((item for item in items if "nav" in (item.get("properties") or "").split()), None)
        if nav_item is not None:
            nav_path = _resolve(package_path, nav_item.get("href", ""))
            if nav_path in archive.namelist():
                toc = _nav_toc(archive.read(nav_path))
        if not toc:
            ncx_item = by_id.get(spine.get("toc", ""))
            if ncx_item is None:
                ncx_item = next(
                    (item for item in items if (item.get("media-type") or "") == "application/x-dtbncx+xml"), None
                )
            if ncx_item is not None:
                ncx_path = _resolve(package_path, ncx_item.get("href", ""))
                if ncx_path in archive.namelist():
                    toc = _ncx_toc(archive.read(ncx_path))

        title, author, description, language = _metadata(metadata, resolved.stem)
        warnings = []
        if font_obfuscated:
            warnings.append("EPUB 的字体已加密，转换后可能使用替代字体。")
        if not toc:
            warnings.append("EPUB 没有内嵌目录，转换后可能没有章节导航。")
        return EpubBook(
            path=resolved,
            size_bytes=len(content),
            sha256=sha256(content).hexdigest(),
            title=title,
            author=author,
            description=description,
            language=language,
            epub_version=(package.get("version") or "").strip(),
            documents=tuple(documents),
            blocks=tuple(blocks),
            toc=tuple(EpubTocEntry(depth, title) for depth, title in toc),
            has_cover=_cover_present(metadata, items, by_id),
            font_obfuscated=font_obfuscated,
            warnings=tuple(warnings),
        )


def plan_block_edits(book: EpubBook, selection: CleaningSelection) -> tuple[EpubEdit, ...]:
    """把已确认的清理选择映射为整段删除或整段替换。"""
    plan = selection.plan
    if plan.source_sha256 != book.sha256:
        raise EpubError("清理分析与当前 EPUB 不一致，请重新导入后再应用。")
    # 待确认项未确认时由清理计划拒绝生成结果。
    selection.render()
    selected = selection.selected_ids
    if not selected:
        return ()

    changes = [change for change in plan.changes if change.id in selected]
    by_line: dict[int, list] = {}
    for change in changes:
        by_line.setdefault(change.line_number, []).append(change)
    lines = {line.number: line for line in iter_physical_lines(plan.source.text)}
    by_number = {block.line_number: (index, block) for index, block in enumerate(book.blocks)}
    edits: list[EpubEdit] = []
    for number in sorted(by_line):
        line = lines.get(number)
        entry = by_number.get(number)
        if line is None or entry is None:
            raise EpubError("清理记录与 EPUB 原文不一致，请重新分析。")
        block_index, block = entry
        if block.text != line.body:
            raise EpubError("EPUB 正文与清理分析不一致，请重新导入。")
        line_changes = sorted(by_line[number], key=lambda change: change.start)
        cursor = 0
        pieces: list[str] = []
        for change in line_changes:
            if change.start < line.start or change.end > line.end:
                raise EpubError("清理建议跨越多个段落，暂不支持在 EPUB 中应用。")
            start = change.start - line.start
            end = change.end - line.start
            if start < cursor:
                raise EpubError("清理建议区间重叠，请重新分析后再应用。")
            pieces.extend((line.body[cursor:start], change.replacement))
            cursor = end
        pieces.append(line.body[cursor:])
        updated = "".join(pieces).rstrip("\r\n").strip(" \t\u3000")
        if not updated:
            edits.append(EpubEdit(block_index))
        elif updated != line.body:
            edits.append(EpubEdit(block_index, updated))
    return tuple(edits)


def _namespaces(data: bytes) -> None:
    try:
        for _, (prefix, uri) in ET.iterparse(BytesIO(data), events=("start-ns",)):
            try:
                ET.register_namespace(prefix, uri)
            except ValueError:
                continue
    except ET.ParseError:
        # 由后续解析给出统一错误提示。
        return


def _rewrite_document(data: bytes, expected: tuple[str, ...], edits: tuple[EpubEdit, ...]) -> bytes:
    _namespaces(data)
    root = _xml(data, "正文文件")
    body = next((element for element in root.iter() if _local(element.tag) == "body"), None)
    if body is None:
        raise EpubError("EPUB 的正文文件缺少 body。")
    collected = _collect_blocks(body)
    if tuple(text for _, _, text in collected) != expected:
        raise EpubError("EPUB 正文在导入后发生变化，请重新导入后再转换。")
    for edit in edits:
        parent, element, _ = collected[edit.block_index]
        if edit.replacement is None:
            parent.remove(element)
        else:
            for child in list(element):
                element.remove(child)
            element.text = edit.replacement
    return ET.tostring(root, encoding="utf-8", xml_declaration=True)


def write_edited_epub(content: bytes, book: EpubBook, edits: tuple[EpubEdit, ...], destination: Path) -> int:
    """复制原 EPUB，只重写涉及改动的正文文件，返回删除段落数。"""
    if not edits:
        raise EpubError("没有可应用的清理改动。")
    grouped: dict[int, list[EpubEdit]] = {}
    for edit in edits:
        block = book.blocks[edit.block_index]
        grouped.setdefault(block.document, []).append(EpubEdit(block.ordinal, edit.replacement))
    removed = sum(edit.replacement is None for edit in edits)
    with ZipFile(BytesIO(content)) as source:
        rewritten: dict[str, bytes] = {}
        for document, document_edits in grouped.items():
            name = book.documents[document]
            expected = tuple(block.text for block in book.blocks_of(document))
            rewritten[name] = _rewrite_document(
                source.read(name), expected, tuple(document_edits)
            )
        with ZipFile(destination, "w") as target:
            if "mimetype" in source.namelist():
                info = ZipInfo("mimetype", date_time=(1980, 1, 1, 0, 0, 0))
                info.compress_type = ZIP_STORED
                info.external_attr = 0o644 << 16
                target.writestr(info, source.read("mimetype"))
            for info in source.infolist():
                if info.filename == "mimetype" or info.is_dir():
                    continue
                data = rewritten.get(info.filename)
                if data is None:
                    data = source.read(info.filename)
                copied = ZipInfo(info.filename, date_time=info.date_time)
                copied.compress_type = info.compress_type
                copied.external_attr = info.external_attr
                copied.create_system = info.create_system
                target.writestr(copied, data)
    return removed
