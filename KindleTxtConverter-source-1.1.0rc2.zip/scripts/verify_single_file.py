"""从两文件 ZIP 验证单文件包的解压、转换、封面及退出清理。"""

import importlib.util
import json
from pathlib import Path
from time import monotonic
import tomllib
import zipfile


def build_epub(path: Path) -> None:
    """在解压目录内生成最小 EPUB，验证包内 EXE 的 EPUB 转换入口。"""
    container = (
        '<?xml version="1.0"?><container version="1.0" '
        'xmlns="urn:oasis:names:tc:opendocument:xmlns:container"><rootfiles>'
        '<rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/>'
        "</rootfiles></container>"
    )
    package = (
        '<?xml version="1.0" encoding="utf-8"?>'
        '<package xmlns="http://www.idpf.org/2007/opf" version="3.0">'
        '<metadata xmlns:dc="http://purl.org/dc/elements/1.1/">'
        "<dc:title>EPUB单文件测试书</dc:title><dc:creator>测试作者</dc:creator>"
        "<dc:language>zh</dc:language></metadata><manifest>"
        '<item id="c1" href="c1.xhtml" media-type="application/xhtml+xml"/>'
        '</manifest><spine><itemref idref="c1"/></spine></package>'
    )
    chapter = (
        '<?xml version="1.0" encoding="utf-8"?>'
        '<html xmlns="http://www.w3.org/1999/xhtml"><body>'
        "<h1>第一章 开端</h1><p>包内 EPUB 正文。</p>"
        "<p>更多精彩小说，请访问：https://fiction.invalid/book</p>"
        "<p>结尾完整。</p></body></html>"
    )
    with zipfile.ZipFile(path, "x", zipfile.ZIP_DEFLATED) as zipped:
        zipped.writestr("mimetype", "application/epub+zip", compress_type=zipfile.ZIP_STORED)
        zipped.writestr("META-INF/container.xml", container)
        zipped.writestr("OEBPS/content.opf", package)
        zipped.writestr("OEBPS/c1.xhtml", chapter)


def main() -> None:
    root = Path(__file__).resolve().parent.parent
    version = tomllib.loads((root / "pyproject.toml").read_text(encoding="utf-8"))["project"]["version"]
    spec = importlib.util.spec_from_file_location("portable_helpers", root / "scripts/verify_portable.py")
    helpers = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helpers)
    archive = root / "dist" / f"KindleConverter_{version}_Windows_x64.zip"
    summary = json.loads((root / "build/reports" / f"{version}-single-summary.json").read_text(encoding="utf-8"))
    assert helpers._hash(archive) == summary["zip_sha256"]
    package = root / "build" / f"{version}-单文件解压验证"
    package.mkdir(exist_ok=False)
    with zipfile.ZipFile(archive) as zipped:
        assert sorted(zipped.namelist()) == sorted(summary["entries"])
        zipped.extractall(package)
    env = helpers._isolated_environment(package)
    env["QT_QPA_PLATFORM"] = "offscreen"
    executable = package / helpers.EXECUTABLE
    start = monotonic()
    runtime = helpers._run(executable, ["--environment"], package / "reports/environment.json", env, 180)
    assert runtime["frozen"] and runtime["application_runtime_inside_bundle"] and runtime["calibre_runtime_inside_bundle"]
    startup_seconds = monotonic() - start
    from PySide6.QtGui import QImage
    image = QImage(240, 320, QImage.Format.Format_RGB32)
    image.fill(0xFF42566A)
    source = package / "合成原文.txt"
    source.write_text("更多精彩小说请访问：www.fiction.invalid\n\n" + helpers.SOURCE_TEXT, encoding="utf-8")
    original_hash = helpers._hash(source)
    results = []
    for fmt, encoding, image_format in (("azw3", "utf-8", "PNG"), ("mobi", "gb18030", "JPG")):
        # 每种编码有独立合成源文件，验证期间保持输入只读。
        encoded_source = package / f"合成原文-{encoding}.txt"
        encoded_source.write_bytes(source.read_text(encoding="utf-8").encode(encoding))
        source_hash = helpers._hash(encoded_source)
        cover = package / f"cover.{image_format.lower()}"
        assert image.save(str(cover), image_format)
        output = package / f"转换结果.{fmt}"
        start = monotonic()
        report = helpers._run(executable, [
            "--convert", str(encoded_source), "--output", str(output),
            "--title", "单文件测试书", "--author", "测试作者",
            "--cover", str(cover), "--encoding", encoding, "--standard-cleaning",
        ], package / f"reports/{fmt}.json", env, 240)
        checked = helpers._check_output(output, fmt, report, source_hash)
        assert report["roundtrip"]["cover_verified"] is True
        assert report["cleaning"]["applied_rule_counts"] == {"STD-001": 1}
        assert helpers._hash(encoded_source) == source_hash
        checked["elapsed_seconds"] = round(monotonic() - start, 2)
        results.append(checked)
        assert not list((package / "validation-state/temp").glob("_MEI*")), "临时运行组件未清理"

    epub = package / "合成电子书.epub"
    build_epub(epub)
    epub_hash = helpers._hash(epub)
    epub_output = package / "EPUB转换结果.azw3"
    start = monotonic()
    epub_report = helpers._run(executable, [
        "--convert", str(epub), "--output", str(epub_output),
        "--title", "EPUB单文件测试书", "--author", "测试作者", "--standard-cleaning",
    ], package / "reports/epub.json", env, 240)
    assert epub_report["input_format"] == "epub"
    assert epub_report["binary"]["mobi_version"] == 8
    assert epub_report["cleaning"]["removed_paragraphs"] == 1
    assert epub_report["roundtrip"]["body_preserved"] in ("exact", "sampled")
    assert epub_report["roundtrip"]["removed_paragraphs_verified"] == 1
    assert helpers._hash(epub) == epub_hash
    results.append({
        "format": "azw3", "input": "epub", "bytes": epub_output.stat().st_size,
        "mobi_version": epub_report["binary"]["mobi_version"],
        "body_preserved": epub_report["roundtrip"]["body_preserved"],
        "removed_paragraphs_verified": 1,
        "elapsed_seconds": round(monotonic() - start, 2),
    })

    assert helpers._hash(source) == original_hash
    result = {
        "result": "passed", "version": version, "zip_sha256": summary["zip_sha256"],
        "zip_entries": summary["entries"], "startup_and_report_seconds": round(startup_seconds, 2),
        "temporary_runtime_cleaned": True, "results": results,
        "evidence_scope": "development_host_isolated_path",
    }
    helpers._write_new_json(root / "build/reports" / f"{version}-single-verified.json", result)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
