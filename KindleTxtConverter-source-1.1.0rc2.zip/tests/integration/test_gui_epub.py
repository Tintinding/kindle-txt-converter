"""桌面端 EPUB 导入、只读目录和清理分析检查（offscreen，非人工点击验收）。"""

import os
import time
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZIP_STORED, ZipFile

import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

PySide6 = pytest.importorskip("PySide6")
from PySide6.QtWidgets import QApplication  # noqa: E402

from kindle_converter.gui import MainWindow  # noqa: E402


CONTAINER = """<?xml version="1.0" encoding="UTF-8"?>
<container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container">
  <rootfiles>
    <rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/>
  </rootfiles>
</container>
"""

PACKAGE = """<?xml version="1.0" encoding="utf-8"?>
<package xmlns="http://www.idpf.org/2007/opf" version="3.0">
  <metadata xmlns:dc="http://purl.org/dc/elements/1.1/">
    <dc:title>桌面测试书</dc:title>
    <dc:creator>桌面作者</dc:creator>
    <dc:description>桌面简介</dc:description>
    <dc:language>zh</dc:language>
  </metadata>
  <manifest>
    <item id="nav" href="nav.xhtml" media-type="application/xhtml+xml" properties="nav"/>
    <item id="ch1" href="text/ch1.xhtml" media-type="application/xhtml+xml"/>
    <item id="ch2" href="text/ch2.xhtml" media-type="application/xhtml+xml"/>
  </manifest>
  <spine><itemref idref="ch1"/><itemref idref="ch2"/></spine>
</package>
"""

NAV = """<?xml version="1.0" encoding="utf-8"?>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops">
<body><nav epub:type="toc"><ol>
  <li><a href="text/ch1.xhtml">第一章 开端</a></li>
  <li><a href="text/ch2.xhtml">第二章 继续</a></li>
</ol></nav></body></html>
"""


def build_epub(path: Path) -> Path:
    with ZipFile(path, "w") as archive:
        archive.writestr("mimetype", "application/epub+zip", compress_type=ZIP_STORED)
        archive.writestr("META-INF/container.xml", CONTAINER, compress_type=ZIP_DEFLATED)
        archive.writestr("OEBPS/content.opf", PACKAGE, compress_type=ZIP_DEFLATED)
        archive.writestr("OEBPS/nav.xhtml", NAV, compress_type=ZIP_DEFLATED)
        archive.writestr(
            "OEBPS/text/ch1.xhtml",
            '<?xml version="1.0" encoding="utf-8"?>'
            '<html xmlns="http://www.w3.org/1999/xhtml"><body>'
            '<h1>第一章 开端</h1><p>正文第一段。</p>'
            '<p>更多精彩小说，请访问：https://fiction.invalid/book</p>'
            '</body></html>',
            compress_type=ZIP_DEFLATED,
        )
        archive.writestr(
            "OEBPS/text/ch2.xhtml",
            '<?xml version="1.0" encoding="utf-8"?>'
            '<html xmlns="http://www.w3.org/1999/xhtml"><body>'
            '<h1>第二章 继续</h1><p>结尾完整。</p>'
            '</body></html>',
            compress_type=ZIP_DEFLATED,
        )
    return path


def wait_until_idle(app: QApplication, window: MainWindow, timeout: float = 20) -> None:
    deadline = time.monotonic() + timeout
    while window.busy and time.monotonic() < deadline:
        app.processEvents()
        time.sleep(0.01)
    app.processEvents()
    assert not window.busy


def test_window_imports_epub_and_shows_readonly_outline(tmp_path):
    app = QApplication.instance() or QApplication([])
    source = build_epub(tmp_path / "桌面 测试书.epub")
    window = MainWindow()
    window.select_source(source)
    wait_until_idle(app, window)

    assert window.title_edit.text() == "桌面测试书"
    assert window.author_edit.text() == "桌面作者"
    assert window.description_edit.toPlainText() == "桌面简介"
    assert window.encoding_combo.isEnabled() is False
    assert "5 段" in window.encoding_label.text()
    assert window.navigation_preview.tree.topLevelItemCount() == 2
    assert window.navigation_preview.analyze_button.isEnabled() is False

    window._analyze_cleaning()
    wait_until_idle(app, window)
    assert window.cleaning_preview.selection is not None
    assert any(change.rule_id == "STD-001" for change in window.cleaning_preview.selection.plan.changes)
    window.close()


def test_outline_builds_volume_chapter_hierarchy():
    app = QApplication.instance() or QApplication([])
    window = MainWindow()
    window.navigation_preview.set_outline(((0, "第一卷"), (1, "第一章"), (0, "第二卷")))
    tree = window.navigation_preview.tree
    assert tree.topLevelItemCount() == 2
    assert tree.topLevelItem(0).childCount() == 1
    assert tree.topLevelItem(0).child(0).text(0) == "第一章"
    assert tree.topLevelItem(1).text(0) == "第二卷"
    window.close()


def test_window_converts_epub_with_real_engine(tmp_path):
    from kindle_converter.converter.calibre import CalibreEngine
    from kindle_converter.services.paths import application_root

    engine = CalibreEngine(application_root())
    if not engine.executable.is_file():
        pytest.skip("尚未准备项目内真实转换引擎")
    app = QApplication.instance() or QApplication([])
    source = build_epub(tmp_path / "桌面 测试书.epub")
    original = source.read_bytes()
    window = MainWindow()
    window.select_source(source)
    wait_until_idle(app, window)
    window._analyze_cleaning()
    wait_until_idle(app, window)
    window.cleaning_preview.select_all.click()
    window.cleaning_preview.delete_button.click()
    assert not window.cleaning_preview.has_pending

    window.output_edit.setText(str(tmp_path))
    window.format_combo.setCurrentIndex(window.format_combo.findData("azw3"))
    window.start_conversion()
    wait_until_idle(app, window, timeout=180)

    output = tmp_path / "桌面测试书.azw3"
    assert output.is_file(), window.status_label.text()
    assert "转换成功" in window.status_label.text()
    assert window.last_report["cleaning"]["removed_paragraphs"] == 1
    assert source.read_bytes() == original
    window.close()
