"""真实引擎的 EPUB 转换检查；缺少引擎时跳过，不代表实机验收。"""

from pathlib import Path
from zipfile import ZIP_DEFLATED, ZIP_STORED, ZipFile

import pytest

from kindle_converter.converter.calibre import CalibreEngine
from kindle_converter.converter.epub_source import parse_epub
from kindle_converter.core.cleaning import analyze_cleaning
from kindle_converter.core.cleaning_selection import CleaningSelection
from kindle_converter.services.paths import application_root


CONTAINER = """<?xml version="1.0" encoding="UTF-8"?>
<container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container">
  <rootfiles>
    <rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/>
  </rootfiles>
</container>
"""

PACKAGE = """<?xml version="1.0" encoding="utf-8"?>
<package xmlns="http://www.idpf.org/2007/opf" version="3.0">
  <metadata xmlns:dc="http://purl.org/dc/elements/1.1/">
    <dc:title>插图测试书</dc:title>
    <dc:creator>测试作者</dc:creator>
    <dc:language>zh</dc:language>
    <meta name="cover" content="cover-image"/>
  </metadata>
  <manifest>
    <item id="nav" href="nav.xhtml" media-type="application/xhtml+xml" properties="nav"/>
    <item id="ch1" href="text/ch1.xhtml" media-type="application/xhtml+xml"/>
    <item id="ch2" href="text/ch2.xhtml" media-type="application/xhtml+xml"/>
    <item id="pic" href="images/pic.png" media-type="image/png"/>
    <item id="cover-image" href="images/cover.png" media-type="image/png" properties="cover-image"/>
  </manifest>
  <spine>
    <itemref idref="ch1"/>
    <itemref idref="ch2"/>
  </spine>
</package>
"""

NAV = """<?xml version="1.0" encoding="utf-8"?>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops">
<body><nav epub:type="toc"><ol>
  <li><a href="text/ch1.xhtml">第一章 开端</a></li>
  <li><a href="text/ch2.xhtml">第二章 继续</a></li>
</ol></nav></body></html>
"""

CHAPTER_ONE = """<?xml version="1.0" encoding="utf-8"?>
<html xmlns="http://www.w3.org/1999/xhtml"><body>
  <h1>第一章 开端</h1>
  <p>这是第一段正文，插图随后出现。</p>
  <p><img src="../images/pic.png" alt="插图"/></p>
  <p>更多精彩小说，请访问：https://fiction.invalid/book</p>
  <p>这是第三段，包含中文标点。</p>
</body></html>
"""

CHAPTER_TWO = """<?xml version="1.0" encoding="utf-8"?>
<html xmlns="http://www.w3.org/1999/xhtml"><body>
  <h1>第二章 继续</h1>
  <p>结尾完整。</p>
</body></html>
"""


def build_epub(path: Path) -> Path:
    with ZipFile(path, "w") as archive:
        archive.writestr("mimetype", "application/epub+zip", compress_type=ZIP_STORED)
        archive.writestr("META-INF/container.xml", CONTAINER, compress_type=ZIP_DEFLATED)
        archive.writestr("OEBPS/content.opf", PACKAGE, compress_type=ZIP_DEFLATED)
        archive.writestr("OEBPS/nav.xhtml", NAV, compress_type=ZIP_DEFLATED)
        archive.writestr("OEBPS/text/ch1.xhtml", CHAPTER_ONE, compress_type=ZIP_DEFLATED)
        archive.writestr("OEBPS/text/ch2.xhtml", CHAPTER_TWO, compress_type=ZIP_DEFLATED)
        # 1x1 PNG，用于核对插图未被改写。
        archive.writestr(
            "OEBPS/images/pic.png",
            bytes.fromhex(
                "89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c489"
                "0000000d49444154789c6360000000020001e221bc330000000049454e44ae426082"
            ),
            compress_type=ZIP_DEFLATED,
        )
        archive.writestr(
            "OEBPS/images/cover.png",
            bytes.fromhex(
                "89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c489"
                "0000000d49444154789c6360000000020001e221bc330000000049454e44ae426082"
            ),
            compress_type=ZIP_DEFLATED,
        )
    return path


@pytest.mark.parametrize("fmt", ["azw3", "mobi"])
def test_real_engine_converts_epub_with_metadata_and_toc(tmp_path, fmt):
    engine = CalibreEngine(application_root())
    if not engine.executable.is_file():
        pytest.skip("尚未准备项目内真实转换引擎")
    source = build_epub(tmp_path / "插图 测试书.epub")
    original = source.read_bytes()
    output = tmp_path / f"插图 测试书.{fmt}"

    report = engine.convert_epub(source, output)

    assert output.is_file()
    assert report["binary"]["mobi_version"] == (8 if fmt == "azw3" else 6)
    assert report["input_format"] == "epub"
    assert report["roundtrip"]["body_preserved"] in ("exact", "sampled")
    assert report["roundtrip"]["metadata_verified"] is True
    assert report["roundtrip"]["toc_entries"] == 2
    assert report["epub"]["documents"] == 2
    assert report["original_unchanged"] is True
    assert source.read_bytes() == original


def test_real_engine_applies_epub_paragraph_cleaning(tmp_path):
    engine = CalibreEngine(application_root())
    if not engine.executable.is_file():
        pytest.skip("尚未准备项目内真实转换引擎")
    source = build_epub(tmp_path / "清理测试书.epub")
    original = source.read_bytes()
    book = parse_epub(source)
    selection = CleaningSelection(analyze_cleaning(book.cleaning_text()))
    assert any(change.rule_id == "STD-001" for change in selection.plan.changes)

    report = engine.convert_epub(
        source, tmp_path / "清理测试书.azw3", cleaning=selection,
    )

    assert report["cleaning"]["removed_paragraphs"] == 1
    assert report["roundtrip"]["removed_paragraphs_verified"] == 1
    assert source.read_bytes() == original
