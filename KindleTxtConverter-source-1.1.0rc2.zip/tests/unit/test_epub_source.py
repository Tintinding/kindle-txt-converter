"""EPUB 解析、清理段落映射与工作副本改写的单元测试。"""

from hashlib import sha256
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZIP_STORED, ZipFile

import pytest

from kindle_converter.converter.epub_source import (
    EpubError,
    parse_epub,
    plan_block_edits,
    write_edited_epub,
)
from kindle_converter.core.cleaning import analyze_cleaning
from kindle_converter.core.cleaning_selection import CleaningSelection


CONTAINER = """<?xml version="1.0" encoding="UTF-8"?>
<container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container">
  <rootfiles>
    <rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/>
  </rootfiles>
</container>
"""

PACKAGE = """<?xml version="1.0" encoding="utf-8"?>
<package xmlns="http://www.idpf.org/2007/opf" version="3.0" unique-identifier="bookid">
  <metadata xmlns:dc="http://purl.org/dc/elements/1.1/">
    <dc:title>测试书</dc:title>
    <dc:creator>测试作者</dc:creator>
    <dc:creator>第二作者</dc:creator>
    <dc:description>一段简介</dc:description>
    <dc:language>zh-CN</dc:language>
    <meta name="cover" content="cover-image"/>
  </metadata>
  <manifest>
    <item id="nav" href="nav.xhtml" media-type="application/xhtml+xml" properties="nav"/>
    <item id="ch1" href="text/ch1.xhtml" media-type="application/xhtml+xml"/>
    <item id="ch2" href="text/ch2.xhtml" media-type="application/xhtml+xml"/>
    <item id="cover-image" href="images/cover.jpg" media-type="image/jpeg" properties="cover-image"/>
  </manifest>
  <spine>
    <itemref idref="ch1"/>
    <itemref idref="ch2"/>
  </spine>
</package>
"""

NAV = """<?xml version="1.0" encoding="utf-8"?>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops">
<head><title>目录</title></head>
<body>
  <nav epub:type="toc">
    <ol>
      <li><a href="text/ch1.xhtml">第一章 开端</a></li>
      <li><a href="text/ch2.xhtml">第二章 继续</a></li>
    </ol>
  </nav>
</body>
</html>
"""

CHAPTER_ONE = """<?xml version="1.0" encoding="utf-8"?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head><title>第一章</title></head>
<body>
  <h1>第一章 开端</h1>
  <p>这是第一段正文&nbsp;内容。</p>
  <p>更多精彩小说，请访问：https://fiction.invalid/book</p>
  <p>这是第三段。</p>
</body>
</html>
"""

CHAPTER_TWO = """<?xml version="1.0" encoding="utf-8"?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head><title>第二章</title></head>
<body>
  <h1>第二章 继续</h1>
  <p>结尾完整。</p>
</body>
</html>
"""


def build_epub(
    path: Path,
    *,
    package: str = PACKAGE,
    chapter_one: str = CHAPTER_ONE,
    encryption: str | None = None,
    extra: dict[str, bytes] | None = None,
) -> Path:
    with ZipFile(path, "w") as archive:
        archive.writestr("mimetype", "application/epub+zip", compress_type=ZIP_STORED)
        archive.writestr("META-INF/container.xml", CONTAINER, compress_type=ZIP_DEFLATED)
        archive.writestr("OEBPS/content.opf", package, compress_type=ZIP_DEFLATED)
        archive.writestr("OEBPS/nav.xhtml", NAV, compress_type=ZIP_DEFLATED)
        archive.writestr("OEBPS/text/ch1.xhtml", chapter_one, compress_type=ZIP_DEFLATED)
        archive.writestr("OEBPS/text/ch2.xhtml", CHAPTER_TWO, compress_type=ZIP_DEFLATED)
        archive.writestr("OEBPS/images/cover.jpg", b"\xff\xd8\xff\xe0fake-jpeg", compress_type=ZIP_DEFLATED)
        if encryption is not None:
            archive.writestr("META-INF/encryption.xml", encryption, compress_type=ZIP_DEFLATED)
        for name, content in (extra or {}).items():
            archive.writestr(name, content, compress_type=ZIP_DEFLATED)
    return path


def test_parse_reads_metadata_toc_and_paragraphs(tmp_path):
    source = build_epub(tmp_path / "book.epub")
    book = parse_epub(source)

    assert book.title == "测试书"
    assert book.author == "测试作者 & 第二作者"
    assert book.description == "一段简介"
    assert book.language == "zh"
    assert book.epub_version == "3.0"
    assert [entry.title for entry in book.toc] == ["第一章 开端", "第二章 继续"]
    assert book.has_cover is True
    assert book.documents == ("OEBPS/text/ch1.xhtml", "OEBPS/text/ch2.xhtml")
    assert [block.text for block in book.blocks] == [
        "第一章 开端",
        "这是第一段正文 内容。",
        "更多精彩小说，请访问：https://fiction.invalid/book",
        "这是第三段。",
        "第二章 继续",
        "结尾完整。",
    ]
    assert [block.line_number for block in book.blocks] == [1, 3, 5, 7, 9, 11]
    assert book.sha256 == sha256(source.read_bytes()).hexdigest()
    assert book.summary()["paragraphs"] == 6


def test_parse_falls_back_to_ncx_in_epub2(tmp_path):
    package = PACKAGE.replace('version="3.0"', 'version="2.0"').replace(
        '    <item id="nav" href="nav.xhtml" media-type="application/xhtml+xml" properties="nav"/>\n', ""
    ).replace(
        '  <spine>\n', '  <spine toc="ncx">\n'
    ).replace(
        '    <item id="cover-image"',
        '    <item id="ncx" href="toc.ncx" media-type="application/x-dtbncx+xml"/>\n    <item id="cover-image"',
    )
    ncx = """<?xml version="1.0" encoding="utf-8"?>
<ncx xmlns="http://www.daisy.org/z3986/2005/ncx/" version="2005-1">
  <navMap>
    <navPoint id="p1"><navLabel><text>卷一</text></navLabel><content src="text/ch1.xhtml"/>
      <navPoint id="p2"><navLabel><text>第一章</text></navLabel><content src="text/ch1.xhtml"/></navPoint>
    </navPoint>
  </navMap>
</ncx>
"""
    source = build_epub(tmp_path / "old.epub", package=package, extra={"OEBPS/toc.ncx": ncx.encode()})
    book = parse_epub(source)
    assert book.epub_version == "2.0"
    assert [(entry.depth, entry.title) for entry in book.toc] == [(0, "卷一"), (1, "第一章")]


def test_plan_edits_deletes_selected_ad_paragraph(tmp_path):
    source = build_epub(tmp_path / "book.epub")
    book = parse_epub(source)
    selection = CleaningSelection(analyze_cleaning(book.cleaning_text()))
    ad_change = next(change for change in selection.plan.changes if change.rule_id == "STD-001")
    assert ad_change.id in selection.selected_ids

    edits = plan_block_edits(book, selection)
    assert len(edits) == 1
    assert edits[0].replacement is None
    assert book.blocks[edits[0].block_index].text.startswith("更多精彩小说")


def test_write_edited_epub_preserves_other_content_and_source(tmp_path):
    source = build_epub(tmp_path / "book.epub")
    original = source.read_bytes()
    book = parse_epub(source)
    selection = CleaningSelection(analyze_cleaning(book.cleaning_text()))
    edits = plan_block_edits(book, selection)
    destination = tmp_path / "cleaned.epub"

    removed = write_edited_epub(original, book, edits, destination)
    assert removed == 1
    assert source.read_bytes() == original
    assert sha256(original).hexdigest() == book.sha256

    cleaned = parse_epub(destination)
    texts = [block.text for block in cleaned.blocks]
    assert "更多精彩小说，请访问：https://fiction.invalid/book" not in texts
    assert "这是第一段正文 内容。" in texts
    assert "结尾完整。" in texts
    assert [entry.title for entry in cleaned.toc] == ["第一章 开端", "第二章 继续"]

    with ZipFile(destination) as archive:
        infos = archive.infolist()
        assert infos[0].filename == "mimetype"
        assert infos[0].compress_type == ZIP_STORED
        assert archive.read("OEBPS/images/cover.jpg") == b"\xff\xd8\xff\xe0fake-jpeg"


def test_write_rejects_changed_epub_paragraphs(tmp_path):
    source = build_epub(tmp_path / "book.epub")
    book = parse_epub(source)
    selection = CleaningSelection(analyze_cleaning(book.cleaning_text()))
    edits = plan_block_edits(book, selection)

    changed = build_epub(
        tmp_path / "changed.epub",
        chapter_one=CHAPTER_ONE.replace("这是第三段。", "这是已改写的第三段。"),
    ).read_bytes()
    with pytest.raises(EpubError):
        write_edited_epub(changed, book, edits, tmp_path / "out.epub")


def test_drm_encrypted_content_is_rejected(tmp_path):
    encryption = """<?xml version="1.0" encoding="utf-8"?>
<encryption xmlns="urn:oasis:names:tc:opendocument:xmlns:container"
            xmlns:enc="http://www.w3.org/2001/04/xmlenc#">
  <enc:EncryptedData>
    <enc:CipherData><enc:CipherReference URI="OEBPS/text/ch1.xhtml"/></enc:CipherData>
  </enc:EncryptedData>
</encryption>
"""
    source = build_epub(tmp_path / "drm.epub", encryption=encryption)
    with pytest.raises(EpubError, match="DRM"):
        parse_epub(source)


def test_obfuscated_font_is_allowed_with_warning(tmp_path):
    package = PACKAGE.replace(
        '    <item id="cover-image"',
        '    <item id="font" href="fonts/book.otf" media-type="application/vnd.ms-opentype"/>\n'
        '    <item id="cover-image"',
    )
    encryption = """<?xml version="1.0" encoding="utf-8"?>
<encryption xmlns="urn:oasis:names:tc:opendocument:xmlns:container"
            xmlns:enc="http://www.w3.org/2001/04/xmlenc#">
  <enc:EncryptedData>
    <enc:CipherData><enc:CipherReference URI="OEBPS/fonts/book.otf"/></enc:CipherData>
  </enc:EncryptedData>
</encryption>
"""
    source = build_epub(
        tmp_path / "font.epub", package=package, encryption=encryption,
        extra={"OEBPS/fonts/book.otf": b"font"},
    )
    book = parse_epub(source)
    assert book.font_obfuscated is True
    assert any("字体" in warning for warning in book.warnings)


def test_invalid_epub_reports_chinese_error(tmp_path):
    broken = tmp_path / "broken.epub"
    broken.write_bytes(b"not a zip")
    with pytest.raises(EpubError, match="ZIP"):
        parse_epub(broken)


def test_missing_opf_is_rejected(tmp_path):
    source = tmp_path / "no-opf.epub"
    with ZipFile(source, "w") as archive:
        archive.writestr("mimetype", "application/epub+zip")
        archive.writestr("META-INF/container.xml", CONTAINER)
    with pytest.raises(EpubError, match="OPF"):
        parse_epub(source)
