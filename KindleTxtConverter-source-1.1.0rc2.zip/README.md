# Kindle 电子书转换器

面向 Kindle Paperwhite 3，默认 AZW3、MOBI 备用；支持 TXT 转换，也支持 EPUB 直接转成这两种 Kindle 格式。最终目标是 Windows 10/11 x64 上解压双击即可离线使用的便携版，用户无需另装 Python 或 Calibre。

使用 **Windows x64 便携候选版 1.1.0rc2** 时，将 `dist/KindleConverter_1.1.0rc2_Windows_x64.zip` 完整解压至可写目录，双击 `Kindle电子书转换器.exe`。默认输出到软件目录下的 `outputs`，也可以点击「选择文件夹」指定输出位置。文件名按书名和格式自动生成。独立 Windows 验收已按用户决定通过，TXT 双格式 PW3 试读已获用户确认。[候选包报告](docs/reports/TASK-018.md)、[实机回执](docs/reports/PW3-双格式-2026-11-12.md)

新版解压后仅有 EXE 和使用说明。运行依赖、标准规则、许可及源码材料已内置，菜单「许可与源码」可打开材料。启动需稍候释放临时文件，正常退出后清理；生成的电子书和自定义设置会按使用情况保留。

1.1.0rc2 起界面改为浅色书卷风：宣纸米色背景、墨色文字、朱砂红主按钮，保留「书籍信息 / 清理预览 / 章节目录」三个标签页和原有菜单结构。

1.1.0rc2 ZIP 的 SHA-256 为 `8396c54c7cd6ee06ba8f577bf7499c640024b73983c0a31328d5d4b34fe97ed1`，同目录 `.zip.sha256` 文件可校验。

单文件构建入口为 `scripts/build_single_file.py`，解压后的真实双格式检查入口为 `scripts/verify_single_file.py`。旧版多文件构建脚本保留用于历史包复现。

桌面入口支持单本、批量和自定义清理规则。默认导出 AZW3，可选 MOBI。生成后可打开输出目录，由用户自行传送电子书。产品要求见 [完整任务书](docs/requirements.md)，阶段进度见 [开发计划](docs/DEVELOPMENT_PLAN.md)。

V1.1 起支持导入 `.epub`：保留原书排版、插图和内嵌目录，直接转换为 AZW3/MOBI。清理预览按整段删除或替换，章节目录页只读展示原书目录，原始 EPUB 保持不变；含 DRM 的 EPUB 会被明确拒绝。批量转换支持 TXT 与 EPUB 混合导入。1.1.0rc2 便携包已包含此功能，并通过解压后包内 EPUB 转换检查；EPUB 的 PW3 实机验收仍待进行。[实现与验证报告](docs/reports/V1.1-EPUB-输入.md)

桌面导入时显示识别编码和文件大小。识别不确定时可手动选择编码，或勾选「使用当前编码」。[编码报告](docs/reports/TASK-004.md)

TASK-005 现有 20 条标准清理规则，涵盖阅读 APP 推广、域名迁移提示及网站来源水印。新识别的来源水印和符合固定结构的无网址 APP 推广须确认。编码诊断可报告替代字符或异常控制字符的原文行号，供核对编码及预览。[乱码定位报告](docs/reports/TASK-005-11.md)

在「清理预览」中分析建议，勾选或全选后点击「删除所选」。点击条目可查看原因和上下文，取消勾选即可恢复，原始 TXT 始终保留。[清理预览报告](docs/reports/TASK-012.md)

阶段 1 的 32 份合成短文中，明确广告召回为 25/27（92.59%，任务书建议门槛为 95%），默认删除建议准确率为 20/20（100%）。[网站来源水印复测报告](docs/reports/TASK-005-17.md)

TASK-007 支持中文章节识别、重复标题合并、跳号提示及目录人工修正。TASK-008 已验证卷章层级和跳转。TASK-013 的桌面目录可新增、改名和删除。[结构化目录报告](docs/reports/TASK-008.md)、[桌面目录报告](docs/reports/TASK-013.md)

生成电子书时自动套用中文小说的默认排版。两种格式均生成章节导航，MOBI 6 自带兼容的书内目录。[排版报告](docs/reports/TASK-009.md)

「书籍信息」支持书名、作者、简介和 JPG/PNG 封面。《渡口灯火》两种格式均已通过本机回读及 PW3 试读。[书籍信息与试读报告](docs/reports/TASK-010.md)

TASK-003 的本地 Windows 桌面技术验证包已归档至 `.old/dist/`。要查看该版本，可使用 `KindleConverter-TASK003/Kindle电子书转换器.exe`，或将 `KindleConverter_TASK003_Windows_x64_验证包.zip` 完整解压后双击同名 EXE。运行时需要同目录下的 `_internal`、`converter`、`licenses` 和 `sources`。

开发机上的迁移及实际转换已通过，包内自带应用和引擎运行时。干净 Windows、断网及普通账号条件尚未实测。当前包供技术验证使用，转换时保留原文。见 [TASK-003 报告](docs/reports/TASK-003.md) 与 [独立环境验证清单](docs/clean-windows-checklist.md)。

补充验证：既有ZIP已实际解压到新目录，全部2,333文件校验及解压后两种格式转换通过。用户也确认 AZW3 在 PW3 可正常浏览并点击章节跳转；这是本次文件的用户实测，不等于全书、MOBI或完整设备验收通过。见 [PW3 实机回执](docs/reports/PW3-AZW3-2026-11-10.md)。

## 当前工程

- `src/kindle_converter/`：Python 模块，包含只读快照、编码、首批清理建议核心与现有转换验证。
- `rules/standard.json`：内置标准清理规则及对应合成用例编号。
- `pyproject.toml`、`requirements.lock`：固定依赖版本及文件哈希。
- `scripts/bootstrap_windows.ps1`：在项目内准备运行时和开发环境。
- `scripts/test_windows.ps1`：按授权运行 Python 检查。
- `tests/`：自行编写的 Python 测试，不包含用户小说。
- `docs/development.md`、`docs/architecture.md`：开发方法和模块边界。
- `docs/third-party-licenses.md`、`licenses/`：第三方版本与许可记录。

开发依赖为 CPython 3.14.10、PySide6-Essentials 6.12.0、charset-normalizer 3.5.2、pytest 9.2.0、PyInstaller 6.22.3。转换引擎为项目内完整 Calibre 9.18.0，使用 PW3 配置。详见 [TASK-002 结果](docs/reports/TASK-002.md) 和 [转换运行时说明](docs/packaging.md)。

开发步骤见 [开发说明](docs/development.md)。用户小说只读，不覆盖、不删除、不上传，不纳入源码或发行压缩包。

## 历史文件归档

`.old/` 按原项目相对路径存放旧候选包、构建和解压验证副本、缓存及早期浏览器原型。查找历史报告引用的产物时，如果原路径下没有该文件，可在路径前加 `.old/` 查找。`dist/` 保留当前候选 ZIP 和 SHA-256 校验文件，`build/reports/` 保留构建及验收记录。

如需复现早期浏览器原型，将 `.old/` 内的 `server.js`、`public/`、`start.bat` 和 `test/` 放回项目根目录。双击 `start.bat` 会打开 `http://127.0.0.1:8765/`。原型依赖 Node.js 和项目内转换引擎，支持导入 TXT、预览与恢复部分清理项、导出 TXT 和日志，以及生成 AZW3 和 MOBI。

旧原型测试归档于 `.old/test/startup.test.js`。当前桌面版的 Python 测试位于 `tests/`。

TASK-002 的小说输出在 `outputs/TASK-002/verified/`，仅作为保留原文内容的转换验证版，未应用后续正式清理规则。用户小说及转换产物不纳入源码和发行包。
